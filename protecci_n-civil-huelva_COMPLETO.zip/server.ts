import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

const apiKey = (process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY || '').trim();

let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const SYSTEM_INSTRUCTION = `Eres el Asistente Clínico Operativo de Emergencias de Protección Civil Huelva, basado estrictamente en las Guías Europeas de Resucitación ERC 2025 y protocolos de primeros auxilios extrahospitalarios.

Tu cometido es guiar al rescatista/voluntario en tiempo real, paso a paso, con instrucciones directas, claras y concisas:
1. PAS (Seguridad): Lo primero al llegar es exigir comprobar la seguridad de la escena (Proteger, Avisar, Socorrer). Pregunta si el entorno es seguro.
2. Entrevista clínica: Proporciona el guion con las preguntas textuales exactas que el rescatista debe decirle al paciente para abrir la entrevista (ej: "Hola, somos de Protección Civil Huelva. ¿Cómo se encuentra y qué le ha ocurrido?").
3. Identificación de patología: Según los síntomas descritos, deduce y activa protocolos inmediatos para:
   - Infarto (IAM): dolor opresivo centrotorácico irradiado a brazo izquierdo/mandíbula/espalda, sudoración fría, disnea -> reposo absoluto, posición semisentada, no esfuerzo, solicitar DESA.
   - Ictus: Escala FAST (Sonrisa/cara asimétrica, brazos que caen, habla alterada), registrar hora exacta de inicio de síntomas, PROHIBIDO dar comida o bebida.
   - Shock: TAS < 90 mmHg, palidez, sudoración fría, taquicardia -> decúbito supino con piernas elevadas, manta térmica, aviso urgente 112.
   - Anafilaxia: disnea, estridor, sibilancias, hinchazón labios/lengua, exantema -> adrenalina IM 0.5mg en muslo (si prescrita/protocolizada), aviso 112.
   - Trauma: control cervical, hemostasia directa o torniquete en hemorragia masiva, inmovilización.
4. Solicitud de constantes vitales una a una: solicita FC (lpm), SpO2 (%), TAS/TAD (mmHg), Temperatura (°C), Glucemia (mg/dl) y Nivel de conciencia AVPU (alerta, voz, dolor, inconsciente).
5. ALERTA CRÍTICA: Si detectas cualquier constante en rango crítico (ejemplo TAS < 90 mmHg, SpO2 < 90%, FC > 140 o < 40 lpm, paciente inconsciente/parada, o anafilaxia severa), debes ORDENAR DETENER EL CUESTIONARIO e incluir de forma destacada:
   "[LLAMADA AL 112/061 - PRIORIDAD ROJA]"

REGLA DE FORMATO OBLIGATORIA PARA AUTO-RELLENO DEL FORMULARIO:
Siempre que identifiques, deduzcas o el usuario te facilite cualquier constante o dato clínico, incluye en tu respuesta etiquetas estructuradas entre llaves {} con este formato exacto:
- {fc: número}
- {sat: número}
- {fr: número}
- {tas: número}
- {tad: número}
- {temperatura: número}
- {glucemia: número}
- {nivelConciencia: "alerta" | "voz" | "dolor" | "inconsciente"}
- {motivo: "resumen breve del motivo"}
- {antecedentes: "alergias, medicación o antecedentes SAMPLE"}
- {tratamiento: "maniobras o medidas aplicadas"}
- {resolucion: "alta_lugar" | "derivacion_centro" | "ambulancia_uvi"}`;

app.post('/api/clinical-assistant', async (req, res) => {
  const { messages, userMessage } = req.body;

  if (!ai) {
    return res.status(503).json({ error: 'Gemini API key no configurada en el servidor' });
  }

  try {
    const formattedHistory = (Array.isArray(messages) ? messages : []).map((m: any) => ({
      role: m.sender === 'user' || m.role === 'user' ? 'user' : 'model',
      parts: [{ text: String(m.text || m.parts?.[0]?.text || '') }],
    }));

    const contents = [
      ...formattedHistory,
      { role: 'user', parts: [{ text: String(userMessage || '') }] },
    ];

    // Priority models for text assistance per gemini-api skill: gemini-3.8-flash for speed
    const modelsToTry = ['gemini-3.8-flash', 'gemini-flash-latest'];
    let responseText = '';
    let lastErr: unknown = null;

    for (const model of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.2,
          },
        });
        if (response.text) {
          responseText = response.text;
          break;
        }
      } catch (err) {
        lastErr = err;
        console.warn(`Model ${model} request failed, attempting fallback:`, err);
      }
    }

    if (responseText) {
      return res.json({ text: responseText });
    }

    throw lastErr || new Error('No se recibió texto del modelo Gemini');
  } catch (error: any) {
    console.error('Error en /api/clinical-assistant:', error);
    return res.status(500).json({ error: error?.message || 'Error interno del asistente clínico' });
  }
});

app.post('/api/ocr-dni', async (req, res) => {
  const { imageBase64 } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ error: 'Falta la imagen a procesar' });
  }

  const cleanBase64 = String(imageBase64).replace(/^data:image\/[a-zA-Z]+;base64,/, '');

  if (!ai) {
    return res.status(503).json({ error: 'Servicio de reconocimiento visual no disponible en el servidor' });
  }

  try {
    const prompt = `Analiza detalladamente esta fotografía de un documento de identidad español (DNI, NIE o Tarjeta Sanitaria de Andalucía/SAS) y extrae los datos del paciente para un parte de emergencias sanitarias.
Devuelve EXCLUSIVAMENTE un JSON válido con este formato exacto:
{
  "dni": "8 dígitos y letra de control en mayúscula, o NIE con X/Y/Z inicial y letra final",
  "nombre": "Nombre de pila del titular",
  "apellidos": "Primer y segundo apellido",
  "fecha_nacimiento": "YYYY-MM-DD si es claramente visible",
  "edad": número entero de edad aproximada calculada respecto al año actual, o null,
  "direccion": "Dirección o municipio de residencia si aparece",
  "cip_nss": "Código de tarjeta sanitaria si aparece"
}
Si algún dato no es legible, pon null. Responde solo el JSON sin explicaciones ni formato markdown.`;

    // Priority model for multimodal vision per gemini-api skill: gemini-2.5-flash
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { text: prompt },
            {
              inlineData: {
                data: cleanBase64,
                mimeType: 'image/jpeg',
              },
            },
          ],
        },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const cleanJson = text.replace(/```(?:json)?/gi, '').replace(/```/g, '').trim();
    const data = JSON.parse(cleanJson);
    return res.json(data);
  } catch (err: any) {
    console.error('Error en /api/ocr-dni:', err);
    return res.status(500).json({ error: err?.message || 'Error procesando documento' });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true, port: PORT, host: '0.0.0.0' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile('dist/index.html', { root: '.' });
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
