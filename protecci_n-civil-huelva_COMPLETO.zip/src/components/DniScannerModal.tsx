import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Camera, CheckCircle2, Loader2, ScanLine, X, TriangleAlert } from 'lucide-react';
import { generateSimulatedScan } from '@/lib/dniScanner';

export interface DniScanCapture {
  dni: string;
  nombre: string;
}

interface DniScannerModalProps {
  open: boolean;
  onClose: () => void;
  /** Se invoca al pulsar "Capturar" con los datos (simulados) leídos del documento. */
  onCapture: (data: DniScanCapture) => void;
}

type Phase = 'ready' | 'scanning' | 'done';
type CameraState = 'starting' | 'live' | 'unavailable';

/** Tiempo que dura el "análisis" simulado antes de rellenar el formulario. */
const SCAN_DURATION_MS = 900;
/** Pausa final con el tick verde antes de cerrar el modal. */
const DONE_HOLD_MS = 300;

export function DniScannerModal({ open, onClose, onCapture }: DniScannerModalProps) {
  const [phase, setPhase] = useState<Phase>('ready');
  const [cameraState, setCameraState] = useState<CameraState>('starting');
  const videoRef = useRef<HTMLVideoElement>(null);
  const timers = useRef<number[]>([]);

  const clearTimers = () => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
  };

  // Cámara real como fondo del visor (si hay permiso); si no, visor simulado.
  useEffect(() => {
    if (!open) return;
    setPhase('ready');
    setCameraState('starting');

    let cancelled = false;
    let stream: MediaStream | null = null;

    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraState('unavailable');
    } else {
      navigator.mediaDevices
        .getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false })
        .then((s) => {
          if (cancelled) {
            s.getTracks().forEach((t) => t.stop());
            return;
          }
          stream = s;
          const video = videoRef.current;
          if (video) {
            video.srcObject = s;
            video.play().catch(() => undefined);
          }
          setCameraState('live');
        })
        .catch(() => {
          if (!cancelled) setCameraState('unavailable');
        });
    }

    return () => {
      cancelled = true;
      clearTimers();
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [open]);

  // Cerrar con Escape
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  const handleCapture = () => {
    if (phase !== 'ready') return;
    setPhase('scanning');
    timers.current.push(
      window.setTimeout(() => {
        onCapture(generateSimulatedScan());
        setPhase('done');
        timers.current.push(window.setTimeout(onClose, DONE_HOLD_MS));
      }, SCAN_DURATION_MS)
    );
  };

  const scanning = phase === 'scanning';
  const done = phase === 'done';

  return createPortal(
    <div
      className="fixed inset-0 flex items-center justify-center bg-black/80 p-4"
      style={{ zIndex: 1300 }}
      role="dialog"
      aria-modal="true"
      aria-label="Escáner de DNI / Tarjeta Sanitaria"
    >
      <div className="w-full max-w-md rounded-3xl bg-slate-950 text-white shadow-2xl border border-white/10 overflow-hidden">
        {/* Cabecera */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <ScanLine size={18} className="text-green-400" />
            <h2 className="text-sm font-bold">Escanear DNI / Tarjeta Sanitaria</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar escáner"
            className="p-1.5 rounded-lg hover:bg-white/10 cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-4 space-y-3">
          {/* VISOR */}
          <div className="relative aspect-[1.586] w-full overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 ring-1 ring-white/10">
            <video
              ref={videoRef}
              muted
              playsInline
              className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-300 ${
                cameraState === 'live' ? 'opacity-100' : 'opacity-0'
              }`}
            />

            {/* Silueta de documento cuando no hay cámara real */}
            {cameraState !== 'live' && (
              <div className="absolute inset-[12%] rounded-xl border border-white/10 bg-white/5 p-3 flex gap-3 opacity-70" aria-hidden="true">
                <div className="w-1/4 rounded-md bg-white/10" />
                <div className="flex-1 space-y-2 pt-1">
                  <div className="h-2.5 w-3/4 rounded bg-white/15" />
                  <div className="h-2.5 w-1/2 rounded bg-white/10" />
                  <div className="h-2.5 w-2/3 rounded bg-white/10" />
                  <div className="h-2.5 w-1/3 rounded bg-white/15" />
                </div>
              </div>
            )}

            {/* Cuadro delimitador verde con esquinas */}
            <div
              className={`absolute inset-[8%] rounded-xl border-2 transition-colors duration-300 ${
                done ? 'border-green-300 bg-green-400/20' : 'border-green-400/80'
              }`}
              style={{ boxShadow: '0 0 0 9999px rgba(2, 6, 23, 0.45)' }}
              aria-hidden="true"
            >
              <span className="absolute -left-0.5 -top-0.5 h-5 w-5 rounded-tl-xl border-l-4 border-t-4 border-green-300" />
              <span className="absolute -right-0.5 -top-0.5 h-5 w-5 rounded-tr-xl border-r-4 border-t-4 border-green-300" />
              <span className="absolute -bottom-0.5 -left-0.5 h-5 w-5 rounded-bl-xl border-b-4 border-l-4 border-green-300" />
              <span className="absolute -bottom-0.5 -right-0.5 h-5 w-5 rounded-br-xl border-b-4 border-r-4 border-green-300" />

              {/* Línea láser animada */}
              {!done && (
                <span
                  className={`dni-laser absolute left-1 right-1 h-0.5 rounded-full bg-green-400 ${
                    scanning ? 'dni-laser-fast' : ''
                  }`}
                  style={{ boxShadow: '0 0 12px 3px rgba(74, 222, 128, 0.85)' }}
                />
              )}

              {done && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <CheckCircle2 size={56} className="text-green-300 drop-shadow" />
                </div>
              )}
            </div>

            {/* Estado dentro del visor */}
            <div className="absolute inset-x-0 bottom-1.5 flex justify-center">
              <span className="rounded-full bg-black/60 px-3 py-0.5 text-[11px] font-semibold text-green-300 backdrop-blur-sm">
                {done
                  ? 'Documento leído'
                  : scanning
                  ? 'Analizando documento…'
                  : cameraState === 'starting'
                  ? 'Iniciando cámara…'
                  : 'Encuadra el documento dentro del recuadro'}
              </span>
            </div>
          </div>

          {/* Aviso de simulación */}
          <div className="flex items-start gap-2 rounded-xl border border-amber-400/30 bg-amber-400/10 px-3 py-2 text-[11px] leading-snug text-amber-200">
            <TriangleAlert size={14} className="mt-0.5 shrink-0" />
            <p>
              <strong>Modo demostración.</strong> La captura rellena un DNI válido y un nombre
              <strong> ficticios</strong>; no se lee el documento real. Sustituye los datos por los reales antes de guardar el parte.
            </p>
          </div>

          {/* Acciones */}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={scanning}
              className="flex-1 rounded-xl border border-white/15 px-4 py-2.5 text-sm font-medium text-slate-200 hover:bg-white/10 disabled:opacity-40 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleCapture}
              disabled={phase !== 'ready'}
              className="flex-[1.4] flex items-center justify-center gap-2 rounded-xl bg-green-500 px-4 py-2.5 text-sm font-bold text-slate-950 hover:bg-green-400 active:scale-95 transition-all disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer"
            >
              {scanning ? <Loader2 size={17} className="animate-spin" /> : done ? <CheckCircle2 size={17} /> : <Camera size={17} />}
              <span>{scanning ? 'Escaneando…' : done ? 'Completado' : 'Capturar'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}
