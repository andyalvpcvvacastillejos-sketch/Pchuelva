import { useCallback, useEffect, useState, useRef } from 'react';
import {
  Activity,
  ArrowLeft,
  Droplet,
  HeartPulse,
  History,
  MapPin,
  Save,
  Stethoscope,
  Thermometer,
  User,
  Sparkles,
  Bot,
  Send,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  MessageSquare,
  Radio,
  Camera,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, isSupabaseConfigured, type AvpuLevel, type MedicalReport, type MedicalResolution, type OperationalVehicle, type PatientHistory, type Servicio } from '@/lib/supabase';
import { demoServicios, demoVehicles, demoPatientHistories, demoMedicalReports } from '@/lib/demoData';
import { getFleetVehicles, subscribeToFleetUpdates } from '@/lib/fleetStorage';
import { scanDniDocument, validateSpanishDni } from '@/lib/dniScanner';
import { DniScannerModal, type DniScanCapture } from '@/components/DniScannerModal';
import { Spinner } from '@/components/ui/Spinner';

const isValidUuid = (val?: string | null): boolean =>
  Boolean(val && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(val));
import {
  askGeminiAssistant,
  parseExtractedData,
  cleanTextForDisplay,
  getImmediateProtocolResponse,
  PROTOCOLS_LIST,
  type ChatMessage,
} from '@/lib/geminiAssistant';

const avpuOptions: { value: AvpuLevel; label: string; description: string }[] = [
  { value: 'alerta', label: 'A', description: 'Alerta, responde espontáneamente' },
  { value: 'voz', label: 'V', description: 'Responde a estímulos verbales' },
  { value: 'dolor', label: 'P', description: 'Responde solo al dolor' },
  { value: 'inconsciente', label: 'U', description: 'Inconsciente, sin respuesta' },
];

const resolutionOptions: { value: MedicalResolution; label: string; color: string }[] = [
  { value: 'alta_lugar', label: 'Alta en el lugar', color: 'success' },
  { value: 'derivacion_centro', label: 'Derivación a centro sanitario', color: 'warning' },
  { value: 'ambulancia_uvi', label: 'Ambulancia UVI', color: 'error' },
];

const vehicleTypeLabels: Record<string, string> = { vir: 'VIR', coordinacion: 'Coordinación', ambulancia: 'Ambulancia', logistica: 'Logística', otro: 'Otro' };

type VitalField = 'fc' | 'tas' | 'tad' | 'spo2' | 'temperatura' | 'glucemia';

export function ParteSanitarioModal({
  incidentId,
  incidentDescription,
  onClose,
  onSaved,
}: {
  incidentId: string;
  incidentDescription: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { user } = useAuth();
  const [pacienteNombre, setPacienteNombre] = useState('');
  const [pacienteEdad, setPacienteEdad] = useState('');
  const [pacienteTelefono, setPacienteTelefono] = useState('');
  const [pacienteDni, setPacienteDni] = useState('');
  const [direccion, setDireccion] = useState('');
  const [motivo, setMotivo] = useState('');
  const [fc, setFc] = useState('');
  const [tas, setTas] = useState('');
  const [tad, setTad] = useState('');
  const [spo2, setSpo2] = useState('');
  const [temperatura, setTemperatura] = useState('');
  const [glucemia, setGlucemia] = useState('');
  const [nivelConciencia, setNivelConciencia] = useState<AvpuLevel | ''>('');
  const [tratamiento, setTratamiento] = useState('');
  const [resolucion, setResolucion] = useState<MedicalResolution>('alta_lugar');
  const [servicioId, setServicioId] = useState<string>('');
  const [vehiculoId, setVehiculoId] = useState<string>('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const [showAssistant, setShowAssistant] = useState(false);
  const [assistantMode, setAssistantMode] = useState<'text' | 'voice'>('text');
  const [isListening, setIsListening] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const recognitionRef = useRef<any>(null);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [assistantInput, setAssistantInput] = useState('');
  const [assistantLoading, setAssistantLoading] = useState(false);
  const [lastExtractedAlert, setLastExtractedAlert] = useState<string | null>(null);
  const [isRedAlert, setIsRedAlert] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const [services, setServices] = useState<Servicio[]>([]);
  const [vehicles, setVehicles] = useState<OperationalVehicle[]>([]);
  const [patientHistory, setPatientHistory] = useState<PatientHistory | null>(null);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [pastReports, setPastReports] = useState<{ created_at: string; motivo_asistencia: string; resolucion: string }[]>([]);

  const vitalSetters: Record<VitalField, (v: string) => void> = {
    fc: setFc, tas: setTas, tad: setTad, spo2: setSpo2, temperatura: setTemperatura, glucemia: setGlucemia,
  };
  const vitalValues: Record<VitalField, string> = { fc, tas, tad, spo2, temperatura, glucemia };

  const handleResetAssistant = useCallback(() => {
    setIsRedAlert(false);
    setLastExtractedAlert(null);
    setMessages([
      {
        id: 'welcome',
        sender: 'assistant',
        text: `Protocolo Clínico y de Soporte Vital (ERC 2025) activado.\n\n1. SEGURIDAD DE LA ESCENA (PAS):\nAntes de intervenir, verifica que el entorno es seguro para ti y tu equipo (tráfico cortado, sin fuego, ni riesgo eléctrico o colapso).\n\n2. GUION DE APERTURA:\nAcércate al paciente con voz calmada y segura y dile:\n"Hola, somos de Protección Civil Huelva. ¿Cómo se encuentra y qué le ha ocurrido?"\n\nIndícame qué síntomas o constantes vitales presenta la víctima.`,
        timestamp: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  }, []);

  useEffect(() => {
    // Si ya existe un parte sanitario previo para esta incidencia, precargar datos
    const loadExistingReport = async () => {
      try {
        const localReports = JSON.parse(localStorage.getItem('pc-huelva-demo-reports') || '[]') as MedicalReport[];
        const found = localReports.find((r) => r.incident_id === incidentId);
        if (found) {
          if (found.motivo_asistencia) setMotivo(found.motivo_asistencia);
          if (found.paciente_nombre) setPacienteNombre(found.paciente_nombre);
          if (found.paciente_edad) setPacienteEdad(String(found.paciente_edad));
          if (found.paciente_telefono) setPacienteTelefono(found.paciente_telefono);
          if (found.paciente_dni) setPacienteDni(found.paciente_dni);
          if (found.direccion) setDireccion(found.direccion);
          if (found.fc) setFc(String(found.fc));
          if (found.tas) setTas(String(found.tas));
          if (found.tad) setTad(String(found.tad));
          if (found.spo2) setSpo2(String(found.spo2));
          if (found.temperatura) setTemperatura(String(found.temperatura));
          if (found.glucemia) setGlucemia(String(found.glucemia));
          if (found.nivel_conciencia) setNivelConciencia(found.nivel_conciencia);
          if (found.tratamiento) setTratamiento(found.tratamiento);
          if (found.resolucion) setResolucion(found.resolucion);
          if (found.servicio_id) setServicioId(found.servicio_id);
          if (found.vehiculo_id) setVehiculoId(found.vehiculo_id);
          return;
        }
      } catch { /* noop */ }

      const demoRep = demoMedicalReports.find((r) => r.incident_id === incidentId);
      if (demoRep) {
        if (demoRep.motivo_asistencia) setMotivo(demoRep.motivo_asistencia);
        if (demoRep.paciente_nombre) setPacienteNombre(demoRep.paciente_nombre);
        if (demoRep.paciente_edad) setPacienteEdad(String(demoRep.paciente_edad));
        if (demoRep.paciente_telefono) setPacienteTelefono(demoRep.paciente_telefono);
        if (demoRep.paciente_dni) setPacienteDni(demoRep.paciente_dni);
        if (demoRep.direccion) setDireccion(demoRep.direccion);
        if (demoRep.fc) setFc(String(demoRep.fc));
        if (demoRep.tas) setTas(String(demoRep.tas));
        if (demoRep.tad) setTad(String(demoRep.tad));
        if (demoRep.spo2) setSpo2(String(demoRep.spo2));
        if (demoRep.temperatura) setTemperatura(String(demoRep.temperatura));
        if (demoRep.glucemia) setGlucemia(String(demoRep.glucemia));
        if (demoRep.nivel_conciencia) setNivelConciencia(demoRep.nivel_conciencia);
        if (demoRep.tratamiento) setTratamiento(demoRep.tratamiento);
        if (demoRep.resolucion) setResolucion(demoRep.resolucion);
        if (demoRep.servicio_id) setServicioId(demoRep.servicio_id);
        if (demoRep.vehiculo_id) setVehiculoId(demoRep.vehiculo_id);
        return;
      }

      if (isSupabaseConfigured && isValidUuid(incidentId)) {
        try {
          const { data } = await supabase
            .from('partes_sanitarios')
            .select('*')
            .eq('incident_id', incidentId)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          if (data) {
            if (data.motivo_asistencia) setMotivo(data.motivo_asistencia);
            if (data.paciente_nombre) setPacienteNombre(data.paciente_nombre);
            if (data.paciente_edad) setPacienteEdad(String(data.paciente_edad));
            if (data.paciente_telefono) setPacienteTelefono(data.paciente_telefono);
            if (data.paciente_dni) setPacienteDni(data.paciente_dni);
            if (data.direccion) setDireccion(data.direccion);
            if (data.fc) setFc(String(data.fc));
            if (data.tas) setTas(String(data.tas));
            if (data.tad) setTad(String(data.tad));
            if (data.spo2) setSpo2(String(data.spo2));
            if (data.temperatura) setTemperatura(String(data.temperatura));
            if (data.glucemia) setGlucemia(String(data.glucemia));
            if (data.nivel_conciencia) setNivelConciencia(data.nivel_conciencia as AvpuLevel);
            if (data.tratamiento) setTratamiento(data.tratamiento);
            if (data.resolucion) setResolucion(data.resolucion as MedicalResolution);
            if (data.servicio_id) setServicioId(data.servicio_id);
            if (data.vehiculo_id) setVehiculoId(data.vehiculo_id);
          }
        } catch { /* noop */ }
      }
    };

    loadExistingReport();
  }, [incidentId]);

  useEffect(() => {
    if (showAssistant && messages.length === 0) {
      handleResetAssistant();
    }
  }, [showAssistant, messages.length, handleResetAssistant]);

  useEffect(() => {
    if (showAssistant) {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, showAssistant]);

  // Síntesis de voz (Text-to-Speech) para lectura de instrucciones clínicas
  const speakResponse = useCallback((text: string) => {
    if (!('speechSynthesis' in window) || !ttsEnabled) return;
    try {
      window.speechSynthesis.cancel();
      const clean = cleanTextForDisplay(text).replace(/\[[^\]]+\]/g, '').replace(/[•\-\*]/g, '').slice(0, 320);
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.lang = 'es-ES';
      utterance.rate = 1.05;
      window.speechSynthesis.speak(utterance);
    } catch { /* noop */ }
  }, [ttsEnabled]);

  // Inicialización de reconocimiento de voz (Web Speech API)
  useEffect(() => {
    const SpeechRecognition =
      (window as unknown as { SpeechRecognition?: any; webkitSpeechRecognition?: any }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: any }).webkitSpeechRecognition;

    if (SpeechRecognition) {
      setSpeechSupported(true);
      try {
        const recognition = new SpeechRecognition();
        recognition.lang = 'es-ES';
        recognition.continuous = false;
        recognition.interimResults = true;

        recognition.onresult = (event: any) => {
          let transcript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
          }
          if (transcript) {
            setAssistantInput(transcript);
          }
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      } catch (e) {
        console.warn('SpeechRecognition init error:', e);
      }
    }
  }, []);

  const toggleListening = () => {
    if (!speechSupported || !recognitionRef.current) {
      setSpeechError('El reconocimiento de voz nativo no está disponible en este navegador o entorno. Puedes usar el Modo Escribir.');
      setTimeout(() => setSpeechError(null), 6000);
      return;
    }

    if (isListening) {
      try {
        recognitionRef.current.stop();
      } catch { /* noop */ }
      setIsListening(false);
    } else {
      try {
        setSpeechError(null);
        setAssistantInput('');
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.warn('Error starting speech recognition:', err);
        setIsListening(false);
        setSpeechError('No se pudo activar el micrófono. Verifica los permisos de tu navegador o usa el Modo Escribir.');
        setTimeout(() => setSpeechError(null), 6000);
      }
    }
  };

  const applyExtractedData = (extracted: ReturnType<typeof parseExtractedData>) => {
    const filled: string[] = [];
    if (extracted.fc !== undefined) {
      setFc(String(extracted.fc));
      filled.push(`FC: ${extracted.fc} lpm`);
    }
    if (extracted.sat !== undefined) {
      setSpo2(String(extracted.sat));
      filled.push(`SpO2: ${extracted.sat}%`);
    }
    if (extracted.tas !== undefined) {
      setTas(String(extracted.tas));
      filled.push(`TAS: ${extracted.tas} mmHg`);
    }
    if (extracted.tad !== undefined) {
      setTad(String(extracted.tad));
      filled.push(`TAD: ${extracted.tad} mmHg`);
    }
    if (extracted.temperatura !== undefined) {
      setTemperatura(String(extracted.temperatura));
      filled.push(`Tª: ${extracted.temperatura}°C`);
    }
    if (extracted.glucemia !== undefined) {
      setGlucemia(String(extracted.glucemia));
      filled.push(`Glucemia: ${extracted.glucemia} mg/dl`);
    }
    if (extracted.nivelConciencia !== undefined) {
      setNivelConciencia(extracted.nivelConciencia);
      filled.push(`AVPU: ${extracted.nivelConciencia}`);
    }
    if (extracted.motivo) {
      setMotivo((prev) => (prev ? (prev.includes(extracted.motivo!) ? prev : `${prev}. ${extracted.motivo}`) : extracted.motivo!));
      filled.push('Motivo');
    }
    if (extracted.antecedentes) {
      setMotivo((prev) => (prev ? `${prev}. [SAMPLE: ${extracted.antecedentes}]` : `[SAMPLE: ${extracted.antecedentes}]`));
      filled.push('Antecedentes');
    }
    if (extracted.tratamiento) {
      setTratamiento((prev) => (prev ? (prev.includes(extracted.tratamiento!) ? prev : `${prev}. ${extracted.tratamiento}`) : extracted.tratamiento!));
      filled.push('Tratamiento');
    }
    if (extracted.resolucion) {
      setResolucion(extracted.resolucion);
      filled.push(`Resolución: ${extracted.resolucion}`);
    }
    if (extracted.isRedPriority) {
      setIsRedAlert(true);
    }

    if (filled.length > 0) {
      setLastExtractedAlert(`Datos sincronizados en el formulario: ${filled.join(', ')}`);
      setTimeout(() => setLastExtractedAlert(null), 6000);
    }
  };

  const handleRunFastProtocol = (protocolId: string) => {
    const rawResponse = getImmediateProtocolResponse(protocolId);
    const extracted = parseExtractedData(rawResponse);
    applyExtractedData(extracted);

    const botMsg: ChatMessage = {
      id: String(Date.now() + 1),
      sender: 'assistant',
      text: cleanTextForDisplay(rawResponse),
      timestamp: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      extracted,
      isRedPriority: extracted.isRedPriority,
    };

    setMessages((prev) => [...prev, botMsg]);
    speakResponse(rawResponse);
  };

  const handleSendAssistantMessage = async (customText?: string) => {
    const textToSend = (customText ?? assistantInput).trim();
    if (!textToSend || assistantLoading) return;

    if (isListening) {
      try {
        recognitionRef.current?.stop();
      } catch { /* noop */ }
      setIsListening(false);
    }

    const userMsg: ChatMessage = {
      id: String(Date.now()),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customText) setAssistantInput('');
    setAssistantLoading(true);

    try {
      const history = messages.map((m) => ({
        role: m.sender === 'user' ? ('user' as const) : ('model' as const),
        parts: [{ text: m.text }],
      }));

      const rawResponse = await askGeminiAssistant(history, textToSend);
      const extracted = parseExtractedData(rawResponse);
      applyExtractedData(extracted);

      const botMsg: ChatMessage = {
        id: String(Date.now() + 1),
        sender: 'assistant',
        text: cleanTextForDisplay(rawResponse),
        timestamp: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
        extracted,
        isRedPriority: extracted.isRedPriority,
      };

      setMessages((prev) => [...prev, botMsg]);
      speakResponse(rawResponse);
    } catch (err) {
      console.error('Error with clinical assistant:', err);
      // Even on unexpected error, provide immediate protocol response
      const fallbackText = getImmediateProtocolResponse('constantes');
      setMessages((prev) => [
        ...prev,
        {
          id: String(Date.now() + 1),
          sender: 'assistant',
          text: fallbackText,
          timestamp: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      speakResponse(fallbackText);
    } finally {
      setAssistantLoading(false);
    }
  };

  useEffect(() => {
    const fetchServices = async () => {
      if (!isSupabaseConfigured) {
        setServices(demoServicios);
        if (demoServicios.length > 0) {
          setServicioId(demoServicios[0].id);
        }
        return;
      }
      try {
        const { data } = await supabase.from('servicios').select('*').order('fecha', { ascending: false }).limit(20);
        setServices((data ?? []) as Servicio[]);
      } catch (err) {
        console.warn('Error fetching services:', err);
        setServices(demoServicios);
      }
    };
    fetchServices();
  }, []);

  const fetchVehiclesForService = useCallback(async (sId: string) => {
    const fleet = await getFleetVehicles();
    if (!isSupabaseConfigured) {
      setVehicles(fleet);
      if (fleet.length > 0 && !vehiculoId) {
        setVehiculoId(fleet[0].id);
      }
      return;
    }
    if (!sId) {
      setVehicles(fleet);
      return;
    }
    try {
      const { data: assigns } = await supabase.from('servicio_vehiculos').select('vehiculo_id').eq('servicio_id', sId);
      const vehicleIds = (assigns ?? []).map((a: { vehiculo_id: string }) => a.vehiculo_id);
      if (vehicleIds.length === 0) {
        setVehicles(fleet);
        return;
      }
      const matching = fleet.filter((v) => vehicleIds.includes(v.id));
      setVehicles(matching.length > 0 ? matching : fleet);
    } catch {
      setVehicles(fleet);
    }
  }, [vehiculoId]);

  useEffect(() => {
    fetchVehiclesForService(servicioId);
    const unsub = subscribeToFleetUpdates(() => {
      fetchVehiclesForService(servicioId);
    });
    return unsub;
  }, [servicioId, fetchVehiclesForService]);

  const searchPatientHistory = useCallback(async (dni: string) => {
    if (dni.trim().length < 5) { setPatientHistory(null); setPastReports([]); return; }
    setHistoryLoading(true);
    const dniUpper = dni.trim().toUpperCase();

    if (!isSupabaseConfigured) {
      const found = demoPatientHistories[dniUpper];
      if (found) {
        setPatientHistory(found);
        if (found.paciente_nombre && !pacienteNombre) setPacienteNombre(found.paciente_nombre);
        if (found.paciente_edad && !pacienteEdad) setPacienteEdad(String(found.paciente_edad));
        if (found.paciente_telefono && !pacienteTelefono) setPacienteTelefono(found.paciente_telefono);
        if (found.direccion && !direccion) setDireccion(found.direccion);
      } else {
        setPatientHistory(null);
      }
      setPastReports([]);
      setHistoryLoading(false);
      return;
    }

    try {
      const { data: history } = await supabase.from('historial_pacientes').select('*').eq('paciente_dni', dniUpper).maybeSingle();
      setPatientHistory(history as PatientHistory | null);
      if (history) {
        const { data: reports } = await supabase.from('partes_sanitarios').select('created_at, motivo_asistencia, resolucion').ilike('dni', dni.trim()).order('created_at', { ascending: false }).limit(10);
        setPastReports((reports ?? []) as { created_at: string; motivo_asistencia: string; resolucion: string }[]);
        if (history.paciente_nombre && !pacienteNombre) setPacienteNombre(history.paciente_nombre);
        if (history.paciente_edad && !pacienteEdad) setPacienteEdad(String(history.paciente_edad));
        if (history.paciente_telefono && !pacienteTelefono) setPacienteTelefono(history.paciente_telefono);
        if (history.direccion && !direccion) setDireccion(history.direccion);
      } else {
        setPastReports([]);
      }
    } catch {
      setPatientHistory(null);
      setPastReports([]);
    } finally {
      setHistoryLoading(false);
    }
  }, [pacienteNombre, pacienteEdad, pacienteTelefono, direccion]);

  const dniFileInputRef = useRef<HTMLInputElement>(null);
  const [scanningDni, setScanningDni] = useState(false);
  const [scanDniFeedback, setScanDniFeedback] = useState<string | null>(null);

  const handleScanDniFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setScanningDni(true);
    setScanDniFeedback(null);

    try {
      const result = await scanDniDocument(file);
      if (result.dni) {
        setPacienteDni(result.dni);
        searchPatientHistory(result.dni);
      }
      if (result.nombre && !pacienteNombre) {
        setPacienteNombre(result.nombre);
      }
      if (result.edad && !pacienteEdad) {
        setPacienteEdad(String(result.edad));
      }
      if (result.direccion && !direccion) {
        setDireccion(result.direccion);
      }

      if (result.dni) {
        const valMsg = result.valido ? 'DNI verificado con letra oficial' : 'DNI extraído';
        setScanDniFeedback(`Documento escaneado: ${result.dni}${result.nombre ? ` · ${result.nombre}` : ''} (${valMsg}).`);
      } else {
        setScanDniFeedback('No se pudo detectar el DNI con suficiente claridad. Revisa la foto e inténtalo de nuevo.');
      }
      setTimeout(() => setScanDniFeedback(null), 6000);
    } catch (err) {
      console.warn('Error escaneando DNI:', err);
      setScanDniFeedback('No se pudo procesar la fotografía del documento.');
      setTimeout(() => setScanDniFeedback(null), 5000);
    } finally {
      setScanningDni(false);
    }
  };

  // Visor de cámara simulado (DniScannerModal): rellena DNI y nombre al capturar
  const [scannerOpen, setScannerOpen] = useState(false);

  const handleSimulatedCapture = ({ dni, nombre }: DniScanCapture) => {
    setPacienteDni(dni);
    setPacienteNombre(nombre);
    // Datos ficticios: no se consulta el historial clínico con ellos.
    setPatientHistory(null);
    setPastReports([]);
    setScanDniFeedback(
      `Captura simulada: ${dni} · ${nombre}. Son datos ficticios de demostración; sustitúyelos por los reales antes de guardar el parte.`
    );
    setTimeout(() => setScanDniFeedback(null), 8000);
  };

  const handleSave = async () => {
    if (!user) return;
    if (motivo.trim().length < 3) {
      setError('Describe el motivo de la asistencia.');
      return;
    }
    setSaving(true);
    setError(null);

    const isDemoSession =
      !isSupabaseConfigured ||
      user.id === 'demo-user-123' ||
      localStorage.getItem('pc-huelva-demo-active') === 'true' ||
      incidentId.startsWith('demo-') ||
      incidentId.startsWith('nuevo-') ||
      incidentId.startsWith('inc-') ||
      incidentId === 'demo-direct';

    const saveReportLocally = (targetIncId: string) => {
      try {
        const demoReport: MedicalReport = {
          id: `rep-${Date.now()}`,
          incident_id: targetIncId,
          user_id: user.id,
          paciente_nombre: pacienteNombre.trim() || null,
          paciente_edad: pacienteEdad ? parseInt(pacienteEdad, 10) : null,
          paciente_telefono: pacienteTelefono.trim() || null,
          paciente_dni: pacienteDni.trim() || null,
          direccion: direccion.trim() || null,
          motivo_asistencia: motivo.trim(),
          fc: fc ? parseInt(fc, 10) : null,
          tas: tas ? parseInt(tas, 10) : null,
          tad: tad ? parseInt(tad, 10) : null,
          spo2: spo2 ? parseInt(spo2, 10) : null,
          temperatura: temperatura ? parseFloat(temperatura) : null,
          glucemia: glucemia ? parseInt(glucemia, 10) : null,
          nivel_conciencia: (nivelConciencia as AvpuLevel) || null,
          tratamiento: tratamiento.trim() || null,
          resolucion,
          servicio_id: servicioId || null,
          vehiculo_id: vehiculoId || null,
          created_at: new Date().toISOString(),
        };

        const existing = JSON.parse(localStorage.getItem('pc-huelva-demo-reports') || '[]') as MedicalReport[];
        const filtered = existing.filter((r) => r.incident_id !== targetIncId);
        localStorage.setItem('pc-huelva-demo-reports', JSON.stringify([demoReport, ...filtered]));

        // Asegurar que la incidencia existe también en el almacenamiento local para que nunca falle
        try {
          const storedIncidents = JSON.parse(localStorage.getItem('pc-huelva-demo-incidents') || '[]');
          const existingInc = storedIncidents.find((i: { id: string }) => i.id === targetIncId);
          if (!existingInc) {
            const newIncident = {
              id: targetIncId,
              user_id: user.id,
              categoria: 'sanitaria',
              descripcion:
                incidentDescription && !incidentDescription.includes('demo') && incidentDescription !== 'Asistencia sanitaria activa'
                  ? incidentDescription
                  : `Asistencia Sanitaria - ${motivo.trim().slice(0, 100)}`,
              latitud: null,
              longitud: null,
              foto_path: null,
              estado: 'abierta',
              created_at: new Date().toISOString(),
              report_count: 1,
              servicio_id: servicioId || null,
            };
            localStorage.setItem('pc-huelva-demo-incidents', JSON.stringify([newIncident, ...storedIncidents]));
          } else {
            existingInc.report_count = (existingInc.report_count ?? 0) + 1;
            localStorage.setItem('pc-huelva-demo-incidents', JSON.stringify(storedIncidents));
          }
        } catch (incErr) {
          console.warn('Error guardando incidencia demo:', incErr);
        }
      } catch (e) {
        console.warn('Error guardando en reportes locales:', e);
      }
    };

    // 1. Guardar localmente de inmediato (infalible e instantáneo)
    saveReportLocally(incidentId);

    if (isDemoSession) {
      setSuccess(true);
      setSaving(false);
      setTimeout(() => onSaved(), 500);
      return;
    }

    // 2. Modo conectado a Supabase con límite de tiempo de 3 segundos para no bloquear la app
    try {
      const syncTask = async () => {
        let targetIncidentId = incidentId;
        let incidentExistsInDb = false;

        if (isValidUuid(targetIncidentId)) {
          try {
            const { data: found } = await supabase
              .from('incidencias_operativas')
              .select('id')
              .eq('id', targetIncidentId)
              .maybeSingle();
            if (found?.id) {
              incidentExistsInDb = true;
            }
          } catch {
            incidentExistsInDb = false;
          }
        }

        if (!incidentExistsInDb) {
          try {
            const descText =
              incidentDescription && !incidentDescription.includes('demo') && incidentDescription !== 'Asistencia sanitaria activa'
                ? incidentDescription
                : `Asistencia Sanitaria - ${motivo.trim().slice(0, 100)}`;

            const { data: newInc } = await supabase
              .from('incidencias_operativas')
              .insert({
                user_id: user.id,
                categoria: 'sanitaria',
                descripcion: descText,
                estado: 'abierta',
                latitud: null,
                longitud: null,
                foto_path: null,
              })
              .select('id')
              .single();

            if (newInc?.id) {
              targetIncidentId = newInc.id;
              incidentExistsInDb = true;
            }
          } catch {
            // Continúa sin romper
          }
        }

        if (incidentExistsInDb) {
          const cleanServicioId = isValidUuid(servicioId) ? servicioId : null;
          const cleanVehiculoId = isValidUuid(vehiculoId) ? vehiculoId : null;

          const payload: Record<string, unknown> = {
            incident_id: targetIncidentId,
            user_id: user.id,
            motivo_asistencia: motivo.trim(),
            resolucion,
            paciente_nombre: pacienteNombre.trim() || null,
            paciente_edad: pacienteEdad ? parseInt(pacienteEdad, 10) : null,
            paciente_telefono: pacienteTelefono.trim() || null,
            paciente_dni: pacienteDni.trim() || null,
            direccion: direccion.trim() || null,
            fc: fc ? parseInt(fc, 10) : null,
            tas: tas ? parseInt(tas, 10) : null,
            tad: tad ? parseInt(tad, 10) : null,
            spo2: spo2 ? parseInt(spo2, 10) : null,
            temperatura: temperatura ? parseFloat(temperatura) : null,
            glucemia: glucemia ? parseInt(glucemia, 10) : null,
            nivel_conciencia: nivelConciencia || null,
            tratamiento: tratamiento.trim() || null,
            servicio_id: cleanServicioId,
            vehiculo_id: cleanVehiculoId,
          };

          await supabase.from('partes_sanitarios').insert(payload);
        }
      };

      const timeoutTask = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Sincronización en background')), 3000)
      );

      await Promise.race([syncTask(), timeoutTask]);
    } catch (syncErr) {
      console.warn('Sincronización remota pospuesta, parte seguro en local:', syncErr);
    }

    setSuccess(true);
    setSaving(false);
    setTimeout(() => onSaved(), 500);
  };

  if (success) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-black/50 p-4 animate-fade-in" style={{ zIndex: 1200 }}>
        <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-6 text-center">
          <div className="w-14 h-14 rounded-full bg-success-100 flex items-center justify-center mx-auto mb-3"><Stethoscope size={28} className="text-success-600" /></div>
          <p className="text-sm font-semibold text-gray-900">Parte guardado correctamente</p>
          <p className="text-xs text-gray-400 mt-1">El parte queda asociado a la incidencia y visible para el equipo.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 flex items-start justify-center bg-black/50 p-3 overflow-y-auto animate-fade-in" style={{ zIndex: 1200 }}>
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full my-4 flex flex-col max-h-[92vh]">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl z-10">
          <div className="flex items-center gap-2"><div className="w-9 h-9 rounded-xl bg-yellow-100 text-yellow-700 flex items-center justify-center"><Stethoscope size={20} /></div><div><h2 className="text-sm font-bold text-gray-900">Parte de Asistencia Sanitaria</h2><p className="text-[11px] text-gray-400 line-clamp-1">{incidentDescription}</p></div></div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100 text-gray-500"><ArrowLeft size={18} /></button>
        </div>

        <div className="overflow-y-auto px-4 py-4 space-y-5">
          {error && <div className="text-sm text-error-600 bg-error-50 rounded-xl px-3 py-2">{error}</div>}

          {showAssistant ? (
            <div className="rounded-2xl border-2 border-primary-300 bg-primary-50/40 p-4 space-y-3.5 shadow-xs animate-slide-down">
              <div className="flex items-center justify-between border-b border-primary-200/60 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-primary-600 text-white flex items-center justify-center shadow-xs">
                    <Bot size={18} />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm font-bold text-primary-950">Asistente Clínico ERC 2025</h3>
                      <span className="text-[10px] bg-primary-100 text-primary-800 font-semibold px-2 py-0.5 rounded-full border border-primary-200">
                        Gemini Flash
                      </span>
                    </div>
                    <p className="text-[11px] text-primary-700">Triage interactivo, preguntas dirigidas y volcado automático</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleResetAssistant}
                    title="Reiniciar evaluación"
                    className="p-1.5 text-gray-500 hover:text-primary-700 rounded-lg hover:bg-primary-100/60 transition-colors"
                  >
                    <RefreshCw size={15} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAssistant(false)}
                    className="text-xs text-gray-500 hover:text-gray-700 px-2 py-1 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    Cerrar
                  </button>
                </div>
              </div>

              {/* Selector de modo dual: Hablar (Voz) o Escribir (Texto) */}
              <div className="flex items-center justify-between gap-2 bg-white p-1.5 rounded-xl border border-primary-200 shadow-xs flex-wrap">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => {
                      if (isListening) toggleListening();
                      setAssistantMode('text');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      assistantMode === 'text'
                        ? 'bg-primary-600 text-white shadow-xs'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <MessageSquare size={14} />
                    <span>Modo Escribir</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAssistantMode('voice');
                      if (!isListening) toggleListening();
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      assistantMode === 'voice'
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'text-gray-600 hover:text-red-700 hover:bg-red-50'
                    }`}
                  >
                    <Mic size={14} className={isListening ? 'animate-bounce' : ''} />
                    <span>Modo Hablar {isListening ? '• Grabando' : ''}</span>
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setTtsEnabled(!ttsEnabled)}
                    title={ttsEnabled ? 'Lectura por voz activada' : 'Lectura por voz desactivada'}
                    className={`px-2.5 py-1 rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer border ${
                      ttsEnabled
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-bold'
                        : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    {ttsEnabled ? <Volume2 size={14} className="text-emerald-600" /> : <VolumeX size={14} />}
                    <span className="text-[11px]">{ttsEnabled ? 'Voz activa' : 'Silencio'}</span>
                  </button>
                </div>
              </div>

              {isRedAlert && (
                <div className="bg-red-600 text-white rounded-xl p-3 flex items-start gap-2.5 shadow-sm animate-pulse">
                  <AlertTriangle size={18} className="shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-bold tracking-wide">[LLAMADA AL 112/061 - PRIORIDAD ROJA]</p>
                    <p className="text-[11px] text-red-100 leading-tight mt-0.5">
                      Criterio de alarma o compromiso vital detectado. Detén la anamnesis no esencial y solicita ambulancia medicalizada UVI de inmediato.
                    </p>
                  </div>
                </div>
              )}

              {lastExtractedAlert && (
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl px-3 py-2 text-xs flex items-center gap-2 animate-fade-in">
                  <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                  <span className="font-medium text-[11px]">{lastExtractedAlert}</span>
                </div>
              )}

              {speechError && (
                <div className="bg-amber-50 border border-amber-200 text-amber-900 rounded-xl px-3 py-2 text-xs flex items-center gap-2 animate-fade-in">
                  <AlertTriangle size={15} className="text-amber-600 shrink-0" />
                  <span className="font-medium text-[11px]">{speechError}</span>
                </div>
              )}

              {/* Barra de Protocolos Ultrarrápidos ERC 2025 */}
              <div className="bg-gradient-to-r from-primary-900 to-primary-950 p-3 rounded-xl text-white space-y-2 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-yellow-300">
                    <Sparkles size={14} />
                    <span>Protocolos Ultrarrápidos ERC 2025 (Respuesta instantánea)</span>
                  </div>
                  <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full text-white/90 font-mono font-medium">
                    &lt;0.05s
                  </span>
                </div>
                <p className="text-[11px] text-primary-200 leading-tight">
                  Haz clic en cualquier patología para activar la pauta clínica inmediatamente sin demoras y rellenar el parte:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-0.5">
                  {PROTOCOLS_LIST.map((proto) => (
                    <button
                      key={proto.id}
                      type="button"
                      onClick={() => handleRunFastProtocol(proto.id)}
                      className="px-2 py-1.5 rounded-lg bg-white/10 hover:bg-white/25 active:scale-98 text-white text-left transition-all border border-white/10 group cursor-pointer"
                    >
                      <span className="text-[11px] font-bold block truncate text-yellow-200 group-hover:text-yellow-100">{proto.label}</span>
                      <span className="text-[9px] text-primary-200 block truncate group-hover:text-white">{proto.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Chat Messages */}
              <div className="bg-white rounded-xl border border-primary-100 p-3 max-h-72 overflow-y-auto space-y-3">
                {messages.map((m) => (
                  <div key={m.id} className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}>
                    <div
                      className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                        m.sender === 'user'
                          ? 'bg-primary-600 text-white rounded-br-xs'
                          : m.isRedPriority
                          ? 'bg-red-50 text-red-950 border border-red-200 rounded-bl-xs'
                          : 'bg-gray-50 text-gray-800 border border-gray-100 rounded-bl-xs'
                      }`}
                    >
                      {m.sender === 'assistant' && (
                        <div className="flex items-center gap-1.5 mb-1 text-[10px] font-bold text-primary-700">
                          <Sparkles size={11} /> Protocolo ERC 2025
                        </div>
                      )}
                      <p className="whitespace-pre-wrap">{m.text}</p>
                      {m.extracted && (
                        <div className="mt-2 pt-1.5 border-t border-gray-200/60 flex flex-wrap gap-1 text-[10px]">
                          {m.extracted.fc && <span className="bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-mono font-medium">FC: {m.extracted.fc} lpm</span>}
                          {m.extracted.sat && <span className="bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-mono font-medium">SpO2: {m.extracted.sat}%</span>}
                          {m.extracted.tas && <span className="bg-purple-100 text-purple-800 px-1.5 py-0.5 rounded font-mono font-medium">TA: {m.extracted.tas}/{m.extracted.tad ?? '—'}</span>}
                          {m.extracted.temperatura && <span className="bg-orange-100 text-orange-800 px-1.5 py-0.5 rounded font-mono font-medium">Tª: {m.extracted.temperatura}°C</span>}
                          {m.extracted.glucemia && <span className="bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-mono font-medium">Glu: {m.extracted.glucemia}</span>}
                          {m.extracted.nivelConciencia && <span className="bg-gray-200 text-gray-800 px-1.5 py-0.5 rounded font-mono font-medium">AVPU: {m.extracted.nivelConciencia}</span>}
                        </div>
                      )}
                    </div>
                    <span className="text-[10px] text-gray-400 mt-0.5 px-1">{m.timestamp}</span>
                  </div>
                ))}
                {assistantLoading && (
                  <div className="flex items-center gap-2 text-xs text-primary-600 bg-primary-50/80 rounded-xl px-3 py-2 w-fit">
                    <Spinner size={14} />
                    <span className="text-[11px] font-medium">Consultando asistente clínico ERC 2025 con Gemini...</span>
                  </div>
                )}
                <div ref={chatBottomRef} />
              </div>

              {/* Botones de sugerencias rápidas */}
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => handleSendAssistantMessage('Escena segura, paciente consciente.')}
                  disabled={assistantLoading}
                  className="px-2.5 py-1 rounded-lg text-[11px] bg-white border border-primary-200 text-primary-700 hover:bg-primary-50 transition-colors font-medium"
                >
                  Escena segura
                </button>
                <button
                  type="button"
                  onClick={() => handleSendAssistantMessage('Refiere dolor opresivo en el pecho irradiado al brazo izquierdo.')}
                  disabled={assistantLoading}
                  className="px-2.5 py-1 rounded-lg text-[11px] bg-white border border-primary-200 text-primary-700 hover:bg-primary-50 transition-colors font-medium"
                >
                  Dolor torácico (IAM)
                </button>
                <button
                  type="button"
                  onClick={() => handleSendAssistantMessage('Asimetría facial y dificultad para hablar (FAST+).')}
                  disabled={assistantLoading}
                  className="px-2.5 py-1 rounded-lg text-[11px] bg-white border border-primary-200 text-primary-700 hover:bg-primary-50 transition-colors font-medium"
                >
                  Sospecha de ictus
                </button>
                <button
                  type="button"
                  onClick={() => handleSendAssistantMessage('Constantes tomadas: FC 85 lpm, TAS 120, TAD 80, SpO2 98%, Temp 36.5, Glucemia 95.')}
                  disabled={assistantLoading}
                  className="px-2.5 py-1 rounded-lg text-[11px] bg-white border border-primary-200 text-primary-700 hover:bg-primary-50 transition-colors font-medium"
                >
                  Constantes normales
                </button>
                <button
                  type="button"
                  onClick={() => handleSendAssistantMessage('TAS 80 mmHg, TAD 50 mmHg, FC 125 lpm, palidez extrema.')}
                  disabled={assistantLoading}
                  className="px-2.5 py-1 rounded-lg text-[11px] bg-red-50 border border-red-200 text-red-700 hover:bg-red-100 transition-colors font-medium"
                >
                  TAS &lt; 90 (Shock)
                </button>
              </div>

              {/* ÁREA DE ENTRADA SEGÚN EL MODO (HABLAR O ESCRIBIR) */}
              {assistantMode === 'voice' ? (
                <div className="p-3.5 bg-red-50/70 rounded-xl border border-red-200 space-y-2.5 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${isListening ? 'bg-red-600 animate-ping' : 'bg-gray-400'}`} />
                      <span className="text-xs font-bold text-red-950">
                        {isListening ? '🎙️ Escuchando tu voz en tiempo real...' : 'Micrófono en espera'}
                      </span>
                    </div>
                    <span className="text-[10px] text-red-700">Dictado en español</span>
                  </div>

                  <p className="text-[11px] text-gray-600 leading-snug">
                    {isListening
                      ? 'Habla con normalidad. Explica los síntomas de la víctima, las constantes observadas o las maniobras aplicadas.'
                      : 'Pulsa el botón rojo para comenzar a hablar con el asistente clínico.'}
                  </p>

                  {assistantInput && (
                    <div className="p-2 bg-white rounded-lg border border-red-200 text-xs text-gray-800">
                      <span className="text-[10px] font-bold text-gray-400 block uppercase">Transcripción detectada:</span>
                      <p className="font-medium text-gray-900 mt-0.5">{assistantInput}</p>
                    </div>
                  )}

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={toggleListening}
                      className={`btn text-xs py-2 px-3.5 flex items-center gap-2 font-bold cursor-pointer transition-all ${
                        isListening
                          ? 'bg-red-600 hover:bg-red-700 text-white animate-pulse'
                          : 'bg-red-100 text-red-800 hover:bg-red-200'
                      }`}
                    >
                      {isListening ? <MicOff size={15} /> : <Mic size={15} />}
                      <span>{isListening ? 'Pausar micrófono' : 'Pulsar para hablar'}</span>
                    </button>

                    {assistantInput.trim() && (
                      <button
                        type="button"
                        onClick={() => handleSendAssistantMessage()}
                        disabled={assistantLoading}
                        className="btn-primary text-xs py-2 px-4 flex items-center gap-1.5 cursor-pointer ml-auto font-bold"
                      >
                        {assistantLoading ? <Spinner size={14} /> : <Send size={14} />}
                        <span>Enviar al asistente</span>
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                /* Modo Escribir con botón de dictado por voz integrado */
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendAssistantMessage();
                  }}
                  className="flex gap-2 items-center"
                >
                  <div className="relative flex-1">
                    <input
                      type="text"
                      className="input text-xs py-2 pr-9 pl-3 w-full"
                      value={assistantInput}
                      onChange={(e) => setAssistantInput(e.target.value)}
                      placeholder={isListening ? 'Escuchando tu voz...' : 'Escribe síntomas, constantes o respuesta del paciente...'}
                      disabled={assistantLoading}
                    />
                    <button
                      type="button"
                      onClick={toggleListening}
                      title={isListening ? 'Detener dictado por voz' : 'Dictar por voz'}
                      className={`absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 rounded-lg transition-colors cursor-pointer ${
                        isListening
                          ? 'text-red-600 bg-red-100 animate-pulse'
                          : 'text-gray-400 hover:text-red-600 hover:bg-gray-100'
                      }`}
                    >
                      <Mic size={15} />
                    </button>
                  </div>

                  <button
                    type="submit"
                    disabled={assistantLoading || !assistantInput.trim()}
                    className="btn-primary text-xs px-3.5 py-2 shrink-0 cursor-pointer"
                  >
                    {assistantLoading ? <Spinner size={14} /> : <Send size={15} />}
                  </button>
                </form>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => {
                setShowAssistant(true);
                if (messages.length === 0) handleResetAssistant();
              }}
              className="w-full rounded-xl bg-primary-50 border border-primary-200 px-4 py-2.5 flex items-center justify-center gap-2 text-sm font-medium text-primary-700 hover:bg-primary-100 transition-colors shadow-xs"
            >
              <Sparkles size={17} className="text-primary-600" />
              <span>Activar Asistente Clínico Interactivo ERC 2025 (Google Gemini)</span>
            </button>
          )}

          {patientHistory && (
            <div className="rounded-xl bg-blue-50 border border-blue-200 p-3">
              <div className="flex items-center gap-2 mb-1"><History size={16} className="text-blue-600" /><p className="text-xs font-bold text-blue-900">Historial del paciente encontrado</p></div>
              {patientHistory.resumen && <p className="text-xs text-blue-700 whitespace-pre-wrap mt-1 max-h-24 overflow-y-auto">{patientHistory.resumen}</p>}
              {pastReports.length > 0 && <p className="text-[11px] text-blue-500 mt-1">{pastReports.length} asistencia(s) anterior(es) registrada(s)</p>}
            </div>
          )}
          {historyLoading && <div className="flex items-center gap-2 text-xs text-gray-400"><Spinner size={14} /> Buscando historial del paciente…</div>}

          <Section title="Datos del paciente" icon={User}>
            <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
              <span className="text-xs text-gray-500 font-medium">Filiación de la persona asistida</span>
              <button
                type="button"
                onClick={() => dniFileInputRef.current?.click()}
                disabled={scanningDni}
                className="text-xs bg-primary-50 hover:bg-primary-100 text-primary-800 px-3 py-1.5 rounded-lg border border-primary-200 flex items-center gap-1.5 cursor-pointer font-bold shadow-xs transition-colors"
                title="Capturar o subir fotografía del DNI para auto-rellenar los datos con OCR"
              >
                <Camera size={14} className="text-primary-700" />
                <span>{scanningDni ? 'Escaneando documento…' : 'Escanear DNI / Tarjeta (Cámara)'}</span>
              </button>
              <input
                ref={dniFileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleScanDniFile}
                className="hidden"
              />
            </div>

            {scanDniFeedback && (
              <div className="mb-3 p-2.5 rounded-xl bg-primary-50 border border-primary-200 text-xs text-primary-900 flex items-center gap-2">
                <CheckCircle2 size={16} className="text-primary-600 shrink-0" />
                <span className="font-medium">{scanDniFeedback}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-[1.7fr_0.6fr_1fr] gap-3">
              <div>
                <label className="label">Nombre</label>
                <div className="flex gap-2">
                  <input className="input min-w-0" value={pacienteNombre} onChange={(e) => setPacienteNombre(e.target.value)} placeholder="Nombre del paciente" />
                  <button
                    type="button"
                    onClick={() => setScannerOpen(true)}
                    className="shrink-0 w-11 rounded-xl border border-primary-200 bg-primary-50 text-primary-700 hover:bg-primary-100 active:scale-95 transition-all flex items-center justify-center cursor-pointer"
                    title="Escanear DNI / Tarjeta Sanitaria con la cámara"
                    aria-label="Escanear DNI o tarjeta sanitaria para rellenar el nombre"
                  >
                    <Camera size={18} />
                  </button>
                </div>
              </div>
              <div><label className="label">Edad</label><input type="number" inputMode="numeric" min={0} max={130} className="input" value={pacienteEdad} onChange={(e) => setPacienteEdad(e.target.value)} placeholder="Años" /></div>
              <div><label className="label">Teléfono</label><input type="tel" inputMode="tel" className="input" value={pacienteTelefono} onChange={(e) => setPacienteTelefono(e.target.value)} placeholder="600 123 456" /></div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
              <div>
                <label className="label">DNI / NIE</label>
                <div className="flex gap-2">
                  <input className="input min-w-0" value={pacienteDni} onChange={(e) => { setPacienteDni(e.target.value); }} onBlur={(e) => searchPatientHistory(e.target.value)} placeholder="00000000X" />
                  <button
                    type="button"
                    onClick={() => setScannerOpen(true)}
                    className="shrink-0 w-11 rounded-xl border border-primary-200 bg-primary-50 text-primary-700 hover:bg-primary-100 active:scale-95 transition-all flex items-center justify-center cursor-pointer"
                    title="Escanear DNI / Tarjeta Sanitaria con la cámara"
                    aria-label="Escanear DNI o tarjeta sanitaria para rellenar el DNI"
                  >
                    <Camera size={18} />
                  </button>
                </div>
              </div>
              <div><label className="label">Dirección completa</label><input className="input" value={direccion} onChange={(e) => setDireccion(e.target.value)} placeholder="Calle, número, piso, ciudad" /></div>
            </div>
            {pacienteDni.trim().length >= 5 && !patientHistory && !historyLoading && <p className="text-[11px] text-gray-400 mt-1">Al salir del campo DNI se buscará automáticamente el historial del paciente.</p>}
          </Section>

          <Section title="Servicio y vehículo" icon={MapPin}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="label">Servicio preventivo</label>
                <select className="input" value={servicioId} onChange={(e) => { setServicioId(e.target.value); setVehiculoId(''); }}>
                  <option value="">Sin servicio asociado</option>
                  {services.map((s) => <option key={s.id} value={s.id}>{s.titulo}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Vehículo que atiende</label>
                <select className="input" value={vehiculoId} onChange={(e) => setVehiculoId(e.target.value)} disabled={!servicioId}>
                  <option value="">{servicioId ? 'Sin vehículo asignado' : 'Selecciona un servicio primero'}</option>
                  {vehicles.map((v) => <option key={v.id} value={v.id}>{v.nombre} ({vehicleTypeLabels[v.tipo] ?? v.tipo})</option>)}
                </select>
                {servicioId && vehicles.length === 0 && <p className="text-[11px] text-gray-400 mt-1">No hay vehículos asignados a este servicio. Asigna vehículos desde el detalle del servicio.</p>}
              </div>
            </div>
          </Section>

          <Section title="Motivo de la asistencia" icon={Activity}>
            <textarea className="input min-h-[72px] resize-none" maxLength={500} value={motivo} onChange={(e) => setMotivo(e.target.value)} placeholder="Anamnesis breve: qué ocurre, síntomas, mecanismo de lesión…" />
            <p className="text-[11px] text-gray-400 text-right mt-1">{motivo.length}/500</p>
          </Section>

          <Section title="Constantes vitales" icon={HeartPulse}>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <VitalFieldInput label="FC (lpm)" value={fc} onChange={setFc} min={0} max={250} icon={<HeartPulse size={14} />} />
              <VitalFieldInput label="TAS (mmHg)" value={tas} onChange={setTas} min={0} max={300} />
              <VitalFieldInput label="TAD (mmHg)" value={tad} onChange={setTad} min={0} max={200} />
              <VitalFieldInput label="SpO2 (%)" value={spo2} onChange={setSpo2} min={0} max={100} />
              <VitalFieldInput label="Temp. (°C)" value={temperatura} onChange={setTemperatura} min={25} max={45} step="0.1" isFloat icon={<Thermometer size={14} />} />
              <VitalFieldInput label="Glucemia (mg/dl)" value={glucemia} onChange={setGlucemia} min={0} max={999} icon={<Droplet size={14} />} />
            </div>
            <div className="mt-3"><label className="label">Nivel de conciencia (AVPU)</label><div className="grid grid-cols-4 gap-2">{avpuOptions.map((opt) => <button key={opt.value} type="button" onClick={() => setNivelConciencia(opt.value)} className={`rounded-xl border-2 py-2.5 text-center transition-all ${nivelConciencia === opt.value ? 'border-yellow-400 bg-yellow-50 text-yellow-900' : 'border-gray-200 bg-white text-gray-500 hover:border-gray-300'}`}><span className="text-lg font-bold block">{opt.label}</span><span className="text-[10px] leading-tight block mt-0.5">{opt.description}</span></button>)}</div></div>
          </Section>

          <Section title="Tratamiento aplicado" icon={Stethoscope}>
            <textarea className="input min-h-[72px] resize-none" maxLength={500} value={tratamiento} onChange={(e) => setTratamiento(e.target.value)} placeholder="Primeros auxilios, medicación, maniobras realizadas…" />
          </Section>

          <Section title="Destino / Resolución" icon={Activity}>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">{resolutionOptions.map((opt) => <button key={opt.value} type="button" onClick={() => setResolucion(opt.value)} className={`rounded-xl border-2 px-3 py-3 text-center transition-all ${resolucion === opt.value ? opt.color === 'success' ? 'border-success-500 bg-success-50 text-success-800' : opt.color === 'warning' ? 'border-warning-400 bg-warning-50 text-warning-900' : 'border-error-500 bg-error-50 text-error-800' : 'border-gray-200 bg-white text-gray-500 hover:border-gray-300'}`}><span className="text-sm font-semibold">{opt.label}</span></button>)}</div>
          </Section>
        </div>

        <div className="px-4 py-3 border-t border-gray-100 flex gap-3 sticky bottom-0 bg-white rounded-b-2xl">
          <button onClick={onClose} className="btn-outline flex-1">Cancelar</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary flex-1">{saving ? <Spinner size={16} /> : <Save size={17} />} {saving ? 'Guardando…' : 'Guardar parte'}</button>
        </div>
      </div>

      <DniScannerModal open={scannerOpen} onClose={() => setScannerOpen(false)} onCapture={handleSimulatedCapture} />
    </div>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: typeof User; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-gray-500 mb-2"><Icon size={15} /> {title}</h3>
      {children}
    </div>
  );
}

function VitalFieldInput({ label, value, onChange, min, max, step, isFloat, icon }: { label: string; value: string; onChange: (v: string) => void; min: number; max: number; step?: string; isFloat?: boolean; icon?: React.ReactNode }) {
  return (
    <div>
      <label className="label flex items-center gap-1">{icon} {label}</label>
      <input
        type="number"
        inputMode="decimal"
        className="input"
        value={value}
        min={min}
        max={max}
        step={step ?? '1'}
        onChange={(e) => {
          const v = e.target.value;
          if (v === '') { onChange(''); return; }
          const parsed = isFloat ? parseFloat(v) : parseInt(v);
          if (isNaN(parsed) || parsed < min || parsed > max) return;
          onChange(v);
        }}
        placeholder="—"
      />
    </div>
  );
}

export function MedicalReportBadge({ count }: { count: number }) {
  if (count === 0) return null;
  return <span className="badge bg-warning-100 text-warning-800"><Stethoscope size={11} /> {count} parte{count > 1 ? 's' : ''}</span>;
}
