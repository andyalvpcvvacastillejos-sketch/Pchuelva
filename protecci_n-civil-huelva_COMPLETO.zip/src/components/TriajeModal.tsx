import { useState, useEffect, useMemo } from 'react';
import {
  AlertTriangle,
  Flame,
  Users,
  CheckCircle2,
  Trash2,
  Download,
  Share2,
  ArrowRight,
  Activity,
  Plus,
  Stethoscope,
  X,
  Clock,
  ShieldAlert,
  Search,
  Copy,
  ChevronRight,
} from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Badge } from '@/components/ui/Badge';
import {
  getTriageRecords,
  saveTriageRecord,
  deleteTriageRecord,
  clearAllTriageRecords,
  subscribeToTriageUpdates,
  calculateTriageStats,
  exportTriageToCsv,
  triageCategoryConfig,
  type TriageCategory,
  type TriageAgeGroup,
  type TriageGender,
  type TriageRecord,
} from '@/lib/triageStorage';
import { useAuth } from '@/context/AuthContext';

interface TriajeModalProps {
  open: boolean;
  onClose: () => void;
  incidentTitle?: string;
  onOpenParteSanitario?: (triage: TriageRecord) => void;
}

export function TriajeModal({ open, onClose, incidentTitle, onOpenParteSanitario }: TriajeModalProps) {
  const { profile } = useAuth();
  const canManage = profile?.role === 'admin_tecnico' || profile?.role === 'coordinador';

  const [records, setRecords] = useState<TriageRecord[]>(getTriageRecords());
  const [activeTab, setActiveTab] = useState<'lista' | 'nuevo_rapido' | 'asistente_start'>('lista');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [copied, setCopied] = useState(false);

  // Form states para nuevo paciente triado
  const [categoria, setCategoria] = useState<TriageCategory>('rojo');
  const [edadGrupo, setEdadGrupo] = useState<TriageAgeGroup>('adulto');
  const [genero, setGenero] = useState<TriageGender>('varon');
  const [lesionPrincipal, setLesionPrincipal] = useState('');
  const [ubicacionNido, setUbicacionNido] = useState('Puesto de Socorro Avanzado (PMA)');
  const [destinoTraslado, setDestinoTraslado] = useState('');
  const [observaciones, setObservaciones] = useState('');

  // Estados del asistente START guiado
  const [startStep, setStartStep] = useState<1 | 2 | 3 | 4>(1);
  const [startDeambula, setStartDeambula] = useState<boolean | null>(null);
  const [startRespira, setStartRespira] = useState<boolean | null>(null);
  const [startFrAlta, setStartFrAlta] = useState<boolean | null>(null);
  const [startPerfusionMala, setStartPerfusionMala] = useState<boolean | null>(null);
  const [startObedece, setStartObedece] = useState<boolean | null>(null);

  useEffect(() => {
    setRecords(getTriageRecords());
    const unsub = subscribeToTriageUpdates(() => {
      setRecords(getTriageRecords());
    });
    return unsub;
  }, []);

  const stats = useMemo(() => calculateTriageStats(records), [records]);

  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      if (filterCategory !== 'all' && r.categoria !== filterCategory) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchesLesion = r.lesion_principal.toLowerCase().includes(q);
        const matchesNido = (r.ubicacion_nido || '').toLowerCase().includes(q);
        const matchesTag = `#${String(r.numero_etiqueta)}`.includes(q);
        return matchesLesion || matchesNido || matchesTag;
      }
      return true;
    });
  }, [records, filterCategory, searchTerm]);

  const resetStartWizard = () => {
    setStartStep(1);
    setStartDeambula(null);
    setStartRespira(null);
    setStartFrAlta(null);
    setStartPerfusionMala(null);
    setStartObedece(null);
  };

  const handleCreateFastTriage = (cat: TriageCategory) => {
    const defaultLesion =
      cat === 'rojo'
        ? 'Compromiso vital inmediato / Inestabilidad hemodinámica'
        : cat === 'amarillo'
        ? 'Traumatismo severo o quemadura sin shock'
        : cat === 'verde'
        ? 'Lesión leve deambulante'
        : 'Víctima sin signos vitales';

    saveTriageRecord({
      categoria: cat,
      edad_grupo: edadGrupo,
      genero,
      lesion_principal: lesionPrincipal.trim() || defaultLesion,
      deambula: cat === 'verde',
      obedece_ordenes: cat !== 'rojo' && cat !== 'negro',
      ubicacion_nido: ubicacionNido.trim() || 'Nido de Heridos',
      destino_traslado: destinoTraslado.trim() || null,
      observaciones: observaciones.trim() || null,
      triado_por: profile ? `${profile.nombre} ${profile.apellidos?.[0] || ''}` : 'Dotación Sanitaria',
    });

    setLesionPrincipal('');
    setObservaciones('');
    setActiveTab('lista');
  };

  const handleFinishStartWizard = (derivedCategory: TriageCategory) => {
    saveTriageRecord({
      categoria: derivedCategory,
      edad_grupo: edadGrupo,
      genero,
      lesion_principal: lesionPrincipal.trim() || `Clasificado por protocolo START: ${triageCategoryConfig[derivedCategory].label}`,
      deambula: startDeambula === true,
      frecuencia_respiratoria: startFrAlta === true ? 35 : startRespira === false ? 0 : 20,
      relleno_capilar_seg: startPerfusionMala === true ? 3 : 1,
      obedece_ordenes: startObedece === true,
      ubicacion_nido: ubicacionNido.trim() || 'Nido de Heridos',
      destino_traslado: destinoTraslado.trim() || null,
      observaciones: observaciones.trim() || null,
      triado_por: profile ? `${profile.nombre}` : 'Rescatista START',
    });

    resetStartWizard();
    setLesionPrincipal('');
    setObservaciones('');
    setActiveTab('lista');
  };

  const handleCopySummary = () => {
    const text = `🚨 [INFORME TRIAJE IMV - PROTECCIÓN CIVIL HUELVA]
Incidente: ${incidentTitle || 'Emergencia / Dispositivo'}
Total víctimas clasificadas: ${stats.total}
🔴 T1 ROJO (Inmediato): ${stats.rojos}
🟡 T2 AMARILLO (Demorado): ${stats.amarillos}
🟢 T3 VERDE (Leve): ${stats.verdes}
⚫ T0 NEGRO (Fallecido): ${stats.negros}
Ambulancias UVI (SVA) requeridas: ${stats.uviRequeridas}
Ambulancias SVB requeridas: ${stats.svbRequeridas}
Hora reporte: ${new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <Modal open={open} onClose={onClose} title="Triaje Táctico IMV (Protocolo START)" size="lg">
      <div className="space-y-4">
        {/* Banner de situación para el Puesto de Mando */}
        <div className="rounded-2xl bg-gradient-to-r from-slate-900 to-primary-950 p-4 text-white shadow-md">
          <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
            <div className="flex items-center gap-2">
              <ShieldAlert className="text-red-400" size={20} />
              <p className="text-sm font-bold uppercase tracking-wide">
                Puesto de Mando Avanzado (PMA) · Clasificación de Catástrofe
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopySummary}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                title="Copiar texto resumen para transmitir al 112"
              >
                {copied ? <CheckCircle2 size={13} className="text-green-400" /> : <Copy size={13} />}
                <span>{copied ? 'Copiado al portapapeles' : 'Copiar para 112'}</span>
              </button>
              <button
                onClick={() => exportTriageToCsv(records, incidentTitle)}
                className="px-2.5 py-1 rounded-lg bg-primary-600 hover:bg-primary-500 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Download size={13} />
                <span>Exportar CSV</span>
              </button>
            </div>
          </div>

          {/* Marcadores de Triaje en tiempo real */}
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="bg-red-950/70 border border-red-500/50 rounded-xl p-2.5">
              <span className="text-[10px] font-bold uppercase text-red-300">T1 ROJO</span>
              <p className="text-2xl font-black text-red-400">{stats.rojos}</p>
              <span className="text-[10px] text-red-200">Inmediato</span>
            </div>
            <div className="bg-amber-950/70 border border-amber-500/50 rounded-xl p-2.5">
              <span className="text-[10px] font-bold uppercase text-amber-300">T2 AMARILLO</span>
              <p className="text-2xl font-black text-amber-400">{stats.amarillos}</p>
              <span className="text-[10px] text-amber-200">Demorado</span>
            </div>
            <div className="bg-emerald-950/70 border border-emerald-500/50 rounded-xl p-2.5">
              <span className="text-[10px] font-bold uppercase text-emerald-300">T3 VERDE</span>
              <p className="text-2xl font-black text-emerald-400">{stats.verdes}</p>
              <span className="text-[10px] text-emerald-200">Leve</span>
            </div>
            <div className="bg-slate-800/80 border border-slate-600/50 rounded-xl p-2.5">
              <span className="text-[10px] font-bold uppercase text-slate-300">T0 NEGRO</span>
              <p className="text-2xl font-black text-slate-200">{stats.negros}</p>
              <span className="text-[10px] text-slate-400">Fallecido</span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between text-xs text-slate-300 border-t border-white/10 pt-2 flex-wrap gap-1">
            <span>
              Total clasificados: <strong className="text-white">{stats.total}</strong> pacientes
            </span>
            <span className="bg-red-500/20 text-red-300 px-2 py-0.5 rounded-md border border-red-500/30">
              Necesidad estimada 112: <strong>{stats.uviRequeridas} UVIs</strong> y <strong>{stats.svbRequeridas} SVBs</strong>
            </span>
          </div>
        </div>

        {/* Pestañas de modo */}
        <div className="flex gap-2 border-b border-gray-200 pb-2">
          <button
            onClick={() => setActiveTab('lista')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'lista' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Listado de Víctimas ({records.length})
          </button>
          <button
            onClick={() => {
              setActiveTab('nuevo_rapido');
              resetStartWizard();
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
              activeTab === 'nuevo_rapido' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            <Plus size={14} />
            <span>Etiquetado Rápido 1-Tap</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('asistente_start');
              resetStartWizard();
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
              activeTab === 'asistente_start' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            <Activity size={14} />
            <span>Algoritmo START Guiado</span>
          </button>
        </div>

        {/* CONTENIDO PESTAÑA: ETIQUETADO RÁPIDO 1-TAP */}
        {activeTab === 'nuevo_rapido' && (
          <div className="card p-4 space-y-4 border-2 border-primary-200">
            <div>
              <h3 className="text-sm font-bold text-gray-900">Etiquetado Rápido de Víctima (Próximo Nº: #{records.length + 1})</h3>
              <p className="text-xs text-gray-500">
                Selecciona la categoría de triaje correspondiente con 1 solo toque.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Grupo de edad</label>
                <select className="input text-xs" value={edadGrupo} onChange={(e) => setEdadGrupo(e.target.value as TriageAgeGroup)}>
                  <option value="adulto">Adulto</option>
                  <option value="pediatrico">Pediátrico / Niño</option>
                  <option value="geriatrico">Geriátrico / Anciano</option>
                </select>
              </div>
              <div>
                <label className="label">Género</label>
                <select className="input text-xs" value={genero} onChange={(e) => setGenero(e.target.value as TriageGender)}>
                  <option value="varon">Varón</option>
                  <option value="mujer">Mujer</option>
                  <option value="desconocido">Desconocido</option>
                </select>
              </div>
            </div>

            <div>
              <label className="label">Lesión predominante o hallazgo clínico</label>
              <input
                className="input text-xs"
                value={lesionPrincipal}
                onChange={(e) => setLesionPrincipal(e.target.value)}
                placeholder="Ej. Amputación traumática de pie, quemadura de 2º grado 20%, dolor torácico..."
              />
            </div>

            <div>
              <label className="label">Ubicación asignada en nido de heridos</label>
              <input
                className="input text-xs"
                value={ubicacionNido}
                onChange={(e) => setUbicacionNido(e.target.value)}
                placeholder="Ej. Carpa Roja PMA, Puesto Socorro Plaza de las Monjas..."
              />
            </div>

            {/* BOTONES GIGANTES DE TRIAJE 1-TAP */}
            <div className="pt-2">
              <label className="label font-bold text-gray-900 mb-2 block">
                PULSA EL COLOR PARA ASIGNAR LA ETIQUETA INMEDIATAMENTE:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => handleCreateFastTriage('rojo')}
                  className="p-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-base shadow-md flex flex-col items-center justify-center gap-1 cursor-pointer transition-transform active:scale-95"
                >
                  <span className="text-xl">🔴 ROJO (T1)</span>
                  <span className="text-xs font-medium text-red-100">Prioridad Vital Inmediata</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleCreateFastTriage('amarillo')}
                  className="p-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-black text-base shadow-md flex flex-col items-center justify-center gap-1 cursor-pointer transition-transform active:scale-95"
                >
                  <span className="text-xl">🟡 AMARILLO (T2)</span>
                  <span className="text-xs font-medium text-amber-100">Grave no crítico</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleCreateFastTriage('verde')}
                  className="p-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-base shadow-md flex flex-col items-center justify-center gap-1 cursor-pointer transition-transform active:scale-95"
                >
                  <span className="text-xl">🟢 VERDE (T3)</span>
                  <span className="text-xs font-medium text-emerald-100">Leve / Deambulante</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleCreateFastTriage('negro')}
                  className="p-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-base shadow-md flex flex-col items-center justify-center gap-1 cursor-pointer transition-transform active:scale-95"
                >
                  <span className="text-xl">⚫ NEGRO (T0)</span>
                  <span className="text-xs font-medium text-slate-300">Fallecido / Sin pulso</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* CONTENIDO PESTAÑA: ASISTENTE START GUIADO */}
        {activeTab === 'asistente_start' && (
          <div className="card p-4 space-y-4 border-2 border-emerald-200">
            <div className="flex items-center justify-between border-b border-gray-100 pb-2">
              <div>
                <h3 className="text-sm font-bold text-gray-900">Árbol de Decisión START (Simple Triage And Rapid Treatment)</h3>
                <p className="text-xs text-gray-500">Paso {startStep} de 4 para la víctima #{records.length + 1}</p>
              </div>
              <button onClick={resetStartWizard} className="text-xs text-gray-400 hover:text-gray-600 underline">
                Reiniciar
              </button>
            </div>

            {/* PASO 1: DEAMBULACIÓN */}
            {startStep === 1 && (
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
                  <p className="font-bold text-sm text-blue-950">1. ¿La víctima puede caminar / deambular?</p>
                  <p className="text-xs text-blue-800 mt-1">
                    Grita al grupo: "Todo aquel que pueda caminar, diríjase hacia la zona segura / ambulancia".
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      setStartDeambula(true);
                      handleFinishStartWizard('verde');
                    }}
                    className="p-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex flex-col items-center justify-center gap-1"
                  >
                    <span>SÍ, CAMINA</span>
                    <span className="text-xs font-normal">→ Clasificar VERDE (T3)</span>
                  </button>
                  <button
                    onClick={() => {
                      setStartDeambula(false);
                      setStartStep(2);
                    }}
                    className="p-4 rounded-xl bg-slate-700 hover:bg-slate-800 text-white font-bold text-sm flex flex-col items-center justify-center gap-1"
                  >
                    <span>NO CAMINA</span>
                    <span className="text-xs font-normal">→ Evaluar Respiración</span>
                  </button>
                </div>
              </div>
            )}

            {/* PASO 2: RESPIRACIÓN */}
            {startStep === 2 && (
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
                  <p className="font-bold text-sm text-blue-950">2. ¿Respira la víctima tras abrir vía aérea (Frente-Mentón)?</p>
                  <p className="text-xs text-blue-800 mt-1">
                    Comprueba elevación torácica durante 5-10 segundos. Si no respira, no inicies RCP prolongada en catástrofe.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button
                    onClick={() => {
                      setStartRespira(false);
                      handleFinishStartWizard('negro');
                    }}
                    className="p-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs"
                  >
                    NO RESPIRA
                    <span className="block text-[11px] font-normal text-slate-300">→ Clasificar NEGRO (T0)</span>
                  </button>

                  <button
                    onClick={() => {
                      setStartRespira(true);
                      setStartFrAlta(true);
                      handleFinishStartWizard('rojo');
                    }}
                    className="p-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs"
                  >
                    RESPIRA &gt; 30 rpm (Taquipnea)
                    <span className="block text-[11px] font-normal text-red-200">→ Clasificar ROJO (T1)</span>
                  </button>

                  <button
                    onClick={() => {
                      setStartRespira(true);
                      setStartFrAlta(false);
                      setStartStep(3);
                    }}
                    className="p-3.5 rounded-xl bg-primary-700 hover:bg-primary-800 text-white font-bold text-xs"
                  >
                    RESPIRA 10-30 rpm (Normal)
                    <span className="block text-[11px] font-normal text-primary-200">→ Evaluar Perfusión</span>
                  </button>
                </div>
              </div>
            )}

            {/* PASO 3: PERFUSIÓN */}
            {startStep === 3 && (
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
                  <p className="font-bold text-sm text-blue-950">3. ¿Existe pulso radial o relleno capilar &lt; 2 segundos?</p>
                  <p className="text-xs text-blue-800 mt-1">
                    Presiona el lecho ungueal 5s y suelta. Si tarda más de 2s en sonrosarse o no palpas pulso radial, hay shock.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      setStartPerfusionMala(true);
                      handleFinishStartWizard('rojo');
                    }}
                    className="p-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm"
                  >
                    RELLENO &gt; 2s o SIN PULSO
                    <span className="block text-xs font-normal">→ Clasificar ROJO (T1)</span>
                  </button>

                  <button
                    onClick={() => {
                      setStartPerfusionMala(false);
                      setStartStep(4);
                    }}
                    className="p-4 rounded-xl bg-primary-700 hover:bg-primary-800 text-white font-bold text-sm"
                  >
                    PULSO RADIAL PRESENTE (&lt;2s)
                    <span className="block text-xs font-normal">→ Evaluar Consciencia</span>
                  </button>
                </div>
              </div>
            )}

            {/* PASO 4: CONSCIENCIA */}
            {startStep === 4 && (
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
                  <p className="font-bold text-sm text-blue-950">4. ¿Obedece órdenes sencillas?</p>
                  <p className="text-xs text-blue-800 mt-1">
                    Pídele: "Apriétame la mano" o "Abre los ojos".
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      setStartObedece(false);
                      handleFinishStartWizard('rojo');
                    }}
                    className="p-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm"
                  >
                    NO OBEDECE (Desorientado/Coma)
                    <span className="block text-xs font-normal">→ Clasificar ROJO (T1)</span>
                  </button>

                  <button
                    onClick={() => {
                      setStartObedece(true);
                      handleFinishStartWizard('amarillo');
                    }}
                    className="p-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm"
                  >
                    SÍ OBEDECE ÓRDENES
                    <span className="block text-xs font-normal">→ Clasificar AMARILLO (T2)</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* CONTENIDO PESTAÑA: LISTADO DE VÍCTIMAS CLASIFICADAS */}
        {activeTab === 'lista' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                <div className="relative flex-1">
                  <Search size={14} className="absolute left-3 top-2.5 text-gray-400" />
                  <input
                    className="input text-xs pl-8 py-1.5"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Buscar por lesión o etiqueta..."
                  />
                </div>
                <select
                  className="input text-xs py-1.5 w-auto"
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                >
                  <option value="all">Todos los colores ({records.length})</option>
                  <option value="rojo">Solo Rojos ({stats.rojos})</option>
                  <option value="amarillo">Solo Amarillos ({stats.amarillos})</option>
                  <option value="verde">Solo Verdes ({stats.verdes})</option>
                  <option value="negro">Solo Negros ({stats.negros})</option>
                </select>
              </div>

              {canManage && records.length > 0 && (
                <button
                  onClick={() => {
                    if (confirm('¿Vaciar y reiniciar el triaje completo de este incidente?')) {
                      clearAllTriageRecords();
                    }
                  }}
                  className="text-xs text-error-600 hover:underline cursor-pointer"
                >
                  Reiniciar triaje
                </button>
              )}
            </div>

            {filteredRecords.length === 0 ? (
              <p className="text-sm text-gray-400 py-8 text-center bg-gray-50 rounded-xl">
                No hay víctimas registradas con el criterio de búsqueda.
              </p>
            ) : (
              <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                {filteredRecords.map((r) => {
                  const cfg = triageCategoryConfig[r.categoria];
                  return (
                    <div
                      key={r.id}
                      className={`p-3 rounded-xl border-l-4 ${cfg.borderClass} ${cfg.bgClass} flex items-center justify-between gap-2 shadow-xs transition-shadow hover:shadow-sm`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className={`w-3 h-3 rounded-full ${cfg.dotClass}`} />
                          <span className="font-black text-sm text-gray-900">
                            #{String(r.numero_etiqueta).padStart(3, '0')}
                          </span>
                          <span className="text-xs font-bold uppercase tracking-wide px-2 py-0.5 rounded-md bg-white border border-gray-200">
                            {cfg.codigo} · {cfg.label}
                          </span>
                          <span className="text-[11px] text-gray-500">
                            {r.edad_grupo} · {r.genero}
                          </span>
                        </div>
                        <p className="text-xs font-semibold text-gray-800 mt-1">{r.lesion_principal}</p>
                        <div className="flex items-center gap-3 text-[10px] text-gray-500 mt-1 flex-wrap">
                          {r.ubicacion_nido && <span>📍 {r.ubicacion_nido}</span>}
                          {r.destino_traslado && <span>🚑 Destino: {r.destino_traslado}</span>}
                          <span>⏱️ {new Date(r.created_at).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        {onOpenParteSanitario && (
                          <button
                            onClick={() => {
                              onOpenParteSanitario(r);
                              onClose();
                            }}
                            className="btn-outline text-xs py-1 px-2.5 bg-white text-primary-700 hover:bg-primary-50 flex items-center gap-1 cursor-pointer font-medium"
                            title="Abrir Parte de Asistencia Sanitaria para esta víctima"
                          >
                            <Stethoscope size={13} />
                            <span>Crear parte</span>
                          </button>
                        )}
                        {canManage && (
                          <button
                            onClick={() => deleteTriageRecord(r.id)}
                            className="p-1.5 text-gray-400 hover:text-red-600 rounded-lg hover:bg-red-50 cursor-pointer"
                            title="Eliminar de triaje"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        <div className="flex justify-end pt-2 border-t border-gray-100">
          <button onClick={onClose} className="btn-primary text-xs px-4 py-2">
            Cerrar panel de triaje
          </button>
        </div>
      </div>
    </Modal>
  );
}
