import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Plus,
  Minus,
  ShieldAlert,
  Copy,
  CheckCircle2,
  Download,
  RotateCcw,
  ListChecks,
  Undo2,
  Ambulance,
  Users,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  getTriageRecords,
  addQuickTriage,
  removeLastTriage,
  restoreTriageRecord,
  clearAllTriageRecords,
  subscribeToTriageUpdates,
  calculateTriageStats,
  exportTriageToCsv,
  type TriageCategory,
  type TriageRecord,
} from '@/lib/triageStorage';
import { TriajeModal } from '@/components/TriajeModal';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';

interface CardStyle {
  title: string;
  code: string;
  subtitle: string;
  hint: string;
  /** Colores oficiales de triaje: rojo, amarillo, verde y negro. */
  card: string;
  stepBtn: string;
  pill: string;
}

const CARD_STYLES: Record<TriageCategory, CardStyle> = {
  rojo: {
    title: 'ROJO',
    code: 'T1',
    subtitle: 'Crítico · Inmediato',
    hint: 'Riesgo vital. Evacuación < 15 min',
    card: 'bg-red-600 text-white shadow-red-900/30',
    stepBtn: 'bg-white/20 hover:bg-white/30 active:bg-white/40 text-white',
    pill: 'bg-red-600 text-white',
  },
  amarillo: {
    title: 'AMARILLO',
    code: 'T2',
    subtitle: 'Urgente · Demorado',
    hint: 'Grave no crítico. Atención < 2 h',
    card: 'bg-yellow-400 text-gray-900 shadow-yellow-900/20',
    stepBtn: 'bg-black/10 hover:bg-black/20 active:bg-black/30 text-gray-900',
    pill: 'bg-yellow-400 text-gray-900',
  },
  verde: {
    title: 'VERDE',
    code: 'T3',
    subtitle: 'Leve · Deambulante',
    hint: 'Menor. Puede esperar',
    card: 'bg-green-600 text-white shadow-green-900/30',
    stepBtn: 'bg-white/20 hover:bg-white/30 active:bg-white/40 text-white',
    pill: 'bg-green-600 text-white',
  },
  negro: {
    title: 'NEGRO',
    code: 'T0',
    subtitle: 'Fallecido',
    hint: 'Sin signos vitales / no recuperable',
    card: 'bg-slate-900 text-white shadow-black/40',
    stepBtn: 'bg-white/15 hover:bg-white/25 active:bg-white/35 text-white',
    pill: 'bg-slate-900 text-white',
  },
};

const CATEGORY_ORDER: TriageCategory[] = ['rojo', 'amarillo', 'verde', 'negro'];

export function TriajePMAPage() {
  const { profile } = useAuth();
  const canReset = profile?.role === 'admin_tecnico' || profile?.role === 'coordinador';
  const operator = profile ? `${profile.nombre ?? ''} ${profile.apellidos?.[0] ?? ''}`.trim() || 'Coordinador PMA' : 'Coordinador PMA';

  const [records, setRecords] = useState<TriageRecord[]>(() => getTriageRecords());
  const [incidentTitle, setIncidentTitle] = useState('');
  const [tapped, setTapped] = useState<TriageCategory | null>(null);
  const [undoRecord, setUndoRecord] = useState<TriageRecord | null>(null);
  const [copied, setCopied] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const tapTimer = useRef<number | null>(null);
  const undoTimer = useRef<number | null>(null);

  // Sincronización en tiempo real (mismo navegador y otras pestañas)
  useEffect(() => {
    const refresh = () => setRecords(getTriageRecords());
    refresh();
    const unsub = subscribeToTriageUpdates(refresh);
    window.addEventListener('storage', refresh);
    return () => {
      unsub();
      window.removeEventListener('storage', refresh);
      if (tapTimer.current) window.clearTimeout(tapTimer.current);
      if (undoTimer.current) window.clearTimeout(undoTimer.current);
    };
  }, []);

  const stats = useMemo(() => calculateTriageStats(records), [records]);
  const counts: Record<TriageCategory, number> = {
    rojo: stats.rojos,
    amarillo: stats.amarillos,
    verde: stats.verdes,
    negro: stats.negros,
  };

  const flash = (cat: TriageCategory) => {
    setTapped(cat);
    if (tapTimer.current) window.clearTimeout(tapTimer.current);
    tapTimer.current = window.setTimeout(() => setTapped(null), 180);
  };

  const handleAdd = (cat: TriageCategory) => {
    addQuickTriage(cat, operator);
    flash(cat);
    // Un alta nueva invalida el "Deshacer" anterior
    setUndoRecord(null);
  };

  const handleRemove = (cat: TriageCategory) => {
    const removed = removeLastTriage(cat);
    if (!removed) return;
    flash(cat);
    setUndoRecord(removed);
    if (undoTimer.current) window.clearTimeout(undoTimer.current);
    undoTimer.current = window.setTimeout(() => setUndoRecord(null), 6000);
  };

  const handleUndo = () => {
    if (!undoRecord) return;
    restoreTriageRecord(undoRecord);
    setUndoRecord(null);
    if (undoTimer.current) window.clearTimeout(undoTimer.current);
  };

  const handleCopySummary = async () => {
    const text = `🚨 [INFORME TRIAJE IMV - PROTECCIÓN CIVIL HUELVA]
Incidente: ${incidentTitle.trim() || 'Emergencia / Dispositivo'}
Total víctimas clasificadas: ${stats.total}
🔴 T1 ROJO (Crítico): ${stats.rojos}
🟡 T2 AMARILLO (Urgente): ${stats.amarillos}
🟢 T3 VERDE (Leve): ${stats.verdes}
⚫ T0 NEGRO (Fallecido): ${stats.negros}
Ambulancias UVI (SVA) requeridas: ${stats.uviRequeridas}
Ambulancias SVB requeridas: ${stats.svbRequeridas}
Hora reporte: ${new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 3000);
    } catch {
      window.prompt('Copia el resumen manualmente:', text);
    }
  };

  return (
    <div className="px-4 py-4 max-w-5xl mx-auto space-y-4">
      {/* Cabecera */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-red-600">
            Incidentes de Múltiples Víctimas
          </p>
          <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <ShieldAlert size={22} className="text-red-600" />
            Triaje Masivo · PMA
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Registro instantáneo de víctimas por prioridad (START / Manchester).
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setShowDetail(true)}
            className="btn-outline text-xs py-2 px-3 flex items-center gap-1.5 text-primary-700 hover:bg-primary-50 cursor-pointer"
            title="Listado de fichas y algoritmo START guiado"
          >
            <ListChecks size={15} />
            <span>Fichas y algoritmo START</span>
          </button>
          <button
            type="button"
            onClick={() => exportTriageToCsv(records, incidentTitle.trim() || undefined)}
            disabled={records.length === 0}
            className="btn-outline text-xs py-2 px-3 flex items-center gap-1.5 text-primary-700 hover:bg-primary-50 cursor-pointer"
          >
            <Download size={15} />
            <span className="hidden sm:inline">CSV</span>
          </button>
        </div>
      </div>

      {/* PANEL DE CONTEO AUTOMÁTICO (fijo arriba al hacer scroll) */}
      <div className="sticky top-14 z-20 -mx-1 rounded-2xl bg-gradient-to-r from-slate-900 to-primary-950 p-3 sm:p-4 text-white shadow-lg">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <p
            className="text-sm sm:text-base font-bold flex flex-wrap items-center gap-x-2 gap-y-1"
            aria-live="polite"
            aria-label="Desglose de víctimas por categoría"
          >
            <span className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-full bg-red-500 ring-2 ring-white/70" /> Rojos: <span className="tabular-nums text-red-300">{stats.rojos}</span>
            </span>
            <span className="text-white/30">|</span>
            <span className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-full bg-yellow-400 ring-2 ring-white/70" /> Amarillos: <span className="tabular-nums text-yellow-300">{stats.amarillos}</span>
            </span>
            <span className="text-white/30">|</span>
            <span className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-full bg-green-500 ring-2 ring-white/70" /> Verdes: <span className="tabular-nums text-green-300">{stats.verdes}</span>
            </span>
            <span className="text-white/30">|</span>
            <span className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-full bg-slate-950 ring-2 ring-white/70" /> Negros: <span className="tabular-nums text-slate-300">{stats.negros}</span>
            </span>
          </p>

          <span className="flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1 text-sm font-bold">
            <Users size={15} />
            Total: <span className="tabular-nums">{stats.total}</span>
          </span>
        </div>

        <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between gap-2 flex-wrap text-xs text-slate-300">
          <span className="flex items-center gap-1.5">
            <Ambulance size={14} className="text-red-300" />
            Necesidad estimada 112: <strong className="text-white">{stats.uviRequeridas} UVI</strong> ·{' '}
            <strong className="text-white">{stats.svbRequeridas} SVB</strong>
          </span>
          <button
            type="button"
            onClick={handleCopySummary}
            className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
          >
            {copied ? <CheckCircle2 size={13} className="text-green-400" /> : <Copy size={13} />}
            <span>{copied ? 'Copiado' : 'Copiar para 112'}</span>
          </button>
        </div>
      </div>

      {/* Incidente (opcional, para el informe y el CSV) */}
      <div className="card p-3 flex items-center gap-3">
        <label htmlFor="pma-incident" className="text-xs font-semibold text-gray-500 uppercase tracking-wide shrink-0">
          Incidente
        </label>
        <input
          id="pma-incident"
          className="input text-xs py-1.5"
          value={incidentTitle}
          onChange={(e) => setIncidentTitle(e.target.value)}
          placeholder="Ej. Accidente múltiple A-49 km 12 (opcional)"
        />
      </div>

      {/* Aviso de deshacer */}
      {undoRecord && (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-xs shadow-xs">
          <span className="text-gray-700">
            Restada la víctima <strong>#{String(undoRecord.numero_etiqueta).padStart(3, '0')}</strong> (
            {CARD_STYLES[undoRecord.categoria].title.toLowerCase()}).
          </span>
          <button
            type="button"
            onClick={handleUndo}
            className="flex items-center gap-1 font-bold text-primary-700 hover:underline cursor-pointer"
          >
            <Undo2 size={14} /> Deshacer
          </button>
        </div>
      )}

      {/* 4 TARJETAS DE TRIAJE */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {CATEGORY_ORDER.map((cat) => {
          const s = CARD_STYLES[cat];
          const count = counts[cat];
          const isTapped = tapped === cat;
          return (
            <section
              key={cat}
              aria-label={`Triaje ${s.title}`}
              className={`rounded-3xl p-4 sm:p-5 shadow-lg transition-transform duration-150 select-none ${s.card} ${
                isTapped ? 'scale-[1.025] ring-4 ring-white/60' : ''
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-xs font-bold tracking-widest opacity-80">{s.code}</p>
                  <h2 className="text-2xl font-black leading-tight tracking-wide">{s.title}</h2>
                  <p className="text-sm font-semibold opacity-90">{s.subtitle}</p>
                </div>
                <p className="text-[11px] font-medium opacity-80 text-right max-w-[9rem] leading-tight">{s.hint}</p>
              </div>

              <div className="mt-4 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => handleRemove(cat)}
                  disabled={count === 0}
                  aria-label={`Restar una víctima ${s.title.toLowerCase()}`}
                  className={`h-16 w-16 sm:h-20 sm:w-20 shrink-0 rounded-2xl flex items-center justify-center cursor-pointer transition-all active:scale-90 disabled:opacity-30 disabled:cursor-not-allowed ${s.stepBtn}`}
                >
                  <Minus size={34} strokeWidth={3} />
                </button>

                <span
                  className="text-7xl sm:text-8xl font-black tabular-nums leading-none"
                  aria-live="polite"
                >
                  {count}
                </span>

                <button
                  type="button"
                  onClick={() => handleAdd(cat)}
                  aria-label={`Sumar una víctima ${s.title.toLowerCase()}`}
                  className={`h-16 w-16 sm:h-20 sm:w-20 shrink-0 rounded-2xl flex items-center justify-center cursor-pointer transition-all active:scale-90 ${s.stepBtn}`}
                >
                  <Plus size={34} strokeWidth={3} />
                </button>
              </div>
            </section>
          );
        })}
      </div>

      <div className="flex items-center justify-between gap-3 flex-wrap text-[11px] text-gray-400 pb-2">
        <p>
          Cada “+” crea una ficha mínima pendiente de filiar; puedes completarla desde “Fichas y algoritmo START”.
        </p>
        {canReset && records.length > 0 && (
          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="flex items-center gap-1 text-error-600 hover:underline cursor-pointer font-medium"
          >
            <RotateCcw size={12} /> Reiniciar triaje
          </button>
        )}
      </div>

      <TriajeModal open={showDetail} onClose={() => setShowDetail(false)} incidentTitle={incidentTitle.trim() || undefined} />

      {confirmReset && (
        <ConfirmDialog
          open={confirmReset}
          title="¿Reiniciar el triaje completo?"
          message={`Se eliminarán las ${records.length} víctimas registradas y todos los contadores volverán a 0. Esta acción no se puede deshacer. Exporta antes el CSV si necesitas conservar los datos.`}
          confirmText="Reiniciar a cero"
          danger
          onConfirm={() => {
            clearAllTriageRecords();
            setUndoRecord(null);
          }}
          onClose={() => setConfirmReset(false)}
        />
      )}
    </div>
  );
}
