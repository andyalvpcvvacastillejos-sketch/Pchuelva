import { useEffect, useState, useMemo, useRef } from 'react';
import {
  Truck,
  Plus,
  Search,
  Filter,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Edit2,
  Trash2,
  Wrench,
  Gauge,
  Shield,
  Radio,
  FileSpreadsheet,
  RefreshCw,
  X,
  MapPin,
  Satellite,
  SatelliteDish,
  Navigation,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { type OperationalVehicle, type VehicleType, type VehicleStatus } from '@/lib/supabase';
import {
  getFleetVehicles,
  createFleetVehicle,
  updateFleetVehicle,
  deleteFleetVehicle,
  subscribeToFleetUpdates,
  type FleetVehicleInput,
} from '@/lib/fleetStorage';
import { downloadCsv } from '@/lib/exportUtils';
import { Badge } from '@/components/ui/Badge';
import { Spinner } from '@/components/ui/Spinner';
import { Modal } from '@/components/ui/Modal';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';

export const vehicleTypeConfig: Record<VehicleType, { label: string; color: string; badgeVariant: 'primary' | 'warning' | 'error' | 'gray' }> = {
  vir: { label: 'VIR (Intervención Rápida)', color: '#ea580c', badgeVariant: 'warning' },
  ambulancia: { label: 'Ambulancia Asistencial', color: '#dc2626', badgeVariant: 'error' },
  coordinacion: { label: 'Mando / Coordinación', color: '#1d4ed8', badgeVariant: 'primary' },
  logistica: { label: 'Logística / Furgón', color: '#059669', badgeVariant: 'primary' },
  otro: { label: 'Vehículo Auxiliar', color: '#6b7280', badgeVariant: 'gray' },
};

export const vehicleStatusConfig: Record<VehicleStatus, { label: string; badgeVariant: 'success' | 'primary' | 'warning' | 'error' | 'gray' }> = {
  en_base: { label: 'En Base (Disponible)', badgeVariant: 'success' },
  en_ruta: { label: 'En Ruta / Patrulla', badgeVariant: 'primary' },
  en_incidencia: { label: 'En Incidencia Activa', badgeVariant: 'error' },
};

// ============================================================
// TELEMETRÍA AVL SIMULADA (Automatic Vehicle Location)
// ============================================================

/** Cadencia de envío de coordenadas de cada dotación con AVL activo. */
const AVL_INTERVAL_MS = 30_000;

/** Centro de operaciones (Huelva capital) usado como ancla de la simulación. */
const AVL_HOME = { lat: 37.2614, lng: -6.9447 };
/** Radio máximo (en grados) que puede alejarse la simulación del centro. */
const AVL_MAX_DRIFT_DEG = 0.06;

/** El AVL solo tiene sentido con el vehículo fuera de base. */
const isAvlEligible = (v: OperationalVehicle) => v.estado === 'en_ruta' || v.estado === 'en_incidencia';
/** Vehículo que está transmitiendo AVL ahora mismo. */
const isAvlTransmitting = (v: OperationalVehicle) => Boolean(v.avl_active) && isAvlEligible(v);

const randomBetween = (min: number, max: number) => min + Math.random() * (max - min);

/**
 * Genera el siguiente "ping" de telemetría: un paso de movimiento coherente
 * (rumbo + velocidad → distancia recorrida en 30 s) desde la última posición.
 * En producción esta función se sustituye por la lectura real de
 * navigator.geolocation (ver startAvlBeacon en fleetStorage.ts).
 */
function simulateAvlPing(veh: OperationalVehicle, operator: string) {
  const lat0 = veh.latitud ?? AVL_HOME.lat;
  const lng0 = veh.longitud ?? AVL_HOME.lng;

  // En incidencia la dotación está prácticamente parada; en ruta circula.
  const speed =
    veh.estado === 'en_incidencia'
      ? Math.round(randomBetween(0, 6))
      : Math.round(randomBetween(18, 55));

  let heading = ((veh.avl_heading ?? randomBetween(0, 360)) + randomBetween(-25, 25) + 360) % 360;

  // Si se aleja demasiado del centro, vuelve a orientarse hacia él.
  if (Math.hypot(lat0 - AVL_HOME.lat, lng0 - AVL_HOME.lng) > AVL_MAX_DRIFT_DEG) {
    const toHome = (Math.atan2(AVL_HOME.lng - lng0, AVL_HOME.lat - lat0) * 180) / Math.PI;
    heading = (toHome + randomBetween(-20, 20) + 360) % 360;
  }

  const km = (speed * (AVL_INTERVAL_MS / 1000)) / 3600;
  const rad = (heading * Math.PI) / 180;
  const dLat = (km * Math.cos(rad)) / 111.32;
  const dLng = (km * Math.sin(rad)) / (111.32 * Math.cos((lat0 * Math.PI) / 180));

  return {
    latitud: Number((lat0 + dLat).toFixed(6)),
    longitud: Number((lng0 + dLng).toFixed(6)),
    avl_speed: speed,
    avl_heading: Math.round(heading),
    avl_accuracy: Math.round(randomBetween(4, 15)),
    avl_last_ping: new Date().toISOString(),
    avl_transmitted_by: operator,
  };
}

const formatPingTime = (iso?: string | null) =>
  iso
    ? new Date(iso).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : '—';

export function ParqueMovilPage() {
  const { user, profile } = useAuth();
  const canManage =
    profile?.role === 'admin_tecnico' ||
    profile?.role === 'coordinador' ||
    profile?.agrupacion_role === 'responsable_parque_movil' ||
    profile?.agrupacion_role === 'jefe_agrupacion' ||
    profile?.agrupacion_role === 'subjefe_agrupacion';

  const [vehicles, setVehicles] = useState<OperationalVehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Modales
  const [showModal, setShowModal] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<OperationalVehicle | null>(null);
  const [vehicleToDelete, setVehicleToDelete] = useState<OperationalVehicle | null>(null);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Form states
  const [nombre, setNombre] = useState('');
  const [tipo, setTipo] = useState<VehicleType>('vir');
  const [estado, setEstado] = useState<VehicleStatus>('en_base');
  const [matricula, setMatricula] = useState('');
  const [indicativo, setIndicativo] = useState('');
  const [kilometraje, setKilometraje] = useState('');
  const [itvCaducidad, setItvCaducidad] = useState('');
  const [seguroCaducidad, setSeguroCaducidad] = useState('');
  const [equipamiento, setEquipamiento] = useState('');
  const [notas, setNotas] = useState('');

  // `silent` evita el spinner a pantalla completa en recargas automáticas
  // (cada ping AVL dispara un evento de flota; sin esto la lista parpadearía).
  const loadVehicles = async (silent = false) => {
    if (!silent) setLoading(true);
    const data = await getFleetVehicles();
    setVehicles(data);
    setLoading(false);
  };

  useEffect(() => {
    loadVehicles();
    const unsubscribe = subscribeToFleetUpdates(() => {
      loadVehicles(true);
    });
    return unsubscribe;
  }, []);

  // ---------- Telemetría AVL ----------
  const vehiclesRef = useRef<OperationalVehicle[]>([]);
  vehiclesRef.current = vehicles;

  const operatorName = profile ? `${profile.nombre ?? ''} ${profile.apellidos ?? ''}`.trim() || 'Operador AVL' : 'Operador AVL';
  const operatorRef = useRef(operatorName);
  operatorRef.current = operatorName;

  // Cola secuencial: updateFleetVehicle es "leer-modificar-escribir" sobre toda la flota,
  // así que ping y cambios manuales no deben solaparse o se pisarían entre sí.
  const fleetQueueRef = useRef<Promise<unknown>>(Promise.resolve());
  const queueFleetUpdate = (id: string, updates: Parameters<typeof updateFleetVehicle>[1]) => {
    const run = fleetQueueRef.current.then(() => updateFleetVehicle(id, updates));
    fleetQueueRef.current = run.catch(() => undefined);
    return run;
  };

  // Clave estable con los ids que transmiten: el efecto solo se reinicia si cambia ESTE conjunto
  // (no con cada ping, que modifica `vehicles`).
  const avlKey = useMemo(
    () => vehicles.filter(isAvlTransmitting).map((v) => v.id).sort().join('|'),
    [vehicles]
  );
  const avlCount = avlKey ? avlKey.split('|').length : 0;

  useEffect(() => {
    if (!canManage || !avlKey) return;
    const ids = avlKey.split('|');
    let cancelled = false;

    const transmit = async (onlyStale: boolean) => {
      for (const id of ids) {
        if (cancelled) return;
        const veh = vehiclesRef.current.find((v) => v.id === id);
        if (!veh || !isAvlTransmitting(veh)) continue;
        // Al activar (o al volver a abrir la página) se envía un primer ping inmediato
        // solo si el último es antiguo; así no se duplican envíos.
        if (
          onlyStale &&
          veh.avl_last_ping &&
          Date.now() - Date.parse(veh.avl_last_ping) < AVL_INTERVAL_MS
        ) {
          continue;
        }
        try {
          await queueFleetUpdate(id, simulateAvlPing(veh, operatorRef.current));
        } catch (e) {
          console.warn('Fallo al enviar ping AVL simulado:', e);
        }
      }
    };

    void transmit(true);
    const timer = window.setInterval(() => void transmit(false), AVL_INTERVAL_MS);

    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
    // queueFleetUpdate solo usa refs y updateFleetVehicle: es estable a efectos del intervalo.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [avlKey, canManage]);

  const showNotification = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleOpenCreate = () => {
    setEditingVehicle(null);
    setNombre('');
    setTipo('vir');
    setEstado('en_base');
    setMatricula('');
    setIndicativo('');
    setKilometraje('');
    setItvCaducidad('');
    setSeguroCaducidad('');
    setEquipamiento('DESA Samaritan 350P, Mochila soporte vital, Collarines cervicales, Extintor 6kg');
    setNotas('');
    setError(null);
    setShowModal(true);
  };

  const handleOpenEdit = (veh: OperationalVehicle) => {
    setEditingVehicle(veh);
    setNombre(veh.nombre);
    setTipo(veh.tipo);
    setEstado(veh.estado);
    setMatricula(veh.matricula || '');
    setIndicativo(veh.indicativo || '');
    setKilometraje(veh.kilometraje ? String(veh.kilometraje) : '');
    setItvCaducidad(veh.itv_caducidad || '');
    setSeguroCaducidad(veh.seguro_caducidad || '');
    setEquipamiento(veh.equipamiento || '');
    setNotas(veh.notas || '');
    setError(null);
    setShowModal(true);
  };

  const handleSaveVehicle = async () => {
    if (nombre.trim().length < 2) {
      setError('Indica el nombre o denominación del vehículo (mínimo 2 letras).');
      return;
    }
    setSaving(true);
    setError(null);

    const inputData: FleetVehicleInput = {
      nombre: nombre.trim(),
      tipo,
      estado,
      matricula: matricula.trim() || null,
      indicativo: indicativo.trim() || null,
      kilometraje: kilometraje ? parseInt(kilometraje, 10) : null,
      itv_caducidad: itvCaducidad || null,
      seguro_caducidad: seguroCaducidad || null,
      equipamiento: equipamiento.trim() || null,
      notas: notas.trim() || null,
      // Un vehículo en base nunca transmite AVL.
      ...(estado === 'en_base' ? { avl_active: false, avl_speed: null } : {}),
    };

    try {
      if (editingVehicle) {
        await queueFleetUpdate(editingVehicle.id, inputData);
        showNotification(`Vehículo "${inputData.nombre}" actualizado en la flota.`);
      } else {
        await createFleetVehicle(inputData, user?.id);
        showNotification(`Vehículo "${inputData.nombre}" incorporado al Parque Móvil.`);
      }
      setShowModal(false);
      await loadVehicles(true);
    } catch (e) {
      setError('Ocurrió un error al guardar el vehículo.');
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!vehicleToDelete) return;
    try {
      await deleteFleetVehicle(vehicleToDelete.id);
      showNotification(`Vehículo "${vehicleToDelete.nombre}" retirado de la flota.`);
      setVehicleToDelete(null);
      await loadVehicles(true);
    } catch {
      showNotification('Error al retirar el vehículo.');
    }
  };

  const handleQuickStatusChange = async (veh: OperationalVehicle, newStatus: VehicleStatus) => {
    const wasTransmitting = isAvlTransmitting(veh);
    // Al volver a base se corta la transmisión AVL automáticamente.
    await queueFleetUpdate(
      veh.id,
      newStatus === 'en_base' ? { estado: newStatus, avl_active: false, avl_speed: null } : { estado: newStatus }
    );
    showNotification(
      `Estado de ${veh.nombre} actualizado a: ${vehicleStatusConfig[newStatus].label}.` +
        (wasTransmitting && newStatus === 'en_base' ? ' Transmisión AVL detenida.' : '')
    );
    await loadVehicles(true);
  };

  const handleToggleAvl = async (veh: OperationalVehicle, enabled: boolean) => {
    await queueFleetUpdate(
      veh.id,
      enabled
        ? {
            avl_active: true,
            avl_last_ping: null, // fuerza un primer ping inmediato desde el efecto
            avl_transmitted_by: operatorName,
          }
        : { avl_active: false, avl_speed: null }
    );
    showNotification(
      enabled
        ? `Transmisión GPS (AVL) activada en ${veh.nombre}. Envío de posición cada ${AVL_INTERVAL_MS / 1000} s.`
        : `Transmisión GPS (AVL) desactivada en ${veh.nombre}.`
    );
    await loadVehicles(true);
  };

  // Filtrado de vehículos
  const filteredVehicles = useMemo(() => {
    return vehicles.filter((v) => {
      if (filterType !== 'all' && v.tipo !== filterType) return false;
      if (filterStatus !== 'all' && v.estado !== filterStatus) return false;
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchesName = v.nombre.toLowerCase().includes(query);
        const matchesMatricula = (v.matricula || '').toLowerCase().includes(query);
        const matchesIndicativo = (v.indicativo || '').toLowerCase().includes(query);
        const matchesEquip = (v.equipamiento || '').toLowerCase().includes(query);
        return matchesName || matchesMatricula || matchesIndicativo || matchesEquip;
      }
      return true;
    });
  }, [vehicles, filterType, filterStatus, searchTerm]);

  // Estadísticas
  const stats = useMemo(() => {
    const total = vehicles.length;
    const enBase = vehicles.filter((v) => v.estado === 'en_base').length;
    const enRuta = vehicles.filter((v) => v.estado === 'en_ruta').length;
    const enIncidencia = vehicles.filter((v) => v.estado === 'en_incidencia').length;
    return { total, enBase, enRuta, enIncidencia };
  }, [vehicles]);

  const handleExportFleet = () => {
    const headers = [
      'ID Vehículo',
      'Denominación / Nombre',
      'Matrícula',
      'Indicativo Radio',
      'Tipo de Vehículo',
      'Estado Operativo',
      'Kilometraje (km)',
      'Caducidad ITV',
      'Caducidad Seguro',
      'Equipamiento Dotacional',
      'Notas / Observaciones',
    ];

    const rows: (string | number | null | undefined)[][] = [headers];

    for (const v of filteredVehicles) {
      rows.push([
        v.id,
        v.nombre,
        v.matricula || '',
        v.indicativo || '',
        vehicleTypeConfig[v.tipo]?.label || v.tipo,
        vehicleStatusConfig[v.estado]?.label || v.estado,
        v.kilometraje ?? '',
        v.itv_caducidad || '',
        v.seguro_caducidad || '',
        v.equipamiento || '',
        v.notas || '',
      ]);
    }

    const timestamp = new Date().toISOString().slice(0, 10);
    downloadCsv(`parque_movil_flota_${timestamp}.csv`, rows);
    showNotification(`Exportados ${filteredVehicles.length} vehículos a archivo CSV.`);
  };

  return (
    <div className="px-4 py-4 max-w-5xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary-600">
            Logística y Recursos
          </p>
          <h1 className="text-xl font-bold text-gray-900">Parque Móvil y Flota Operativa</h1>
          <p className="text-sm text-gray-500 mt-1">
            Gestión integral de vehículos de Protección Civil Huelva.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportFleet}
            disabled={filteredVehicles.length === 0}
            className="btn-outline text-xs py-2 px-3 flex items-center gap-1.5 text-primary-700 hover:bg-primary-50 cursor-pointer shadow-xs disabled:opacity-50"
            title="Exportar inventario del parque móvil a CSV"
          >
            <FileSpreadsheet size={15} />
            <span className="hidden sm:inline">Exportar Flota (CSV)</span>
          </button>

          {canManage && (
            <button
              type="button"
              onClick={handleOpenCreate}
              className="btn-primary text-xs py-2 px-3.5 flex items-center gap-1.5 cursor-pointer shadow-sm font-bold"
            >
              <Plus size={16} />
              <span>Nuevo Vehículo</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => loadVehicles()}
            className="p-2 rounded-lg text-primary-600 hover:bg-primary-50 cursor-pointer"
            aria-label="Actualizar"
          >
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {/* Banner de feedback */}
      {feedback && (
        <div className="bg-success-50 border border-success-200 text-success-800 rounded-xl px-4 py-2.5 text-xs flex items-center gap-2 animate-fade-in shadow-xs">
          <CheckCircle2 size={16} className="text-success-600 shrink-0" />
          <span className="font-medium">{feedback}</span>
        </div>
      )}

      {/* Banner global de telemetría AVL */}
      {avlCount > 0 && (
        <div className="bg-sky-50 border border-sky-200 text-sky-900 rounded-xl px-4 py-2.5 text-xs flex items-center gap-2.5 shadow-xs">
          <span className="relative flex h-2.5 w-2.5 shrink-0">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-sky-400 opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-sky-500" />
          </span>
          <SatelliteDish size={15} className="text-sky-600 shrink-0" />
          <span className="font-semibold">
            {avlCount} {avlCount === 1 ? 'dotación transmitiendo' : 'dotaciones transmitiendo'} posición GPS (AVL)
          </span>
          <span className="text-sky-700/80 hidden sm:inline">· actualización cada {AVL_INTERVAL_MS / 1000} s · telemetría simulada</span>
        </div>
      )}

      {/* Indicadores de flota */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="card p-3 border-l-4 border-l-primary-500">
          <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Flota Total</p>
          <p className="text-xl font-black text-gray-900 mt-0.5">{stats.total}</p>
          <p className="text-[10px] text-gray-500 mt-0.5">Vehículos censados</p>
        </div>
        <div className="card p-3 border-l-4 border-l-emerald-500">
          <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">En Base</p>
          <p className="text-xl font-black text-emerald-700 mt-0.5">{stats.enBase}</p>
          <p className="text-[10px] text-emerald-600 mt-0.5">Disponibles de inmediato</p>
        </div>
        <div className="card p-3 border-l-4 border-l-blue-500">
          <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">En Ruta / Patrulla</p>
          <p className="text-xl font-black text-blue-700 mt-0.5">{stats.enRuta}</p>
          <p className="text-[10px] text-blue-600 mt-0.5">Operando en vía pública</p>
        </div>
        <div className="card p-3 border-l-4 border-l-red-500">
          <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">En Incidencia</p>
          <p className="text-xl font-black text-red-700 mt-0.5">{stats.enIncidencia}</p>
          <p className="text-[10px] text-red-600 mt-0.5">Interviniendo actualmente</p>
        </div>
      </div>

      {/* Barra de Búsqueda y Filtros */}
      <div className="card p-3 space-y-2.5">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            className="input pl-9 text-xs"
            placeholder="Buscar por denominación, matrícula, indicativo de radio o equipamiento…"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1"
            >
              <X size={14} />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 flex-wrap text-xs">
          <div className="flex items-center gap-1.5 text-gray-500 font-semibold">
            <Filter size={13} />
            <span>Tipo:</span>
          </div>
          <select
            className="bg-gray-50 border border-gray-200 rounded-lg px-2 py-1 text-xs text-gray-800 outline-none"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
          >
            <option value="all">Todos los tipos ({vehicles.length})</option>
            {Object.keys(vehicleTypeConfig).map((key) => {
              const k = key as VehicleType;
              const count = vehicles.filter((v) => v.tipo === k).length;
              return (
                <option key={k} value={k}>
                  {vehicleTypeConfig[k].label} ({count})
                </option>
              );
            })}
          </select>

          <div className="flex items-center gap-1.5 text-gray-500 font-semibold ml-2">
            <span>Estado:</span>
          </div>
          <select
            className="bg-gray-50 border border-gray-200 rounded-lg px-2 py-1 text-xs text-gray-800 outline-none"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="all">Todos los estados</option>
            {Object.keys(vehicleStatusConfig).map((key) => {
              const k = key as VehicleStatus;
              const count = vehicles.filter((v) => v.estado === k).length;
              return (
                <option key={k} value={k}>
                  {vehicleStatusConfig[k].label} ({count})
                </option>
              );
            })}
          </select>

          {(filterType !== 'all' || filterStatus !== 'all' || searchTerm) && (
            <button
              onClick={() => {
                setFilterType('all');
                setFilterStatus('all');
                setSearchTerm('');
              }}
              className="text-xs text-primary-600 hover:underline ml-auto font-medium"
            >
              Limpiar filtros
            </button>
          )}
        </div>
      </div>

      {/* Listado de Tarjetas de Vehículos */}
      {loading ? (
        <div className="flex justify-center py-12">
          <Spinner size={32} />
        </div>
      ) : filteredVehicles.length === 0 ? (
        <div className="card p-8 text-center space-y-2">
          <Truck size={36} className="mx-auto text-gray-300" />
          <p className="text-sm font-semibold text-gray-700">No se encontraron vehículos</p>
          <p className="text-xs text-gray-400">
            {searchTerm || filterType !== 'all' || filterStatus !== 'all'
              ? 'Prueba a cambiar los criterios de búsqueda o filtro.'
              : 'Añade el primer vehículo a la flota con el botón superior.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredVehicles.map((veh) => {
            const typeInfo = vehicleTypeConfig[veh.tipo] || vehicleTypeConfig.otro;
            const statusInfo = vehicleStatusConfig[veh.estado] || vehicleStatusConfig.en_base;
            const transmitting = isAvlTransmitting(veh);
            const avlEligible = isAvlEligible(veh);

            return (
              <div
                key={veh.id}
                className="card p-4 space-y-3 border border-gray-100 hover:border-gray-200 transition-all shadow-xs bg-white"
              >
                {/* Cabecera del vehículo */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${typeInfo.color}15`, color: typeInfo.color }}
                    >
                      <Truck size={20} />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-gray-900 leading-snug">{veh.nombre}</h3>
                      <p className="text-xs text-gray-500 font-medium">{typeInfo.label}</p>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1.5">
                    <Badge variant={statusInfo.badgeVariant}>{statusInfo.label}</Badge>
                    {transmitting && (
                      <span
                        className="inline-flex items-center gap-1.5 rounded-full bg-sky-50 border border-sky-200 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-sky-700"
                        title="Transmitiendo posición GPS en segundo plano (AVL)"
                      >
                        <span className="relative flex h-2 w-2">
                          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-sky-400 opacity-75" />
                          <span className="relative inline-flex h-2 w-2 rounded-full bg-sky-500" />
                        </span>
                        <Satellite size={12} className="animate-pulse" />
                        AVL en directo
                      </span>
                    )}
                  </div>
                </div>

                {/* Telemetría en vivo (solo con AVL transmitiendo) */}
                {transmitting && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-3 gap-y-1 rounded-xl bg-sky-50/70 border border-sky-100 px-3 py-2 text-[11px] text-sky-900">
                    <span className="flex items-center gap-1">
                      <Satellite size={11} className="text-sky-500" />
                      Ping: <strong className="font-mono">{formatPingTime(veh.avl_last_ping)}</strong>
                    </span>
                    <span className="flex items-center gap-1">
                      <Gauge size={11} className="text-sky-500" />
                      <strong>{veh.avl_speed ?? 0} km/h</strong>
                    </span>
                    <span className="flex items-center gap-1">
                      <Navigation
                        size={11}
                        className="text-sky-500"
                        style={{ transform: `rotate(${(veh.avl_heading ?? 0) - 45}deg)` }}
                      />
                      <strong>{veh.avl_heading ?? 0}°</strong>
                    </span>
                    <span className="text-sky-700/80">±{veh.avl_accuracy ?? '—'} m</span>
                    {veh.latitud !== null && veh.longitud !== null && (
                      <span className="col-span-2 sm:col-span-4 font-mono text-[10px] text-sky-700/80">
                        {veh.latitud.toFixed(5)}, {veh.longitud.toFixed(5)}
                        {veh.avl_transmitted_by ? ` · emite: ${veh.avl_transmitted_by}` : ''}
                      </span>
                    )}
                  </div>
                )}

                {/* Datos técnicos (Matrícula, Indicativo, Kilometraje) */}
                <div className="grid grid-cols-3 gap-2 bg-gray-50/70 p-2.5 rounded-xl text-xs">
                  <div>
                    <span className="text-[10px] text-gray-400 block font-semibold uppercase">Matrícula</span>
                    <span className="font-mono font-bold text-gray-800">{veh.matricula || 'Sin placa'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-400 block font-semibold uppercase flex items-center gap-1">
                      <Radio size={10} /> Indicativo
                    </span>
                    <span className="font-semibold text-gray-800">{veh.indicativo || '—'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-400 block font-semibold uppercase flex items-center gap-1">
                      <Gauge size={10} /> Kilómetros
                    </span>
                    <span className="font-medium text-gray-700">
                      {veh.kilometraje ? `${veh.kilometraje.toLocaleString()} km` : '—'}
                    </span>
                  </div>
                </div>

                {/* Vencimientos ITV y Seguro */}
                <div className="flex items-center gap-3 text-[11px] text-gray-500 flex-wrap">
                  {veh.itv_caducidad && (
                    <span className="flex items-center gap-1">
                      <Calendar size={12} className="text-gray-400" />
                      ITV: <strong className="text-gray-700">{veh.itv_caducidad}</strong>
                    </span>
                  )}
                  {veh.seguro_caducidad && (
                    <span className="flex items-center gap-1">
                      <Shield size={12} className="text-gray-400" />
                      Seguro: <strong className="text-gray-700">{veh.seguro_caducidad}</strong>
                    </span>
                  )}
                  {veh.latitud !== null && veh.longitud !== null && (
                    <span className="flex items-center gap-1 text-primary-600 ml-auto">
                      <MapPin size={12} /> Localizado en mapa
                    </span>
                  )}
                </div>

                {/* Dotación y equipamiento a bordo */}
                {veh.equipamiento && (
                  <div className="text-[11px] bg-blue-50/60 border border-blue-100/70 p-2 rounded-lg text-blue-900 leading-tight">
                    <strong className="block text-[10px] uppercase tracking-wide text-blue-600 mb-0.5">
                      Equipamiento sanitario / técnico dotado:
                    </strong>
                    {veh.equipamiento}
                  </div>
                )}

                {/* Switch AVL: solo aparece con el vehículo En Ruta o En Incidencia */}
                {canManage && avlEligible && (
                  <div
                    className={`flex items-center justify-between gap-3 rounded-xl border px-3 py-2 transition-colors ${
                      transmitting ? 'bg-sky-50 border-sky-200' : 'bg-gray-50 border-gray-200'
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-gray-800 flex items-center gap-1.5">
                        <SatelliteDish size={14} className={transmitting ? 'text-sky-600' : 'text-gray-400'} />
                        Activar Transmisión GPS (AVL)
                      </p>
                      <p className="text-[10px] text-gray-500 leading-tight mt-0.5">
                        Opcional · comparte la posición de la dotación cada {AVL_INTERVAL_MS / 1000} s.
                      </p>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={transmitting}
                      aria-label={`Transmisión GPS AVL de ${veh.nombre}`}
                      onClick={() => handleToggleAvl(veh, !transmitting)}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-offset-1 ${
                        transmitting ? 'bg-sky-500' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                          transmitting ? 'translate-x-[22px]' : 'translate-x-0.5'
                        }`}
                      />
                    </button>
                  </div>
                )}

                {/* Acciones y cambio rápido de estado */}
                {canManage && (
                  <div className="pt-2 border-t border-gray-100 flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-1">
                      {(['en_base', 'en_ruta', 'en_incidencia'] as VehicleStatus[]).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => handleQuickStatusChange(veh, st)}
                          className={`text-[10px] px-2 py-1 rounded-md font-medium border transition-colors cursor-pointer ${
                            veh.estado === st
                              ? 'border-primary-500 bg-primary-50 text-primary-700 font-bold'
                              : 'border-gray-200 bg-white text-gray-500 hover:bg-gray-50'
                          }`}
                        >
                          {st === 'en_base' ? 'En Base' : st === 'en_ruta' ? 'En Ruta' : 'En Incidencia'}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-1.5 ml-auto">
                      <button
                        type="button"
                        onClick={() => handleOpenEdit(veh)}
                        className="p-1.5 text-gray-500 hover:text-primary-600 hover:bg-primary-50 rounded-lg cursor-pointer"
                        title="Modificar vehículo"
                      >
                        <Edit2 size={15} />
                      </button>
                      <button
                        type="button"
                        onClick={() => setVehicleToDelete(veh)}
                        className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                        title="Retirar vehículo del parque móvil"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modal Crear / Editar Vehículo */}
      {showModal && (
        <Modal
          open={showModal}
          onClose={() => setShowModal(false)}
          title={editingVehicle ? 'Modificar vehículo del Parque Móvil' : 'Incorporar nuevo vehículo a la flota'}
          size="lg"
        >
          <div className="space-y-4">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl px-3 py-2 text-xs flex items-center gap-2">
                <AlertTriangle size={15} className="shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="label">Denominación / Nombre operativo *</label>
                <input
                  type="text"
                  className="input"
                  placeholder="Ej. VIR-1 Bravo o Ambulancia Alfa"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                />
              </div>

              <div>
                <label className="label">Tipo de vehículo</label>
                <select
                  className="input"
                  value={tipo}
                  onChange={(e) => setTipo(e.target.value as VehicleType)}
                >
                  {Object.keys(vehicleTypeConfig).map((k) => (
                    <option key={k} value={k}>
                      {vehicleTypeConfig[k as VehicleType].label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="label">Matrícula</label>
                <input
                  type="text"
                  className="input uppercase"
                  placeholder="Ej. 1234-KBC"
                  value={matricula}
                  onChange={(e) => setMatricula(e.target.value)}
                />
              </div>

              <div>
                <label className="label">Indicativo de Radio</label>
                <input
                  type="text"
                  className="input"
                  placeholder="Ej. BRAVO-1 o ECO-2"
                  value={indicativo}
                  onChange={(e) => setIndicativo(e.target.value)}
                />
              </div>

              <div>
                <label className="label">Estado operativo inicial</label>
                <select
                  className="input"
                  value={estado}
                  onChange={(e) => setEstado(e.target.value as VehicleStatus)}
                >
                  {Object.keys(vehicleStatusConfig).map((k) => (
                    <option key={k} value={k}>
                      {vehicleStatusConfig[k as VehicleStatus].label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="label">Kilometraje actual</label>
                <input
                  type="number"
                  className="input"
                  placeholder="Ej. 45200"
                  value={kilometraje}
                  onChange={(e) => setKilometraje(e.target.value)}
                />
              </div>

              <div>
                <label className="label">Vencimiento ITV</label>
                <input
                  type="date"
                  className="input"
                  value={itvCaducidad}
                  onChange={(e) => setItvCaducidad(e.target.value)}
                />
              </div>

              <div>
                <label className="label">Vencimiento Seguro</label>
                <input
                  type="date"
                  className="input"
                  value={seguroCaducidad}
                  onChange={(e) => setSeguroCaducidad(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label className="label">Equipamiento dotacional a bordo</label>
              <textarea
                className="input min-h-[64px] resize-none text-xs"
                placeholder="Ej. DESA Samaritan, Camilla tijera, Mochila soporte vital avanzado, Tablero espinal, Conos de balizamiento…"
                value={equipamiento}
                onChange={(e) => setEquipamiento(e.target.value)}
              />
            </div>

            <div>
              <label className="label">Notas mecánicas o de mantenimiento</label>
              <textarea
                className="input min-h-[50px] resize-none text-xs"
                placeholder="Observaciones de revisiones, neumáticos o aceite…"
                value={notas}
                onChange={(e) => setNotas(e.target.value)}
              />
            </div>

            <div className="flex gap-2 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="btn-outline flex-1 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveVehicle}
                disabled={saving}
                className="btn-primary flex-1 cursor-pointer font-bold"
              >
                {saving ? <Spinner size={16} /> : <CheckCircle2 size={16} />}
                <span>{editingVehicle ? 'Guardar Cambios' : 'Registrar Vehículo'}</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Diálogo de Confirmación para Borrar */}
      {vehicleToDelete && (
        <ConfirmDialog
          open={!!vehicleToDelete}
          title="¿Retirar vehículo del Parque Móvil?"
          message={`¿Estás seguro de que deseas eliminar permanentemente el vehículo "${vehicleToDelete.nombre}" (${vehicleToDelete.matricula || 'sin matrícula'})? Dejará de estar disponible para seleccionar en los partes y servicios.`}
          confirmText="Retirar de la flota"
          danger
          onConfirm={handleConfirmDelete}
          onClose={() => setVehicleToDelete(null)}
        />
      )}
    </div>
  );
}
