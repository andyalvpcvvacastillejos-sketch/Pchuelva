import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity,
  Calendar,
  Clock,
  Download,
  Droplet,
  Eye,
  FileText,
  HeartPulse,
  MapPin,
  Phone,
  Printer,
  RefreshCw,
  Stethoscope,
  Thermometer,
  Trash2,
  User,
  X,
  } from 'lucide-react';

import { supabase, isSupabaseConfigured, type MedicalReport } from '@/lib/supabase';
import { demoMedicalReports } from '@/lib/demoData';
import { useAuth } from '@/context/AuthContext';
import { getFleetVehicles } from '@/lib/fleetStorage';
import { Badge } from '@/components/ui/Badge';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { Spinner } from '@/components/ui/Spinner';
import { exportAsistenciasToCsv } from '@/lib/exportUtils';

interface ReportWithRelations extends MedicalReport {
  servicio_titulo?: string;
  vehiculo_nombre?: string;
  incident_descripcion?: string;
  incident_latitud?: number | null;
  incident_longitud?: number | null;
}

const resolutionLabels: Record<string, string> = {
  alta_lugar: 'Alta en el lugar',
  derivacion_centro: 'Derivación a centro sanitario',
  ambulancia_uvi: 'Ambulancia UVI (Prioridad Roja)',
};

const resolutionVariants: Record<string, 'success' | 'warning' | 'error'> = {
  alta_lugar: 'success',
  derivacion_centro: 'warning',
  ambulancia_uvi: 'error',
};

const avpuLabels: Record<string, string> = {
  alerta: 'A - Alerta, responde espontáneamente',
  voz: 'V - Responde a estímulos verbales',
  dolor: 'P - Responde únicamente al dolor',
  inconsciente: 'U - Inconsciente / Sin respuesta',
};

export function AsistenciasPage() {
  const { user, profile } = useAuth();
  const isStaff = profile?.role === 'admin_tecnico' || profile?.role === 'coordinador';
  const [reports, setReports] = useState<ReportWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterServicio, setFilterServicio] = useState<string>('all');
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [selectedReport, setSelectedReport] = useState<ReportWithRelations | null>(null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setActionNotice(msg);
    setTimeout(() => setActionNotice(null), 4000);
  };

  const fetchReports = useCallback(async () => {
    setLoading(true);

    let fleetLookup = new Map<string, string>();
    try {
      const fleet = await getFleetVehicles();
      fleet.forEach((v) => {
        fleetLookup.set(v.id, v.matricula ? `${v.nombre} (${v.matricula})` : v.nombre);
      });
    } catch { /* noop */ }

    if (!isSupabaseConfigured) {
      try {
        const storedReports = JSON.parse(localStorage.getItem('pc-huelva-demo-reports') || '[]') as MedicalReport[];
        const combined = [...storedReports, ...demoMedicalReports];
        const seen = new Set<string>();
        const deduped: ReportWithRelations[] = [];

        for (const r of combined) {
          if (!seen.has(r.id)) {
            seen.add(r.id);
            const vehName = r.vehiculo_id ? (fleetLookup.get(r.vehiculo_id) || 'Vehículo de dotación') : 'Sin vehículo';
            deduped.push({
              ...r,
              servicio_titulo: r.servicio_id ? 'Dispositivo Sanitario Huelva' : 'Dispositivo Sanitario Fiestas Colombinas 2026',
              vehiculo_nombre: vehName,
              incident_descripcion: 'Asistencia Sanitaria Operativa',
            });
          }
        }
        setReports(deduped);
      } catch {
        setReports(demoMedicalReports);
      } finally {
        setLoading(false);
      }
      return;
    }

    try {
      const { data, error } = await supabase
        .from('partes_sanitarios')
        .select(`
          *,
          incidencias_operativas (descripcion, latitud, longitud),
          servicios (titulo),
          vehiculos_operativos (nombre, matricula)
        `)
        .order('created_at', { ascending: false })
        .limit(200);

      if (error) {
        console.warn('Error fetching Supabase reports:', error);
      }

      const enriched = (data ?? []).map((r: Record<string, unknown>) => {
        const remoteVeh = r.vehiculos_operativos as { nombre?: string; matricula?: string } | null;
        const vehId = (r as unknown as MedicalReport).vehiculo_id;
        const resolvedName = vehId && fleetLookup.has(vehId)
          ? fleetLookup.get(vehId)
          : remoteVeh?.nombre
          ? (remoteVeh.matricula ? `${remoteVeh.nombre} (${remoteVeh.matricula})` : remoteVeh.nombre)
          : 'Sin vehículo asignado';

        return {
          ...(r as unknown as MedicalReport),
          servicio_titulo: (r.servicios as { titulo?: string } | null)?.titulo,
          vehiculo_nombre: resolvedName,
          incident_descripcion: (r.incidencias_operativas as { descripcion?: string } | null)?.descripcion,
          incident_latitud: (r.incidencias_operativas as { latitud?: number } | null)?.latitud ?? null,
          incident_longitud: (r.incidencias_operativas as { longitud?: number } | null)?.longitud ?? null,
        };
      });

      let localReports: MedicalReport[] = [];
      try {
        localReports = JSON.parse(localStorage.getItem('pc-huelva-demo-reports') || '[]') as MedicalReport[];
      } catch { /* noop */ }

      const enrichedIds = new Set(enriched.map((e) => e.id));
      const missingLocal = localReports
        .filter((lr) => !enrichedIds.has(lr.id))
        .map((lr) => ({
          ...lr,
          servicio_titulo: 'Dispositivo Sanitario Huelva',
          vehiculo_nombre: lr.vehiculo_id ? (fleetLookup.get(lr.vehiculo_id) || 'Vehículo de intervención') : 'Sin vehículo',
          incident_descripcion: 'Asistencia Sanitaria Operativa',
        }));

      setReports([...missingLocal, ...enriched]);
    } catch (err) {
      console.warn('Error fetching medical reports, using demo data:', err);
      let localReports: MedicalReport[] = [];
      try {
        localReports = JSON.parse(localStorage.getItem('pc-huelva-demo-reports') || '[]') as MedicalReport[];
      } catch { /* noop */ }
      setReports([...localReports, ...demoMedicalReports]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchReports();
  }, [fetchReports]);

  const handleDelete = async () => {
    if (!deleteTarget) return;

    // 1. Eliminar de almacenamiento local
    try {
      const stored = JSON.parse(localStorage.getItem('pc-huelva-demo-reports') || '[]') as MedicalReport[];
      localStorage.setItem('pc-huelva-demo-reports', JSON.stringify(stored.filter((r) => r.id !== deleteTarget)));
    } catch { /* noop */ }

    // 2. Si está configurado Supabase, eliminar en base de datos
    if (isSupabaseConfigured) {
      try {
        await supabase.from('partes_sanitarios').delete().eq('id', deleteTarget);
      } catch (err) {
        console.warn('Error eliminando parte en Supabase:', err);
      }
    }

    // 3. Actualizar estado en UI y cerrar modal si estaba abierto
    setReports((prev) => prev.filter((r) => r.id !== deleteTarget));
    if (selectedReport?.id === deleteTarget) {
      setSelectedReport(null);
    }
    setDeleteTarget(null);
    showNotification('Parte de asistencia eliminado correctamente.');
  };

  const groupedByServicio = useMemo(() => {
    const groups: Record<string, { serviceName: string; reports: ReportWithRelations[] }> = {};
    for (const r of reports) {
      const key = r.servicio_id ?? 'sin_servicio';
      const name = r.servicio_titulo ?? 'Servicio Operativo Ordinario';
      if (!groups[key]) groups[key] = { serviceName: name, reports: [] };
      groups[key].reports.push(r);
    }
    return groups;
  }, [reports]);

  const filteredKeys = filterServicio === 'all' ? Object.keys(groupedByServicio) : [filterServicio];
  const totalReports = filterServicio === 'all' ? reports.length : (groupedByServicio[filterServicio]?.reports.length ?? 0);

  return (
    <div className="px-4 py-4 max-w-4xl mx-auto space-y-4">
      {/* Encabezado */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary-600">Gestión sanitaria extrahospitalaria</p>
          <h1 className="text-xl font-bold text-gray-900">Historial de asistencias</h1>
          <p className="text-sm text-gray-500 mt-1">
            Consulta los partes sanitarios, revisa las constantes vitales completas o elimina registros.
          </p>
        </div>
        <div className="w-10 h-10 rounded-xl bg-yellow-100 text-yellow-700 flex items-center justify-center shrink-0">
          <Stethoscope size={22} />
        </div>
      </div>

      {actionNotice && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl px-4 py-2.5 text-xs font-medium animate-fade-in flex items-center justify-between">
          <span>{actionNotice}</span>
          <button onClick={() => setActionNotice(null)} className="text-emerald-600 hover:text-emerald-900 ml-2">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Filtros */}
      <div className="card p-3 flex items-center gap-2 flex-wrap">
        <p className="text-xs font-semibold text-gray-700 shrink-0">Filtrar por servicio:</p>
        <button
          onClick={() => setFilterServicio('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
            filterServicio === 'all'
              ? 'border-primary-500 bg-primary-50 text-primary-700'
              : 'border-gray-200 bg-white text-gray-500 hover:bg-gray-50'
          }`}
        >
          Todos ({reports.length})
        </button>
        {Object.entries(groupedByServicio).map(([key, group]) => (
          <button
            key={key}
            onClick={() => setFilterServicio(key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
              filterServicio === key
                ? 'border-primary-500 bg-primary-50 text-primary-700'
                : 'border-gray-200 bg-white text-gray-500 hover:bg-gray-50'
            }`}
          >
            {group.serviceName} ({group.reports.length})
          </button>
        ))}
        <button
          type="button"
          onClick={() => {
            const listToExport = filterServicio === 'all'
              ? reports
              : (groupedByServicio[filterServicio]?.reports ?? []);
            const serviceTitle = filterServicio === 'all'
              ? 'todas_las_asistencias'
              : (groupedByServicio[filterServicio]?.serviceName || 'servicio');
            exportAsistenciasToCsv(listToExport, serviceTitle);
            showNotification(`Exportadas ${listToExport.length} asistencias a archivo CSV.`);
          }}
          disabled={reports.length === 0}
          className="btn-outline text-xs py-1.5 px-3 flex items-center gap-1.5 text-primary-700 hover:bg-primary-50 ml-auto cursor-pointer shadow-xs disabled:opacity-50"
          title="Descargar datos en formato CSV para Excel o Calc"
        >
          <Download size={14} />
          <span>Exportar {filterServicio === 'all' ? 'asistencias' : 'servicio'} (CSV)</span>
        </button>

        <button
          onClick={fetchReports}
          className="p-2 rounded-lg text-primary-600 hover:bg-primary-50 cursor-pointer"
          aria-label="Actualizar"
          title="Actualizar listado"
        >
          <RefreshCw size={16} />
        </button>
      </div>

      <div className="flex items-center gap-2 text-xs text-gray-400">
        <FileText size={14} /> {loading ? 'Cargando asistencias…' : `${totalReports} partes de asistencia disponibles`}
      </div>

      {/* Listado de asistencias */}
      {loading ? (
        <div className="flex justify-center py-12">
          <Spinner size={28} />
        </div>
      ) : reports.length === 0 ? (
        <div className="card p-8 text-center space-y-2">
          <Stethoscope size={36} className="mx-auto text-gray-300 mb-2" />
          <p className="text-sm text-gray-500 font-medium">No hay partes de asistencia sanitaria registrados.</p>
          <p className="text-xs text-gray-400">
            Puedes abrir y completar un nuevo parte desde el Canal de Incidencias con el Asistente Clínico ERC 2025.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredKeys.map((key) => {
            const group = groupedByServicio[key];
            if (!group) return null;
            return (
              <div key={key} className="space-y-3">
                <div className="flex items-center gap-2 border-b border-gray-100 pb-2">
                  <div className="w-7 h-7 rounded-lg bg-primary-100 text-primary-700 flex items-center justify-center">
                    <Activity size={15} />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-gray-900">{group.serviceName}</h2>
                    <p className="text-[11px] text-gray-400">{group.reports.length} asistencia(s) en este dispositivo</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {group.reports.map((r) => (
                    <div
                      key={r.id}
                      className="card p-4 space-y-3 border hover:border-primary-200 transition-all flex flex-col justify-between"
                    >
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-semibold text-yellow-800 bg-yellow-50 rounded-lg px-2 py-0.5 flex items-center gap-1 border border-yellow-200/50">
                            <Calendar size={12} />
                            {new Date(r.created_at).toLocaleString('es-ES', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                          <Badge variant={resolutionVariants[r.resolucion] ?? 'gray'}>
                            {resolutionLabels[r.resolucion] ?? r.resolucion}
                          </Badge>
                        </div>

                        <div>
                          <p className="text-sm font-semibold text-gray-900 line-clamp-2">{r.motivo_asistencia}</p>
                          {r.paciente_nombre && (
                            <p className="text-xs text-gray-600 flex items-center gap-1 mt-1">
                              <User size={12} className="text-gray-400 shrink-0" />
                              <span className="font-medium">{r.paciente_nombre}</span>
                              {r.paciente_edad ? `, ${r.paciente_edad} años` : ''}
                              {r.paciente_dni ? ` (DNI: ${r.paciente_dni})` : ''}
                            </p>
                          )}
                          {r.direccion && (
                            <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                              <MapPin size={12} className="text-gray-400 shrink-0" />
                              <span className="truncate">{r.direccion}</span>
                            </p>
                          )}
                        </div>

                        {/* Fila de constantes vitales clave */}
                        {(r.fc || r.tas || r.spo2 || r.temperatura || r.glucemia || r.nivel_conciencia) && (
                          <div className="flex flex-wrap gap-1.5 pt-1">
                            {r.fc && (
                              <span className="text-[10px] bg-red-50 text-red-700 border border-red-100 rounded px-1.5 py-0.5 font-mono">
                                FC: {r.fc}
                              </span>
                            )}
                            {r.tas && r.tad && (
                              <span className="text-[10px] bg-purple-50 text-purple-700 border border-purple-100 rounded px-1.5 py-0.5 font-mono">
                                TA: {r.tas}/{r.tad}
                              </span>
                            )}
                            {r.spo2 && (
                              <span className="text-[10px] bg-blue-50 text-blue-700 border border-blue-100 rounded px-1.5 py-0.5 font-mono">
                                SpO2: {r.spo2}%
                              </span>
                            )}
                            {r.temperatura && (
                              <span className="text-[10px] bg-amber-50 text-amber-700 border border-amber-100 rounded px-1.5 py-0.5 font-mono">
                                Tª: {r.temperatura}°
                              </span>
                            )}
                            {r.glucemia && (
                              <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-100 rounded px-1.5 py-0.5 font-mono">
                                Glu: {r.glucemia}
                              </span>
                            )}
                            {r.nivel_conciencia && (
                              <span className="text-[10px] bg-gray-100 text-gray-700 rounded px-1.5 py-0.5 uppercase font-mono">
                                AVPU: {r.nivel_conciencia}
                              </span>
                            )}
                          </div>
                        )}

                        {r.tratamiento && (
                          <p className="text-xs text-gray-600 bg-gray-50 rounded-lg p-2 line-clamp-2 border border-gray-100">
                            <span className="font-medium text-gray-700">Tratamiento:</span> {r.tratamiento}
                          </p>
                        )}
                      </div>

                      {/* Botonera de acciones (Ver en detalle / Eliminar) */}
                      <div className="pt-2 border-t border-gray-100 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedReport(r)}
                          className="btn-outline text-xs py-1.5 px-3 flex items-center gap-1.5 text-primary-700 hover:bg-primary-50 cursor-pointer"
                        >
                          <Eye size={14} />
                          <span>Ver detalle</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeleteTarget(r.id)}
                          className="p-1.5 rounded-lg text-error-600 hover:bg-error-50 hover:text-error-700 transition-colors cursor-pointer flex items-center gap-1 text-xs"
                          title="Eliminar este parte de asistencia"
                        >
                          <Trash2 size={15} />
                          <span className="hidden sm:inline text-[11px] font-medium">Eliminar</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL DE DETALLE COMPLETO DEL PARTE */}
      {selectedReport && (
        <div
          className="fixed inset-0 flex items-center justify-center bg-black/60 p-3 overflow-y-auto animate-fade-in"
          style={{ zIndex: 1250 }}
        >
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full my-6 flex flex-col max-h-[92vh] overflow-hidden border border-gray-100">
            {/* Cabecera del modal */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100 bg-gray-50/70">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center shadow-xs">
                  <Stethoscope size={22} />
                </div>
                <div>
                  <h2 className="text-base font-bold text-gray-900">Parte de Asistencia Sanitaria</h2>
                  <p className="text-xs text-gray-500">
                    ID: {selectedReport.id} · {new Date(selectedReport.created_at).toLocaleString('es-ES')}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="p-2 text-gray-500 hover:text-gray-800 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors"
                  title="Imprimir / Exportar documento"
                >
                  <Printer size={18} />
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedReport(null)}
                  className="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors"
                  title="Cerrar ventana"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Contenido imprimible / legible */}
            <div className="overflow-y-auto p-5 space-y-5 print:p-0">
              {/* Resolución y Servicio */}
              <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-primary-50/50 rounded-xl border border-primary-100">
                <div>
                  <p className="text-[11px] font-semibold text-primary-700 uppercase tracking-wider">Dispositivo / Servicio</p>
                  <p className="text-sm font-bold text-gray-900">
                    {selectedReport.servicio_titulo || 'Servicio Operativo Ordinario'}
                  </p>
                  {selectedReport.vehiculo_nombre && (
                    <p className="text-xs text-gray-600 mt-0.5">
                      Vehículo: <span className="font-semibold">{selectedReport.vehiculo_nombre}</span>
                    </p>
                  )}
                </div>
                <div className="text-right">
                  <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">Resolución médica</p>
                  <Badge variant={resolutionVariants[selectedReport.resolucion] ?? 'gray'} className="text-xs mt-1">
                    {resolutionLabels[selectedReport.resolucion] ?? selectedReport.resolucion}
                  </Badge>
                </div>
              </div>

              {/* Datos del Paciente */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 flex items-center gap-1.5">
                  <User size={14} className="text-primary-600" /> Datos de Filiación del Paciente
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-gray-50 rounded-xl border border-gray-100 text-xs">
                  <div>
                    <span className="text-gray-400 block">Nombre y apellidos:</span>
                    <span className="font-semibold text-gray-900 text-sm">
                      {selectedReport.paciente_nombre || 'No aportado / Anónimo'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">DNI / NIE / Pasaporte:</span>
                    <span className="font-mono font-semibold text-gray-900">
                      {selectedReport.paciente_dni || 'No registrado'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">Edad:</span>
                    <span className="font-medium text-gray-800">
                      {selectedReport.paciente_edad ? `${selectedReport.paciente_edad} años` : 'No especificada'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">Teléfono de contacto:</span>
                    <span className="font-medium text-gray-800 flex items-center gap-1">
                      {selectedReport.paciente_telefono ? (
                        <>
                          <Phone size={11} className="text-primary-600" />
                          {selectedReport.paciente_telefono}
                        </>
                      ) : (
                        'No facilitado'
                      )}
                    </span>
                  </div>
                  <div className="sm:col-span-2">
                    <span className="text-gray-400 block">Lugar / Dirección de la asistencia:</span>
                    <span className="font-medium text-gray-800 flex items-center gap-1">
                      <MapPin size={12} className="text-primary-600 shrink-0" />
                      {selectedReport.direccion || 'Ubicación operativa en vía pública'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Constantes Vitales - Panel visual */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 flex items-center gap-1.5">
                  <HeartPulse size={14} className="text-red-500" /> Constantes Vitales (ERC 2025)
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  <div className="p-3 bg-red-50/60 rounded-xl border border-red-100">
                    <span className="text-[11px] text-red-600 block font-medium">Frecuencia Cardíaca</span>
                    <span className="text-lg font-bold font-mono text-red-950">
                      {selectedReport.fc ? `${selectedReport.fc} lpm` : '—'}
                    </span>
                  </div>

                  <div className="p-3 bg-purple-50/60 rounded-xl border border-purple-100">
                    <span className="text-[11px] text-purple-600 block font-medium">Tensión Arterial</span>
                    <span className="text-lg font-bold font-mono text-purple-950">
                      {selectedReport.tas && selectedReport.tad ? `${selectedReport.tas}/${selectedReport.tad} mmHg` : '—'}
                    </span>
                  </div>

                  <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100">
                    <span className="text-[11px] text-blue-600 block font-medium">Sat. Oxígeno (SpO2)</span>
                    <span className="text-lg font-bold font-mono text-blue-950">
                      {selectedReport.spo2 ? `${selectedReport.spo2}%` : '—'}
                    </span>
                  </div>

                  <div className="p-3 bg-orange-50/60 rounded-xl border border-orange-100">
                    <span className="text-[11px] text-orange-600 block font-medium">Temperatura</span>
                    <span className="text-lg font-bold font-mono text-orange-950">
                      {selectedReport.temperatura ? `${selectedReport.temperatura} °C` : '—'}
                    </span>
                  </div>

                  <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100">
                    <span className="text-[11px] text-emerald-600 block font-medium">Glucemia Capilar</span>
                    <span className="text-lg font-bold font-mono text-emerald-950">
                      {selectedReport.glucemia ? `${selectedReport.glucemia} mg/dl` : '—'}
                    </span>
                  </div>

                  <div className="p-3 bg-gray-100/70 rounded-xl border border-gray-200">
                    <span className="text-[11px] text-gray-600 block font-medium">Nivel Conciencia (AVPU)</span>
                    <span className="text-xs font-bold uppercase font-mono text-gray-900 block mt-1">
                      {selectedReport.nivel_conciencia
                        ? avpuLabels[selectedReport.nivel_conciencia] ?? selectedReport.nivel_conciencia
                        : 'No registrado'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Motivo de la asistencia */}
              <div className="space-y-1.5">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">Motivo de Asistencia y Anamnesis</h3>
                <div className="p-3.5 bg-gray-50 rounded-xl border border-gray-100 text-xs text-gray-800 whitespace-pre-wrap leading-relaxed">
                  {selectedReport.motivo_asistencia}
                </div>
              </div>

              {/* Tratamiento y Medidas aplicadas */}
              {selectedReport.tratamiento && (
                <div className="space-y-1.5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">Tratamiento y Primeros Auxilios</h3>
                  <div className="p-3.5 bg-yellow-50/60 rounded-xl border border-yellow-200/60 text-xs text-yellow-950 whitespace-pre-wrap leading-relaxed">
                    {selectedReport.tratamiento}
                  </div>
                </div>
              )}

              {/* Coordenadas GPS */}
              {selectedReport.incident_latitud != null && selectedReport.incident_longitud != null && (
                <div className="flex items-center gap-2 text-xs text-gray-500 bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <MapPin size={14} className="text-primary-600 shrink-0" />
                  <span>
                    Coordenadas GPS de intervención: {selectedReport.incident_latitud.toFixed(5)},{' '}
                    {selectedReport.incident_longitud.toFixed(5)}
                  </span>
                </div>
              )}
            </div>

            {/* Pie del modal con acciones */}
            <div className="px-5 py-3 border-t border-gray-100 bg-gray-50 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  setDeleteTarget(selectedReport.id);
                }}
                className="btn-danger text-xs py-2 px-3 flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 size={14} />
                <span>Eliminar parte</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    exportAsistenciasToCsv([selectedReport], selectedReport.servicio_titulo || 'asistencia');
                    showNotification('Parte descargado en formato CSV.');
                  }}
                  className="btn-outline text-xs py-2 px-3 flex items-center gap-1.5 cursor-pointer"
                  title="Descargar este parte en formato CSV para Excel"
                >
                  <Download size={14} />
                  <span>Exportar CSV</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="btn-outline text-xs py-2 px-3 flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer size={14} />
                  <span>Imprimir</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedReport(null)}
                  className="btn-primary text-xs py-2 px-4 cursor-pointer"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DIÁLOGO DE CONFIRMACIÓN DE ELIMINACIÓN */}
      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Eliminar parte de asistencia sanitaria"
        message="¿Estás seguro de que deseas eliminar este parte de asistencia sanitaria de los registros? Esta acción no se puede deshacer."
        confirmText="Eliminar permanentemente"
        danger
      />
    </div>
  );
}
