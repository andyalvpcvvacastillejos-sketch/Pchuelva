import { useCallback, useEffect, useState, type ChangeEvent } from 'react';
import {
  Camera,
  CheckCircle2,
  Crosshair,
  Download,
  FileText,
  MapPin,
  RefreshCw,
  Send,
  Stethoscope,
  TriangleAlert,
  WifiOff,
  Sparkles,
  Filter,
  Trash2,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, isSupabaseConfigured, type IncidentCategory, type OperativeIncident, type Servicio } from '@/lib/supabase';
import { demoServicios } from '@/lib/demoData';
import { ParteSanitarioModal } from '@/components/ParteSanitarioModal';
import { Badge } from '@/components/ui/Badge';
import { Spinner } from '@/components/ui/Spinner';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { exportIncidenciasToCsv } from '@/lib/exportUtils';

const pendingKey = 'pc-huelva-pending-incidents';

const categoryConfig: Record<IncidentCategory, { label: string; shortLabel: string; dot: string; active: string }> = {
  urgente_refuerzos: { label: 'Urgente / Refuerzos', shortLabel: 'Urgente', dot: 'bg-red-500', active: 'border-red-500 bg-red-50 text-red-800' },
  sanitaria: { label: 'Sanitaria', shortLabel: 'Sanitaria', dot: 'bg-yellow-400', active: 'border-yellow-400 bg-yellow-50 text-yellow-900' },
  trafico_via_publica: { label: 'Tráfico / Vía Pública', shortLabel: 'Tráfico', dot: 'bg-blue-500', active: 'border-blue-500 bg-blue-50 text-blue-800' },
  aviso_general: { label: 'Aviso General', shortLabel: 'Aviso', dot: 'bg-green-500', active: 'border-green-500 bg-green-50 text-green-800' },
};

interface PendingIncident {
  id: string;
  categoria: IncidentCategory;
  descripcion: string;
  latitud: number | null;
  longitud: number | null;
  created_at: string;
  sync_state: 'pending';
  servicio_id?: string | null;
}

interface IncidentWithReports extends OperativeIncident {
  report_count?: number;
  servicio_id?: string | null;
  servicio_titulo?: string;
  is_local_only?: boolean;
}

function readPendingIncidents(): PendingIncident[] {
  try {
    const saved = JSON.parse(localStorage.getItem(pendingKey) ?? '[]') as PendingIncident[];
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function savePendingIncident(incident: PendingIncident) {
  localStorage.setItem(pendingKey, JSON.stringify([incident, ...readPendingIncidents()].slice(0, 30)));
}

export function IncidenciasPage() {
  const { user, profile } = useAuth();
  const canDelete = profile?.role === 'admin_tecnico' || profile?.role === 'coordinador';

  const [category, setCategory] = useState<IncidentCategory>('urgente_refuerzos');
  const [description, setDescription] = useState('');
  const [coordinates, setCoordinates] = useState<{ latitud: number; longitud: number } | null>(null);
  const [locationStatus, setLocationStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [photo, setPhoto] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [incidents, setIncidents] = useState<IncidentWithReports[]>([]);
  const [pending, setPending] = useState<PendingIncident[]>(readPendingIncidents);
  const [services, setServices] = useState<Servicio[]>(demoServicios);
  const [incidentServiceId, setIncidentServiceId] = useState<string>('');
  const [filterServiceId, setFilterServiceId] = useState<string>('all');
  const [loading, setLoading] = useState(false);
  const [loadingList, setLoadingList] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savedIncidentId, setSavedIncidentId] = useState<string | null>(null);
  const [incidentToDelete, setIncidentToDelete] = useState<IncidentWithReports | null>(null);

  // Cargar lista de servicios preventivos
  useEffect(() => {
    const loadServices = async () => {
      if (!isSupabaseConfigured) {
        setServices(demoServicios);
        return;
      }
      try {
        const { data } = await supabase.from('servicios').select('*').order('fecha', { ascending: false }).limit(20);
        if (data && data.length > 0) {
          setServices(data as Servicio[]);
        } else {
          setServices(demoServicios);
        }
      } catch {
        setServices(demoServicios);
      }
    };
    loadServices();
  }, []);

  const fetchIncidents = useCallback(async () => {
    setLoadingList(true);
    let storedReports: { incident_id?: string }[] = [];
    try {
      storedReports = JSON.parse(localStorage.getItem('pc-huelva-demo-reports') || '[]');
    } catch { /* noop */ }

    let storedIncidents: IncidentWithReports[] = [];
    try {
      storedIncidents = JSON.parse(localStorage.getItem('pc-huelva-demo-incidents') || '[]');
    } catch { /* noop */ }

    const pendingList = readPendingIncidents();
    const pendingIncidents: IncidentWithReports[] = pendingList.map((p) => ({
      id: p.id,
      user_id: user?.id || 'demo-user-123',
      categoria: p.categoria,
      descripcion: p.descripcion,
      latitud: p.latitud,
      longitud: p.longitud,
      foto_path: null,
      estado: 'abierta',
      created_at: p.created_at,
      report_count: 0,
      servicio_id: p.servicio_id || null,
      is_local_only: true,
    }));

    let dbIncidents: IncidentWithReports[] = [];
    if (isSupabaseConfigured) {
      try {
        const { data } = await supabase.from('incidencias_operativas').select('*').order('created_at', { ascending: false }).limit(25);
        const incidentList = (data ?? []) as OperativeIncident[];
        for (const incident of incidentList) {
          const { count } = await supabase.from('partes_sanitarios').select('*', { count: 'exact', head: true }).eq('incident_id', incident.id);
          const localMatches = storedReports.filter((r) => r.incident_id === incident.id).length;
          dbIncidents.push({ ...incident, report_count: (count ?? 0) + localMatches });
        }
      } catch (err) {
        console.warn('Error fetching db incidents:', err);
      }
    }

    const defaultIncidents: IncidentWithReports[] = [
      {
        id: 'demo-inc-1',
        user_id: 'demo-user-123',
        categoria: 'sanitaria',
        descripcion: 'Asistencia en Plaza de las Monjas - Varón de 58 años con dolor torácico opresivo y sudoración fría',
        latitud: 37.2614,
        longitud: -6.9447,
        foto_path: null,
        estado: 'abierta',
        created_at: new Date().toISOString(),
        report_count: 1,
        servicio_id: 'demo-serv-1',
      },
      {
        id: 'demo-inc-2',
        user_id: 'demo-user-123',
        categoria: 'urgente_refuerzos',
        descripcion: 'Caída de bicicleta en Gran Vía con traumatismo en miembro superior y contusión',
        latitud: 37.2592,
        longitud: -6.9482,
        foto_path: null,
        estado: 'abierta',
        created_at: new Date(Date.now() - 3600000).toISOString(),
        report_count: 0,
        servicio_id: 'demo-serv-2',
      },
    ];

    let deletedIds = new Set<string>();
    try {
      deletedIds = new Set<string>(JSON.parse(localStorage.getItem('pc-huelva-deleted-incidents') || '[]'));
    } catch { /* noop */ }

    const combined = [...dbIncidents, ...pendingIncidents, ...storedIncidents, ...defaultIncidents];
    const seen = new Set<string>();
    const deduped: IncidentWithReports[] = [];

    for (const item of combined) {
      if (!seen.has(item.id) && !deletedIds.has(item.id)) {
        seen.add(item.id);
        const localCount = storedReports.filter((r) => r.incident_id === item.id).length;
        const sMatch = services.find((s) => s.id === item.servicio_id);
        deduped.push({
          ...item,
          servicio_titulo: sMatch?.titulo || undefined,
          report_count: (item.report_count ?? 0) > 0 ? item.report_count : localCount,
        });
      }
    }

    setIncidents(deduped);
    setPending(pendingList.filter((p) => !deletedIds.has(p.id)));
    setLoadingList(false);
  }, [user?.id, services]);

  const handleDeleteIncident = async (incident: IncidentWithReports) => {
    try {
      // 1. Persistir ID en la lista de eliminados
      let deletedList: string[] = [];
      try {
        deletedList = JSON.parse(localStorage.getItem('pc-huelva-deleted-incidents') || '[]');
      } catch { /* noop */ }

      if (!deletedList.includes(incident.id)) {
        deletedList.push(incident.id);
        localStorage.setItem('pc-huelva-deleted-incidents', JSON.stringify(deletedList));
      }

      // 2. Eliminar de pendientes locales
      const curPending = readPendingIncidents().filter((p) => p.id !== incident.id);
      localStorage.setItem(pendingKey, JSON.stringify(curPending));
      setPending(curPending);

      // 3. Eliminar de incidencias de demostración almacenadas
      try {
        const curStored = JSON.parse(localStorage.getItem('pc-huelva-demo-incidents') || '[]')
          .filter((i: any) => i.id !== incident.id);
        localStorage.setItem('pc-huelva-demo-incidents', JSON.stringify(curStored));
      } catch { /* noop */ }

      // 4. Si Supabase está conectado, eliminar en la base de datos
      if (isSupabaseConfigured) {
        try {
          await supabase.from('incidencias_operativas').delete().eq('id', incident.id);
        } catch (dbErr) {
          console.warn('Error al eliminar incidencia en Supabase:', dbErr);
        }
      }

      // 5. Actualizar estado
      setIncidents((prev) => prev.filter((i) => i.id !== incident.id));
      setMessage('Incidencia eliminada del sistema.');
      setTimeout(() => setMessage(null), 3000);
    } catch {
      setError('Ocurrió un error al eliminar la incidencia.');
      setTimeout(() => setError(null), 3000);
    } finally {
      setIncidentToDelete(null);
    }
  };

  useEffect(() => {
    fetchIncidents();
  }, [fetchIncidents]);

  useEffect(() => {
    if (!photo) {
      setPhotoPreview(null);
      return;
    }
    const url = URL.createObjectURL(photo);
    setPhotoPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [photo]);

  const captureLocation = () => {
    if (!navigator.geolocation) {
      setLocationStatus('error');
      return;
    }
    setLocationStatus('loading');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoordinates({
          latitud: Number(position.coords.latitude.toFixed(6)),
          longitud: Number(position.coords.longitude.toFixed(6)),
        });
        setLocationStatus('ready');
      },
      () => setLocationStatus('error'),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 },
    );
  };

  useEffect(() => {
    captureLocation();
  }, []);

  const handlePhoto = (event: ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0] ?? null;
    event.target.value = '';
    if (!selected) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(selected.type) || selected.size > 5 * 1024 * 1024) {
      setError('La foto debe ser JPG, PNG o WebP y pesar menos de 5 MB.');
      return;
    }
    setError(null);
    setPhoto(selected);
  };

  const handleSyncPending = async () => {
    if (pending.length === 0) return;
    setSyncing(true);
    if (!navigator.onLine || !isSupabaseConfigured) {
      setTimeout(() => {
        setSyncing(false);
        setMessage('Incidencias guardadas en el dispositivo de forma segura. Se conservan para consulta y partes sanitarios.');
        setTimeout(() => setMessage(null), 4000);
      }, 500);
      return;
    }

    const remaining: PendingIncident[] = [];
    for (const p of pending) {
      try {
        const { error: insertErr } = await supabase.from('incidencias_operativas').insert({
          categoria: p.categoria,
          descripcion: p.descripcion,
          latitud: p.latitud,
          longitud: p.longitud,
          foto_path: null,
          estado: 'abierta',
        });
        if (insertErr) {
          remaining.push(p);
        }
      } catch {
        remaining.push(p);
      }
    }

    localStorage.setItem(pendingKey, JSON.stringify(remaining));
    setPending(remaining);
    setSyncing(false);
    if (remaining.length === 0) {
      setMessage('Todas las incidencias han sido sincronizadas.');
    } else {
      setMessage(`Se han sincronizado ${pending.length - remaining.length} incidencias.`);
    }
    setTimeout(() => setMessage(null), 4000);
    await fetchIncidents();
  };

  const handleSubmit = async () => {
    if (!user || description.trim().length < 3) {
      setError('Escribe una descripción breve de al menos 3 caracteres.');
      return;
    }
    setLoading(true);
    setError(null);
    setMessage(null);

    const sMatch = services.find((s) => s.id === incidentServiceId);

    // Guardado local inmediato garantizado
    const localId = `inc-${Date.now()}`;
    const newLocalInc: IncidentWithReports = {
      id: localId,
      user_id: user.id,
      categoria: category,
      descripcion: description.trim(),
      latitud: coordinates?.latitud ?? null,
      longitud: coordinates?.longitud ?? null,
      foto_path: null,
      estado: 'abierta',
      created_at: new Date().toISOString(),
      report_count: 0,
      servicio_id: incidentServiceId || null,
      servicio_titulo: sMatch?.titulo || undefined,
    };

    if (!isSupabaseConfigured) {
      setIncidents((prev) => [newLocalInc, ...prev]);
      try {
        const stored = JSON.parse(localStorage.getItem('pc-huelva-demo-incidents') || '[]');
        localStorage.setItem('pc-huelva-demo-incidents', JSON.stringify([newLocalInc, ...stored]));
      } catch { /* noop */ }
      setMessage('Incidencia registrada.');
      setDescription('');
      setPhoto(null);
      if (category === 'sanitaria') {
        setSavedIncidentId(localId);
      }
      setLoading(false);
      return;
    }

    if (!navigator.onLine) {
      const queued: PendingIncident = {
        id: localId,
        categoria: category,
        descripcion: description.trim(),
        latitud: coordinates?.latitud ?? null,
        longitud: coordinates?.longitud ?? null,
        created_at: new Date().toISOString(),
        sync_state: 'pending',
        servicio_id: incidentServiceId || null,
      };
      savePendingIncident(queued);
      setPending(readPendingIncidents());
      setIncidents((prev) => [newLocalInc, ...prev]);
      try {
        const stored = JSON.parse(localStorage.getItem('pc-huelva-demo-incidents') || '[]');
        localStorage.setItem('pc-huelva-demo-incidents', JSON.stringify([newLocalInc, ...stored]));
      } catch { /* noop */ }
      setMessage('Guardada en el dispositivo (sin conexión).');
      setDescription('');
      setPhoto(null);
      if (category === 'sanitaria') {
        setSavedIncidentId(localId);
      }
      setLoading(false);
      return;
    }

    let uploadedPath: string | null = null;
    try {
      if (photo) {
        const extension = photo.type.split('/')[1].replace('jpeg', 'jpg');
        uploadedPath = `${user.id}/${crypto.randomUUID()}.${extension}`;
        const { error: uploadError } = await supabase.storage.from('incident-photos').upload(uploadedPath, photo, { contentType: photo.type, upsert: false });
        if (uploadError) throw uploadError;
      }

      const { data: insertData, error: insertError } = await supabase.from('incidencias_operativas').insert({
        categoria: category,
        descripcion: description.trim(),
        latitud: coordinates?.latitud ?? null,
        longitud: coordinates?.longitud ?? null,
        foto_path: uploadedPath,
      }).select().single();

      if (insertError) throw insertError;
      setMessage('Incidencia registrada y compartida con el equipo.');
      setDescription('');
      setPhoto(null);
      if (category === 'sanitaria' && insertData) {
        setSavedIncidentId(insertData.id);
      }
      await fetchIncidents();
    } catch {
      if (uploadedPath) {
        await supabase.storage.from('incident-photos').remove([uploadedPath]).catch(() => {});
      }
      const queued: PendingIncident = {
        id: localId,
        categoria: category,
        descripcion: description.trim(),
        latitud: coordinates?.latitud ?? null,
        longitud: coordinates?.longitud ?? null,
        created_at: new Date().toISOString(),
        sync_state: 'pending',
        servicio_id: incidentServiceId || null,
      };
      savePendingIncident(queued);
      setPending(readPendingIncidents());
      setIncidents((prev) => [newLocalInc, ...prev.filter((i) => i.id !== localId)]);
      try {
        const stored = JSON.parse(localStorage.getItem('pc-huelva-demo-incidents') || '[]');
        localStorage.setItem('pc-huelva-demo-incidents', JSON.stringify([newLocalInc, ...stored.filter((i: any) => i.id !== localId)]));
      } catch { /* noop */ }
      setMessage('Incidencia guardada en el dispositivo.');
      if (category === 'sanitaria') {
        setSavedIncidentId(localId);
      }
      setDescription('');
      setPhoto(null);
    } finally {
      setLoading(false);
    }
  };

  // Filtrado de incidencias por servicio
  const filteredIncidents = incidents.filter((inc) => {
    if (filterServiceId === 'all') return true;
    return inc.servicio_id === filterServiceId;
  });

  const selectedServiceObj = services.find((s) => s.id === filterServiceId);

  const handleExportFiltered = () => {
    const label = selectedServiceObj ? selectedServiceObj.titulo : 'todas';
    exportIncidenciasToCsv(filteredIncidents, label);
  };

  const locationText =
    locationStatus === 'loading'
      ? 'Obteniendo ubicación…'
      : locationStatus === 'ready' && coordinates
      ? `${coordinates.latitud.toFixed(5)}, ${coordinates.longitud.toFixed(5)}`
      : locationStatus === 'error'
      ? 'Ubicación no disponible'
      : 'Sin ubicación';

  return (
    <div className="px-4 py-4 max-w-2xl mx-auto space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary-600">Canal operativo</p>
          <h1 className="text-xl font-bold text-gray-900">Registro rápido de incidencias</h1>
          <p className="text-sm text-gray-500 mt-1">Comunica lo que ocurre sobre el terreno en pocos segundos.</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleExportFiltered}
            disabled={filteredIncidents.length === 0}
            className="btn-outline text-xs py-2 px-3 flex items-center gap-1.5 text-primary-700 hover:bg-primary-50 cursor-pointer shadow-xs disabled:opacity-50"
            title="Exportar incidencias en CSV"
          >
            <Download size={14} />
            <span className="hidden sm:inline">Exportar (CSV)</span>
          </button>
          <div className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
            <TriangleAlert size={22} />
          </div>
        </div>
      </div>

      {/* Banner de acceso directo al Asistente Clínico ERC 2025 */}
      <div className="rounded-2xl bg-gradient-to-r from-primary-800 to-primary-950 p-4 text-white shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur flex items-center justify-center text-yellow-300 shrink-0">
            <Stethoscope size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white">Parte Sanitario y Asistente ERC 2025</h2>
              <span className="text-[10px] bg-yellow-400 text-yellow-950 font-bold px-2 py-0.5 rounded-full">
                Voz / Texto · Ultrarrápido
              </span>
            </div>
            <p className="text-xs text-primary-200 mt-0.5">
              Habla o escribe al asistente clínico para completar constantes y primeros auxilios al instante.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            const sanitary = incidents.find((i) => i.categoria === 'sanitaria') || incidents[0];
            if (sanitary) {
              setSavedIncidentId(sanitary.id);
            } else {
              const newId = `inc-sanitaria-${Date.now()}`;
              const autoInc: IncidentWithReports = {
                id: newId,
                user_id: user?.id || 'demo-user-123',
                categoria: 'sanitaria',
                descripcion: 'Asistencia Sanitaria Operativa',
                latitud: coordinates?.latitud ?? null,
                longitud: coordinates?.longitud ?? null,
                foto_path: null,
                estado: 'abierta',
                created_at: new Date().toISOString(),
                report_count: 0,
              };
              setIncidents((prev) => [autoInc, ...prev]);
              try {
                const stored = JSON.parse(localStorage.getItem('pc-huelva-demo-incidents') || '[]');
                localStorage.setItem('pc-huelva-demo-incidents', JSON.stringify([autoInc, ...stored]));
              } catch { /* noop */ }
              setSavedIncidentId(newId);
            }
          }}
          className="btn bg-white text-primary-900 hover:bg-primary-50 text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs shrink-0 flex items-center gap-2 cursor-pointer"
        >
          <Sparkles size={16} className="text-primary-600" />
          <span>Abrir Asistente Clínico</span>
        </button>
      </div>

      {/* Formulario de registro */}
      <div className="card p-4 space-y-4">
        <div>
          <p className="label">Tipo de incidencia</p>
          <div className="grid grid-cols-2 gap-2">
            {(Object.keys(categoryConfig) as IncidentCategory[]).map((item) => {
              const config = categoryConfig[item];
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => setCategory(item)}
                  className={`min-h-14 rounded-xl border-2 px-3 py-2 text-left flex items-center gap-2 transition-all ${
                    category === item ? config.active : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300'
                  }`}
                >
                  <span className={`w-3 h-3 rounded-full flex-shrink-0 ${config.dot}`} />
                  <div>
                    <span className="text-sm font-semibold">{config.label}</span>
                    {item === 'sanitaria' && (
                      <span className="block text-[10px] opacity-70 mt-0.5">Incluye Parte de Asistencia</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Servicio operativo opcional */}
        <div>
          <label className="label">Vincular a servicio / dispositivo preventivo (opcional)</label>
          <select
            className="input text-xs"
            value={incidentServiceId}
            onChange={(e) => setIncidentServiceId(e.target.value)}
          >
            <option value="">Sin servicio específico (Incidencia general)</option>
            {services.map((s) => (
              <option key={s.id} value={s.id}>
                {s.titulo} ({new Date(s.fecha).toLocaleDateString('es-ES')})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="label" htmlFor="incident-description">
            Descripción breve
          </label>
          <textarea
            id="incident-description"
            className="input min-h-[92px] resize-none"
            maxLength={500}
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            placeholder="Qué ocurre, dónde y qué apoyo se necesita…"
          />
          <p className="text-[11px] text-gray-400 text-right mt-1">{description.length}/500</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button type="button" onClick={captureLocation} className="btn-outline justify-start">
            <Crosshair size={17} className={locationStatus === 'loading' ? 'animate-spin' : ''} />
            <span className="truncate">{locationText}</span>
          </button>
          <label className="btn-outline justify-start cursor-pointer">
            <Camera size={17} />
            <span className="truncate">{photo ? photo.name : 'Añadir foto'}</span>
            <input type="file" accept="image/*" capture="environment" onChange={handlePhoto} className="hidden" />
          </label>
        </div>

        {photoPreview && (
          <div className="relative rounded-xl overflow-hidden h-36 bg-gray-100">
            <img src={photoPreview} alt="Vista previa de la incidencia" className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => setPhoto(null)}
              className="absolute top-2 right-2 bg-black/60 text-white rounded-lg px-2 py-1 text-xs"
            >
              Quitar
            </button>
          </div>
        )}

        {error && <p className="text-sm text-error-600 bg-error-50 rounded-xl px-3 py-2">{error}</p>}
        {message && (
          <p className="text-sm text-success-700 bg-success-50 rounded-xl px-3 py-2 flex items-center gap-2">
            <CheckCircle2 size={16} />
            {message}
          </p>
        )}

        <button type="button" onClick={handleSubmit} disabled={loading} className="btn-danger w-full cursor-pointer">
          <Send size={17} />
          {loading ? 'Registrando incidencia…' : 'Registrar incidencia'}
        </button>

        {category === 'sanitaria' && (
          <div className="rounded-xl bg-yellow-50 border border-yellow-200 px-3 py-2.5 flex items-center gap-2">
            <Stethoscope size={16} className="text-yellow-700 flex-shrink-0" />
            <p className="text-xs text-yellow-900">
              Al registrar la incidencia se abrirá el Parte de Asistencia Sanitaria con el Asistente Clínico (dictado por voz o texto).
            </p>
          </div>
        )}
      </div>

      {/* Alerta de incidencias pendientes / locales con sincronización explícita */}
      {pending.length > 0 && (
        <div className="rounded-2xl border border-yellow-200 bg-yellow-50 p-3.5 space-y-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2 text-yellow-900 font-semibold text-xs sm:text-sm">
              <WifiOff size={16} />
              <span>Incidencias conservadas en el dispositivo: {pending.length}</span>
            </div>
            <button
              type="button"
              onClick={handleSyncPending}
              disabled={syncing}
              className="btn-outline bg-white text-xs py-1 px-3 text-yellow-900 hover:bg-yellow-100 flex items-center gap-1.5 cursor-pointer font-medium border-yellow-300"
            >
              <RefreshCw size={13} className={syncing ? 'animate-spin' : ''} />
              <span>{syncing ? 'Comprobando…' : 'Sincronizar ahora'}</span>
            </button>
          </div>
          <p className="text-[11px] text-yellow-800">
            Están seguras y listas para trabajar, consultar y vincular con sus partes sanitarios sin perder ningún dato.
          </p>
        </div>
      )}

      {/* Lista de Incidencias con Filtro por Servicio */}
      <div className="card p-4 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-gray-100 pb-3">
          <div>
            <h2 className="text-sm font-semibold text-gray-900">Incidencias recientes</h2>
            <p className="text-xs text-gray-400">
              {filteredIncidents.length} incidencia{filteredIncidents.length === 1 ? '' : 's'}{' '}
              {filterServiceId !== 'all' ? `en ${selectedServiceObj?.titulo || 'servicio'}` : ''}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportFiltered}
              disabled={filteredIncidents.length === 0}
              className="btn-outline text-xs py-1 px-2.5 flex items-center gap-1.5 text-primary-700 hover:bg-primary-50 cursor-pointer disabled:opacity-50"
              title="Descargar listado de incidencias en CSV"
            >
              <Download size={13} />
              <span>Exportar (CSV)</span>
            </button>
            <button
              onClick={fetchIncidents}
              className="p-1.5 rounded-lg text-primary-600 hover:bg-primary-50 cursor-pointer"
              aria-label="Actualizar incidencias"
            >
              <RefreshCw size={15} />
            </button>
          </div>
        </div>

        {/* Selector de filtro por Servicio */}
        <div className="flex items-center gap-2 bg-gray-50 p-2 rounded-xl border border-gray-200 text-xs">
          <Filter size={14} className="text-gray-500 shrink-0" />
          <span className="font-semibold text-gray-700 shrink-0">Filtrar por Servicio:</span>
          <select
            className="bg-white border border-gray-200 rounded-lg px-2 py-1 text-xs text-gray-800 flex-1 outline-none"
            value={filterServiceId}
            onChange={(e) => setFilterServiceId(e.target.value)}
          >
            <option value="all">Todos los servicios ({incidents.length})</option>
            {services.map((s) => {
              const count = incidents.filter((i) => i.servicio_id === s.id).length;
              return (
                <option key={s.id} value={s.id}>
                  {s.titulo} ({count})
                </option>
              );
            })}
          </select>
        </div>

        {loadingList ? (
          <div className="flex justify-center py-6">
            <Spinner size={24} />
          </div>
        ) : filteredIncidents.length === 0 ? (
          <p className="text-sm text-gray-400 py-4 text-center">
            {filterServiceId === 'all'
              ? 'Todavía no hay incidencias registradas.'
              : 'No hay incidencias asociadas a este servicio.'}
          </p>
        ) : (
          <div className="space-y-2">
            {filteredIncidents.map((incident) => {
              const config = categoryConfig[incident.categoria];
              return (
                <div key={incident.id} className="rounded-xl border border-gray-100 p-3 bg-white hover:border-gray-200 transition-colors">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2">
                      <span className={`w-2.5 h-2.5 rounded-full ${config.dot}`} />
                      <span className="text-xs font-semibold text-gray-700">{config.shortLabel}</span>
                      {incident.servicio_titulo && (
                        <span className="text-[10px] bg-blue-50 text-blue-700 font-medium px-2 py-0.5 rounded-md border border-blue-100">
                          {incident.servicio_titulo}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-gray-400">
                      {new Date(incident.created_at).toLocaleString('es-ES', {
                        day: '2-digit',
                        month: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <p className="text-sm text-gray-800 mt-1">{incident.descripcion}</p>
                  <div className="flex items-center gap-3 text-[11px] text-gray-400 mt-2 flex-wrap">
                    {incident.latitud !== null && incident.longitud !== null && (
                      <span className="flex items-center gap-1">
                        <MapPin size={12} /> GPS
                      </span>
                    )}
                    {incident.foto_path && (
                      <span className="flex items-center gap-1">
                        <Camera size={12} /> Foto
                      </span>
                    )}
                    <Badge variant={incident.estado === 'resuelta' ? 'success' : 'warning'}>
                      {incident.estado === 'resuelta' ? 'Resuelta' : 'Abierta'}
                    </Badge>
                    {incident.categoria === 'sanitaria' && (incident.report_count ?? 0) > 0 && (
                      <Badge variant="primary">
                        <FileText size={11} /> {incident.report_count} parte
                        {(incident.report_count ?? 0) > 1 ? 's' : ''}
                      </Badge>
                    )}
                    {incident.categoria === 'sanitaria' && (
                      <button
                        onClick={() => setSavedIncidentId(incident.id)}
                        className="text-primary-600 font-medium flex items-center gap-1 hover:underline cursor-pointer ml-auto"
                      >
                        <Stethoscope size={13} />{' '}
                        <span>{(incident.report_count ?? 0) > 0 ? 'Ver / Editar parte' : 'Completar parte'}</span>
                      </button>
                    )}
                    {canDelete && (
                      <button
                        type="button"
                        onClick={() => setIncidentToDelete(incident)}
                        className={`p-1.5 text-gray-400 hover:text-error-600 hover:bg-error-50 rounded-lg transition-colors cursor-pointer ${
                          incident.categoria !== 'sanitaria' ? 'ml-auto' : ''
                        }`}
                        title="Eliminar incidencia (Administrador / Coordinador)"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {savedIncidentId && (() => {
        const incident =
          incidents.find((i) => i.id === savedIncidentId) ||
          pending.find((p) => p.id === savedIncidentId);
        return (
          <ParteSanitarioModal
            incidentId={savedIncidentId}
            incidentDescription={incident?.descripcion ?? 'Asistencia sanitaria activa'}
            onClose={() => setSavedIncidentId(null)}
            onSaved={() => {
              setSavedIncidentId(null);
              fetchIncidents();
            }}
          />
        );
      })()}

      <ConfirmDialog
        open={Boolean(incidentToDelete)}
        onClose={() => setIncidentToDelete(null)}
        onConfirm={() => {
          if (incidentToDelete) {
            handleDeleteIncident(incidentToDelete);
          }
        }}
        title="Eliminar incidencia"
        message={`¿Estás seguro de que deseas eliminar permanentemente esta incidencia (${categoryConfig[incidentToDelete?.categoria ?? 'aviso_general']?.shortLabel || 'Incidencia'}): "${incidentToDelete?.descripcion.slice(0, 80) ?? ''}..."? Esta acción no se puede deshacer.`}
        confirmText="Eliminar incidencia"
        danger
      />
    </div>
  );
}
