import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Crosshair,
  Droplets,
  MapPinned,
  MapPin,
  Plus,
  RefreshCw,
  Route,
  Shield,
  Trash2,
  Truck,
  X,
  Flag,
  Navigation,
  Eye,
  EyeOff,
  AlertTriangle,
} from 'lucide-react';
import L from 'leaflet';
import { MapContainer, Marker, Polyline, Popup, TileLayer, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useAuth } from '@/context/AuthContext';
import {
  supabase,
  isSupabaseConfigured,
  type OperationalPoi,
  type OperationalVehicle,
  type PoiCategory,
  type RouteType,
  type RouteWaypoint,
  type SpecialRoute,
  type VehicleStatus,
  type VehicleType,
  type WaypointType,
} from '@/lib/supabase';
import { demoPois, demoRoutes, demoWaypoints } from '@/lib/demoData';
import {
  getFleetVehicles,
  updateFleetVehicle,
  deleteFleetVehicle,
  subscribeToFleetUpdates,
} from '@/lib/fleetStorage';
import { Badge } from '@/components/ui/Badge';
import { Modal } from '@/components/ui/Modal';
import { Spinner } from '@/components/ui/Spinner';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';

const huelvaCenter: [number, number] = [37.2614, -6.9447];

const poiConfig: Record<PoiCategory, { label: string; shortLabel: string; color: string; icon: typeof Shield }> = {
  socorro_encuentro: { label: 'Puestos de socorro / Encuentro', shortLabel: 'Socorro', color: '#dc2626', icon: Shield },
  hidrante: { label: 'Bocas de riego / Hidrantes', shortLabel: 'Hidrantes', color: '#2563eb', icon: Droplets },
  riesgo_evacuacion: { label: 'Zonas de riesgo / Evacuación', shortLabel: 'Riesgo', color: '#d97706', icon: Route },
};

const vehicleTypeConfig: Record<VehicleType, { label: string; color: string }> = {
  vir: { label: 'VIR', color: '#16a34a' },
  coordinacion: { label: 'Coordinación', color: '#9333ea' },
  ambulancia: { label: 'Ambulancia', color: '#dc2626' },
  logistica: { label: 'Logística', color: '#0891b2' },
  otro: { label: 'Otro', color: '#475569' },
};

const vehicleStatusConfig: Record<VehicleStatus, { label: string; color: 'gray' | 'primary' | 'error' | 'success' }> = {
  en_base: { label: 'En base', color: 'gray' },
  en_ruta: { label: 'En ruta', color: 'primary' },
  en_incidencia: { label: 'En incidencia', color: 'error' },
};

const routeTypeConfig: Record<RouteType, { label: string }> = {
  procesion: { label: 'Procesión' },
  carrera_popular: { label: 'Carrera popular' },
  manifestacion: { label: 'Manifestación' },
  otro: { label: 'Otro evento' },
};

const waypointTypeConfig: Record<WaypointType, { label: string; color: string }> = {
  recorrido: { label: 'Recorrido', color: '#334155' },
  pk_critico: { label: 'PK crítico', color: '#d97706' },
  corte_trafico: { label: 'Corte de tráfico', color: '#dc2626' },
  retene: { label: 'Retén estático', color: '#16a34a' },
};

function createPoiIcon(category: PoiCategory) {
  const { color } = poiConfig[category];
  return L.divIcon({
    className: 'poi-marker',
    html: `<div style="background:${color};width:34px;height:34px;border:3px solid white;border-radius:50% 50% 50% 0;transform:rotate(-45deg);box-shadow:0 2px 7px rgba(15,23,42,.35);display:flex;align-items:center;justify-content:center"><span style="width:9px;height:9px;border-radius:50%;background:white"></span></div>`,
    iconSize: [34, 34],
    iconAnchor: [17, 34],
    popupAnchor: [0, -34],
  });
}

function createVehicleIcon(type: VehicleType, status: VehicleStatus) {
  const { color } = vehicleTypeConfig[type];
  const pulse = status === 'en_incidencia' ? 'animation:vehiclePulse 1.5s infinite;' : '';
  return L.divIcon({
    className: 'vehicle-marker',
    html: `<div style="${pulse}background:${color};width:36px;height:36px;border:3px solid white;border-radius:50%;box-shadow:0 2px 8px rgba(15,23,42,.4);display:flex;align-items:center;justify-content:center"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 17h-2v-5l2-5h11l4 4v6h-2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/></svg></div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -18],
  });
}

function createWaypointIcon(type: WaypointType) {
  const { color } = waypointTypeConfig[type];
  if (type === 'retene' || type === 'corte_trafico') {
    return L.divIcon({
      className: 'waypoint-marker',
      html: `<div style="background:${color};width:28px;height:28px;border:2.5px solid white;border-radius:4px;box-shadow:0 2px 5px rgba(15,23,42,.3);display:flex;align-items:center;justify-content:center"><span style="width:10px;height:10px;border-radius:50%;background:white"></span></div>`,
      iconSize: [28, 28],
      iconAnchor: [14, 14],
      popupAnchor: [0, -14],
    });
  }
  return L.divIcon({
    className: 'waypoint-marker',
    html: `<div style="background:${color};width:22px;height:22px;border:2px solid white;border-radius:50%;box-shadow:0 2px 5px rgba(15,23,42,.3)"></div>`,
    iconSize: [22, 22],
    iconAnchor: [11, 11],
    popupAnchor: [0, -11],
  });
}

const selectedIcon = L.divIcon({
  className: 'selected-marker',
  html: '<div style="width:24px;height:24px;border:3px solid white;border-radius:50%;background:#0f766e;box-shadow:0 0 0 3px rgba(15,118,110,.3)"></div>',
  iconSize: [24, 24],
  iconAnchor: [12, 12],
});

type AddMode = 'poi' | 'vehicle' | 'waypoint' | null;

function MapClickHandler({ mode, onSelect }: { mode: AddMode; onSelect: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(event) {
      if (mode) onSelect(Number(event.latlng.lat.toFixed(6)), Number(event.latlng.lng.toFixed(6)));
    },
  });
  return null;
}

type TabView = 'general' | 'vehiculos' | 'rutas';

interface DeleteTarget {
  type: 'poi' | 'route' | 'vehicle_fleet' | 'vehicle_map';
  id: string;
  name: string;
}

export function MapaOperativoPage() {
  const { profile } = useAuth();
  const canManage = profile?.role === 'admin_tecnico' || profile?.role === 'coordinador';

  const [tab, setTab] = useState<TabView>('general');
  const [pois, setPois] = useState<OperationalPoi[]>([]);
  const [vehicles, setVehicles] = useState<OperationalVehicle[]>([]);
  const [routes, setRoutes] = useState<SpecialRoute[]>([]);
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>(null);
  const [waypoints, setWaypoints] = useState<RouteWaypoint[]>([]);
  const [activeLayers, setActiveLayers] = useState<Record<PoiCategory, boolean>>({
    socorro_encuentro: true,
    hidrante: true,
    riesgo_evacuacion: true,
  });
  const [showVehicles, setShowVehicles] = useState(true);
  const [showRoute, setShowRoute] = useState(true);
  const [loading, setLoading] = useState(true);
  const [addMode, setAddMode] = useState<AddMode>(null);
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Form states POI
  const [poiName, setPoiName] = useState('');
  const [poiDescription, setPoiDescription] = useState('');
  const [poiCategory, setPoiCategory] = useState<PoiCategory>('socorro_encuentro');

  // Form states Vehículo (SELECCIÓN EXCLUSIVA DE LA FLOTA DE PARQUE MÓVIL)
  const [selectedFleetVehicleId, setSelectedFleetVehicleId] = useState<string>('');
  const [vehicleStatus, setVehicleStatus] = useState<VehicleStatus>('en_ruta');

  // Form states Ruta
  const [showRouteModal, setShowRouteModal] = useState(false);
  const [routeName, setRouteName] = useState('');
  const [routeType, setRouteType] = useState<RouteType>('procesion');
  const [routeDate, setRouteDate] = useState('');
  const [routeDescription, setRouteDescription] = useState('');
  const [waypointType, setWaypointType] = useState<WaypointType>('recorrido');
  const [waypointLabel, setWaypointLabel] = useState('');
  const [saving, setSaving] = useState(false);

  // Dialogo de confirmación para borrados
  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget | null>(null);

  const showNotification = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3500);
  };

  const fetchAll = useCallback(async () => {
    setLoading(true);

    // Leer IDs eliminados
    let deletedPoiIds = new Set<string>();
    let deletedRouteIds = new Set<string>();
    try {
      deletedPoiIds = new Set(JSON.parse(localStorage.getItem('pc-huelva-deleted-pois') || '[]'));
      deletedRouteIds = new Set(JSON.parse(localStorage.getItem('pc-huelva-deleted-routes') || '[]'));
    } catch { /* noop */ }

    // Los vehículos siempre provienen del Parque Móvil oficial
    const fleet = await getFleetVehicles();
    setVehicles(fleet);

    // Cargar POIs locales o por defecto
    let storedPois: OperationalPoi[] = [];
    try {
      const rawPois = localStorage.getItem('pc-huelva-local-pois');
      storedPois = rawPois ? JSON.parse(rawPois) : [...demoPois];
    } catch {
      storedPois = [...demoPois];
    }

    // Cargar Rutas locales o por defecto
    let storedRoutes: SpecialRoute[] = [];
    try {
      const rawRoutes = localStorage.getItem('pc-huelva-local-routes');
      storedRoutes = rawRoutes ? JSON.parse(rawRoutes) : [...demoRoutes];
    } catch {
      storedRoutes = [...demoRoutes];
    }

    if (!isSupabaseConfigured) {
      const activePois = storedPois.filter((p) => !deletedPoiIds.has(p.id) && p.is_active !== false);
      const activeRoutes = storedRoutes.filter((r) => !deletedRouteIds.has(r.id) && r.is_active !== false);
      setPois(activePois);
      setRoutes(activeRoutes);
      if (activeRoutes.length > 0 && !selectedRouteId) {
        setSelectedRouteId(activeRoutes[0].id);
      }
      setLoading(false);
      return;
    }

    try {
      const [poiRes, routeRes] = await Promise.all([
        supabase.from('puntos_interes').select('*').eq('is_active', true).order('created_at', { ascending: false }),
        supabase.from('rutas_especiales').select('*').eq('is_active', true).order('fecha', { ascending: true }),
      ]);
      const dbPois = (poiRes.data ?? []) as OperationalPoi[];
      const dbRoutes = (routeRes.data ?? []) as SpecialRoute[];

      const mergedPois = [...dbPois, ...storedPois.filter((p) => !dbPois.some((dp) => dp.id === p.id))]
        .filter((p) => !deletedPoiIds.has(p.id));
      const mergedRoutes = [...dbRoutes, ...storedRoutes.filter((r) => !dbRoutes.some((dr) => dr.id === r.id))]
        .filter((r) => !deletedRouteIds.has(r.id));

      setPois(mergedPois);
      setRoutes(mergedRoutes);
      if (mergedRoutes.length > 0 && !selectedRouteId) {
        setSelectedRouteId(mergedRoutes[0].id);
      }
    } catch (err) {
      console.warn('Error al cargar datos del mapa de Supabase, usando respaldo local:', err);
      setPois(storedPois.filter((p) => !deletedPoiIds.has(p.id)));
      setRoutes(storedRoutes.filter((r) => !deletedRouteIds.has(r.id)));
    } finally {
      setLoading(false);
    }
  }, [selectedRouteId]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  // Suscribirse en tiempo real a cambios en la flota de Parque Móvil
  useEffect(() => {
    const unsub = subscribeToFleetUpdates(async () => {
      const fleet = await getFleetVehicles();
      setVehicles(fleet);
    });
    return unsub;
  }, []);

  const fetchWaypoints = useCallback(async (routeId: string) => {
    if (!isSupabaseConfigured) {
      let storedWaypoints: RouteWaypoint[] = [];
      try {
        const rawWps = localStorage.getItem('pc-huelva-local-waypoints');
        storedWaypoints = rawWps ? JSON.parse(rawWps) : [...demoWaypoints];
      } catch {
        storedWaypoints = [...demoWaypoints];
      }
      setWaypoints(storedWaypoints.filter((w) => w.ruta_id === routeId || routeId === 'demo-route-1'));
      return;
    }
    try {
      const { data } = await supabase.from('ruta_waypoints').select('*').eq('ruta_id', routeId).order('orden', { ascending: true });
      setWaypoints((data ?? []) as RouteWaypoint[]);
    } catch (err) {
      console.warn('Error fetching waypoints:', err);
      setWaypoints(demoWaypoints);
    }
  }, []);

  useEffect(() => {
    if (selectedRouteId) {
      fetchWaypoints(selectedRouteId);
    } else {
      setWaypoints([]);
    }
  }, [selectedRouteId, fetchWaypoints]);

  const visiblePois = useMemo(() => pois.filter((p) => activeLayers[p.categoria]), [activeLayers, pois]);
  const placedVehicles = useMemo(() => vehicles.filter((v) => v.latitud !== null && v.longitud !== null), [vehicles]);
  const routeLinePoints = useMemo(
    () => waypoints.filter((w) => w.tipo === 'recorrido' || w.tipo === 'pk_critico').map((w) => [w.latitud, w.longitud] as [number, number]),
    [waypoints]
  );

  const toggleLayer = (layer: PoiCategory) => setActiveLayers((c) => ({ ...c, [layer]: !c[layer] }));

  const handleMapClick = (lat: number, lng: number) => {
    setSelectedLocation({ lat, lng });
    setError(null);
  };

  const startAdd = (mode: AddMode) => {
    setAddMode(mode);
    setSelectedLocation(null);
    setError(null);
    if (mode === 'vehicle' && vehicles.length > 0 && !selectedFleetVehicleId) {
      setSelectedFleetVehicleId(vehicles[0].id);
    }
  };

  const cancelAdd = () => {
    setAddMode(null);
    setSelectedLocation(null);
    setPoiName('');
    setPoiDescription('');
    setWaypointLabel('');
  };

  // Guardar nuevo Punto de Interés (POI)
  const savePoi = async () => {
    if (!selectedLocation || poiName.trim().length < 2) {
      setError('Selecciona una ubicación en el mapa e introduce un nombre descriptivo.');
      return;
    }
    setSaving(true);
    setError(null);

    const newPoi: OperationalPoi = {
      id: `poi-${Date.now()}`,
      nombre: poiName.trim(),
      descripcion: poiDescription.trim() || null,
      categoria: poiCategory,
      latitud: selectedLocation.lat,
      longitud: selectedLocation.lng,
      created_by: profile?.id || 'admin',
      is_active: true,
      created_at: new Date().toISOString(),
    };

    // Guardar en almacenamiento local
    try {
      const cur = JSON.parse(localStorage.getItem('pc-huelva-local-pois') || '[]');
      localStorage.setItem('pc-huelva-local-pois', JSON.stringify([newPoi, ...cur]));
    } catch { /* noop */ }

    setPois((prev) => [newPoi, ...prev]);

    if (isSupabaseConfigured) {
      try {
        await supabase.from('puntos_interes').insert({
          nombre: newPoi.nombre,
          descripcion: newPoi.descripcion,
          categoria: newPoi.categoria,
          latitud: newPoi.latitud,
          longitud: newPoi.longitud,
        });
      } catch (err) {
        console.warn('Error al guardar POI en Supabase:', err);
      }
    }

    cancelAdd();
    setSaving(false);
    showNotification(`Punto de interés "${newPoi.nombre}" añadido al mapa.`);
  };

  // Desplegar o posicionar vehículo del Parque Móvil en el mapa
  const placeVehicleOnMap = async () => {
    if (!selectedLocation) {
      setError('Toca en el mapa para situar las coordenadas del vehículo.');
      return;
    }
    if (!selectedFleetVehicleId) {
      setError('Selecciona un vehículo de la flota del Parque Móvil.');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const updated = await updateFleetVehicle(selectedFleetVehicleId, {
        latitud: selectedLocation.lat,
        longitud: selectedLocation.lng,
        estado: vehicleStatus,
      });

      if (updated) {
        setVehicles((prev) => prev.map((v) => (v.id === updated.id ? updated : v)));
        showNotification(`Vehículo "${updated.nombre}" posicionado en el mapa operativo.`);
      }
      cancelAdd();
    } catch {
      setError('Ocurrió un error al posicionar el vehículo.');
    } finally {
      setSaving(false);
    }
  };

  const updateVehicleQuickStatus = async (id: string, status: VehicleStatus) => {
    await updateFleetVehicle(id, { estado: status });
    setVehicles((c) => c.map((v) => (v.id === id ? { ...v, estado: status } : v)));
    showNotification(`Estado del vehículo actualizado a: ${vehicleStatusConfig[status].label}`);
  };

  // Retirar vehículo del mapa (desubicar sin borrar de la flota)
  const handleRetireVehicleFromMap = async (id: string) => {
    await updateFleetVehicle(id, { latitud: null, longitud: null, estado: 'en_base' });
    setVehicles((c) => c.map((v) => (v.id === id ? { ...v, latitud: null, longitud: null, estado: 'en_base' } : v)));
    showNotification('Vehículo retirado del mapa táctico (sigue disponible en Parque Móvil).');
  };

  // Ejecutar eliminación confirmada (POI, Ruta, Vehículo del mapa o de la flota)
  const handleExecuteDelete = async () => {
    if (!deleteTarget) return;

    if (deleteTarget.type === 'poi') {
      const id = deleteTarget.id;
      setPois((c) => c.filter((p) => p.id !== id));

      // Guardar en lista de eliminados
      try {
        const deleted = JSON.parse(localStorage.getItem('pc-huelva-deleted-pois') || '[]');
        if (!deleted.includes(id)) {
          deleted.push(id);
          localStorage.setItem('pc-huelva-deleted-pois', JSON.stringify(deleted));
        }
        const curLocal = JSON.parse(localStorage.getItem('pc-huelva-local-pois') || '[]').filter((p: any) => p.id !== id);
        localStorage.setItem('pc-huelva-local-pois', JSON.stringify(curLocal));
      } catch { /* noop */ }

      if (isSupabaseConfigured) {
        try {
          await supabase.from('puntos_interes').delete().eq('id', id);
        } catch {
          try {
            await supabase.from('puntos_interes').update({ is_active: false }).eq('id', id);
          } catch { /* noop */ }
        }
      }
      showNotification(`Punto de interés "${deleteTarget.name}" eliminado del mapa.`);
    } else if (deleteTarget.type === 'route') {
      const id = deleteTarget.id;
      setRoutes((c) => c.filter((r) => r.id !== id));
      if (selectedRouteId === id) {
        setSelectedRouteId(null);
        setWaypoints([]);
      }

      try {
        const deleted = JSON.parse(localStorage.getItem('pc-huelva-deleted-routes') || '[]');
        if (!deleted.includes(id)) {
          deleted.push(id);
          localStorage.setItem('pc-huelva-deleted-routes', JSON.stringify(deleted));
        }
        const curLocal = JSON.parse(localStorage.getItem('pc-huelva-local-routes') || '[]').filter((r: any) => r.id !== id);
        localStorage.setItem('pc-huelva-local-routes', JSON.stringify(curLocal));
      } catch { /* noop */ }

      if (isSupabaseConfigured) {
        try {
          await supabase.from('rutas_especiales').delete().eq('id', id);
        } catch {
          try {
            await supabase.from('rutas_especiales').update({ is_active: false }).eq('id', id);
          } catch { /* noop */ }
        }
      }
      showNotification(`Ruta especial "${deleteTarget.name}" eliminada.`);
    } else if (deleteTarget.type === 'vehicle_map') {
      await handleRetireVehicleFromMap(deleteTarget.id);
    } else if (deleteTarget.type === 'vehicle_fleet') {
      await deleteFleetVehicle(deleteTarget.id);
      setVehicles((c) => c.filter((v) => v.id !== deleteTarget.id));
      showNotification(`Vehículo "${deleteTarget.name}" eliminado permanentemente de la flota.`);
    }

    setDeleteTarget(null);
  };

  // Crear ruta
  const createRoute = async () => {
    if (routeName.trim().length < 3 || !routeDate) {
      setError('Escribe un nombre y fecha/hora para la ruta especial.');
      return;
    }
    setSaving(true);
    setError(null);

    const newRoute: SpecialRoute = {
      id: `route-${Date.now()}`,
      nombre: routeName.trim(),
      tipo: routeType,
      fecha: new Date(routeDate).toISOString(),
      descripcion: routeDescription.trim() || null,
      created_by: profile?.id || 'admin',
      is_active: true,
      created_at: new Date().toISOString(),
    };

    try {
      const cur = JSON.parse(localStorage.getItem('pc-huelva-local-routes') || '[]');
      localStorage.setItem('pc-huelva-local-routes', JSON.stringify([newRoute, ...cur]));
    } catch { /* noop */ }

    setRoutes((prev) => [newRoute, ...prev]);
    setSelectedRouteId(newRoute.id);
    setWaypoints([]);

    if (isSupabaseConfigured) {
      try {
        const { data } = await supabase
          .from('rutas_especiales')
          .insert({
            nombre: newRoute.nombre,
            tipo: newRoute.tipo,
            fecha: newRoute.fecha,
            descripcion: newRoute.descripcion,
          })
          .select()
          .single();
        if (data?.id) {
          setSelectedRouteId(data.id);
        }
      } catch (err) {
        console.warn('Error al guardar ruta en Supabase:', err);
      }
    }

    setShowRouteModal(false);
    setRouteName('');
    setRouteDate('');
    setRouteDescription('');
    setAddMode('waypoint');
    setSaving(false);
    showNotification(`Ruta "${newRoute.nombre}" creada. Ahora pulsa en el mapa para trazar los puntos.`);
  };

  // Añadir punto a la ruta
  const addWaypoint = async () => {
    if (!selectedRouteId || !selectedLocation) {
      setError('Selecciona una ubicación en el mapa para situar este punto.');
      return;
    }
    setSaving(true);
    setError(null);

    const nextOrden = waypoints.length > 0 ? Math.max(...waypoints.map((w) => w.orden)) + 1 : 0;
    const newWp: RouteWaypoint = {
      id: `wp-${Date.now()}`,
      ruta_id: selectedRouteId,
      orden: nextOrden,
      tipo: waypointType,
      latitud: selectedLocation.lat,
      longitud: selectedLocation.lng,
      etiqueta: waypointLabel.trim() || null,
      created_at: new Date().toISOString(),
    };

    setWaypoints((prev) => [...prev, newWp]);

    try {
      const cur = JSON.parse(localStorage.getItem('pc-huelva-local-waypoints') || '[]');
      localStorage.setItem('pc-huelva-local-waypoints', JSON.stringify([...cur, newWp]));
    } catch { /* noop */ }

    if (isSupabaseConfigured) {
      try {
        await supabase.from('ruta_waypoints').insert({
          ruta_id: selectedRouteId,
          orden: nextOrden,
          tipo: waypointType,
          latitud: selectedLocation.lat,
          longitud: selectedLocation.lng,
          etiqueta: newWp.etiqueta,
        });
      } catch (err) {
        console.warn('Error al guardar waypoint en Supabase:', err);
      }
    }

    setSelectedLocation(null);
    setWaypointLabel('');
    setSaving(false);
    showNotification(`Punto ${nextOrden + 1} añadido a la ruta.`);
  };

  const handleRemoveWaypoint = async (wpId: string) => {
    setWaypoints((c) => c.filter((w) => w.id !== wpId));
    try {
      const cur = JSON.parse(localStorage.getItem('pc-huelva-local-waypoints') || '[]').filter((w: any) => w.id !== wpId);
      localStorage.setItem('pc-huelva-local-waypoints', JSON.stringify(cur));
    } catch { /* noop */ }

    if (isSupabaseConfigured) {
      try {
        await supabase.from('ruta_waypoints').delete().eq('id', wpId);
      } catch { /* noop */ }
    }
    showNotification('Punto de la ruta eliminado.');
  };

  const modeLabel =
    addMode === 'poi'
      ? 'Toca el mapa para situar las coordenadas del nuevo punto de interés.'
      : addMode === 'vehicle'
      ? 'Toca el mapa para situar o reubicar el vehículo seleccionado de la flota.'
      : addMode === 'waypoint'
      ? 'Toca el mapa para añadir el siguiente punto o PK al trazado de la ruta.'
      : '';

  return (
    <div className="px-4 py-4 max-w-5xl mx-auto space-y-4">
      <style>{'@keyframes vehiclePulse{0%,100%{opacity:1}50%{opacity:.55}}'}</style>

      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary-600">Cartografía y Operativa</p>
          <h1 className="text-xl font-bold text-gray-900">Mapa Táctico</h1>
          <p className="text-sm text-gray-500 mt-1">
            Puntos de interés, rutas preventivas y flota operativa de Huelva.
          </p>
        </div>
        <div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-700 flex items-center justify-center">
          <MapPinned size={22} />
        </div>
      </div>

      {feedback && (
        <div className="rounded-xl bg-success-50 border border-success-200 px-3 py-2 text-xs text-success-800 font-medium">
          {feedback}
        </div>
      )}

      {/* Selector de pestañas */}
      <div className="flex gap-2">
        {(
          [
            ['general', 'Puntos de interés'],
            ['vehiculos', 'Vehículos operativos'],
            ['rutas', 'Rutas especiales'],
          ] as [TabView, string][]
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => {
              setTab(id);
              cancelAdd();
            }}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              tab === id ? 'bg-primary-600 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Capas visibles en Puntos de interés */}
      {tab === 'general' && (
        <div className="card p-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-semibold text-gray-700">Capas de Puntos de Interés ({visiblePois.length} visibles)</p>
            <button onClick={fetchAll} className="p-2 rounded-lg text-primary-600 hover:bg-primary-50" aria-label="Actualizar">
              <RefreshCw size={16} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {(Object.keys(poiConfig) as PoiCategory[]).map((layer) => {
              const config = poiConfig[layer];
              const Icon = config.icon;
              return (
                <button
                  key={layer}
                  onClick={() => toggleLayer(layer)}
                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-left transition-colors ${
                    activeLayers[layer] ? 'border-gray-200 bg-gray-50 text-gray-800' : 'border-gray-100 bg-white text-gray-400 opacity-60'
                  }`}
                >
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: config.color }} />
                  <Icon size={16} style={{ color: config.color }} />
                  <span className="text-xs font-medium leading-tight">{config.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Pestaña Vehículos */}
      {tab === 'vehiculos' && (
        <div className="card p-3 space-y-2">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div>
              <p className="text-xs font-semibold text-gray-700">
                Flota de Parque Móvil ({vehicles.length} vehículos registrados · {placedVehicles.length} situados en mapa)
              </p>
              <p className="text-[11px] text-gray-400">
                Solo se pueden situar vehículos oficiales gestionados en el Parque Móvil.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowVehicles((v) => !v)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium border flex items-center gap-1 ${
                  showVehicles ? 'border-primary-200 bg-primary-50 text-primary-700' : 'border-gray-200 text-gray-400'
                }`}
              >
                {showVehicles ? <Eye size={13} /> : <EyeOff size={13} />}
                {showVehicles ? 'Visibles' : 'Ocultos'}
              </button>
              <button onClick={fetchAll} className="p-2 rounded-lg text-primary-600 hover:bg-primary-50" aria-label="Actualizar">
                <RefreshCw size={16} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pestaña Rutas */}
      {tab === 'rutas' && (
        <div className="card p-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-semibold text-gray-700">Rutas y eventos especiales ({routes.length})</p>
            {canManage && !showRouteModal && (
              <button onClick={() => setShowRouteModal(true)} className="btn-primary text-xs px-3 py-1.5 flex items-center gap-1">
                <Plus size={14} /> Nueva ruta
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {routes.map((r) => (
              <button
                key={r.id}
                onClick={() => {
                  setSelectedRouteId(r.id);
                  setAddMode(null);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors flex items-center gap-1.5 ${
                  selectedRouteId === r.id
                    ? 'border-primary-500 bg-primary-50 text-primary-800 font-semibold'
                    : 'border-gray-200 bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Flag size={12} />
                <span>{r.nombre}</span>
                <span className="text-gray-400 text-[10px]">({routeTypeConfig[r.tipo].label})</span>
              </button>
            ))}
          </div>

          {selectedRouteId && (() => {
            const route = routes.find((r) => r.id === selectedRouteId);
            if (!route) return null;
            return (
              <div className="rounded-xl bg-primary-50 border border-primary-100 px-3.5 py-3 flex items-center justify-between gap-2 flex-wrap">
                <div>
                  <p className="text-sm font-semibold text-primary-900">{route.nombre}</p>
                  <p className="text-[11px] text-primary-700">
                    {new Date(route.fecha).toLocaleString('es-ES', {
                      day: '2-digit',
                      month: 'long',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}{' '}
                    · {waypoints.length} puntos trazados
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  {canManage && (
                    <button onClick={() => setAddMode('waypoint')} className="btn-primary text-xs px-2.5 py-1">
                      <Plus size={13} /> Añadir punto
                    </button>
                  )}
                  <button
                    onClick={() => setShowRoute((v) => !v)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border ${
                      showRoute ? 'border-primary-200 bg-white text-primary-700' : 'border-gray-200 text-gray-400'
                    }`}
                  >
                    {showRoute ? 'Trazado visible' : 'Trazado oculto'}
                  </button>
                  {canManage && (
                    <button
                      onClick={() =>
                        setDeleteTarget({
                          type: 'route',
                          id: route.id,
                          name: route.nombre,
                        })
                      }
                      className="p-1.5 rounded-lg text-error-600 hover:bg-error-50 cursor-pointer"
                      title="Eliminar ruta especial"
                    >
                      <Trash2 size={15} />
                    </button>
                  )}
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Contenedor del Mapa Leaflet */}
      <div className="relative rounded-2xl overflow-hidden border border-gray-200 shadow-sm bg-slate-100">
        <MapContainer center={huelvaCenter} zoom={13} scrollWheelZoom className="h-[min(68vh,560px)] min-h-[390px] w-full">
          <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <MapClickHandler mode={addMode} onSelect={handleMapClick} />

          {/* Marcadores POI */}
          {tab === 'general' &&
            visiblePois.map((poi) => (
              <Marker key={poi.id} position={[poi.latitud, poi.longitud]} icon={createPoiIcon(poi.categoria)}>
                <Popup>
                  <div className="min-w-[190px]">
                    <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: poiConfig[poi.categoria].color }}>
                      {poiConfig[poi.categoria].label}
                    </p>
                    <p className="font-bold text-gray-900 mt-1">{poi.nombre}</p>
                    {poi.descripcion && <p className="text-sm text-gray-600 mt-1">{poi.descripcion}</p>}
                    <p className="text-[11px] text-gray-400 mt-2">
                      {poi.latitud.toFixed(5)}, {poi.longitud.toFixed(5)}
                    </p>
                    {canManage && (
                      <button
                        onClick={() =>
                          setDeleteTarget({
                            type: 'poi',
                            id: poi.id,
                            name: poi.nombre,
                          })
                        }
                        className="text-xs text-red-600 font-medium mt-2 flex items-center gap-1 hover:underline cursor-pointer"
                      >
                        <Trash2 size={13} /> Eliminar punto
                      </button>
                    )}
                  </div>
                </Popup>
              </Marker>
            ))}

          {/* Marcadores de Vehículos de la Flota */}
          {tab === 'vehiculos' &&
            showVehicles &&
            vehicles.map(
              (v) =>
                v.latitud !== null &&
                v.longitud !== null && (
                  <Marker key={v.id} position={[v.latitud, v.longitud]} icon={createVehicleIcon(v.tipo, v.estado)}>
                    <Popup>
                      <div className="min-w-[210px]">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded-full" style={{ backgroundColor: vehicleTypeConfig[v.tipo].color }} />
                          <p className="font-bold text-gray-900">{v.nombre}</p>
                        </div>
                        <p className="text-xs text-gray-500 mt-0.5">
                          {vehicleTypeConfig[v.tipo].label}
                          {v.matricula ? ` · ${v.matricula}` : ''}
                          {v.indicativo ? ` (${v.indicativo})` : ''}
                        </p>
                        <div className="mt-2 flex items-center gap-2">
                          <Badge variant={vehicleStatusConfig[v.estado].color}>{vehicleStatusConfig[v.estado].label}</Badge>
                          <span className="text-[10px] text-gray-400">
                            {new Date(v.updated_at).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        {canManage && (
                          <div className="mt-2.5 space-y-1.5 border-t border-gray-100 pt-2">
                            <p className="text-[10px] font-semibold text-gray-500 uppercase">Cambiar estado:</p>
                            <div className="flex gap-1 flex-wrap">
                              {(['en_base', 'en_ruta', 'en_incidencia'] as VehicleStatus[]).map((st) => (
                                <button
                                  key={st}
                                  onClick={() => updateVehicleQuickStatus(v.id, st)}
                                  className={`text-[10px] px-2 py-0.5 rounded-md border ${
                                    v.estado === st
                                      ? 'border-primary-400 bg-primary-50 text-primary-700 font-bold'
                                      : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                                  }`}
                                >
                                  {vehicleStatusConfig[st].label}
                                </button>
                              ))}
                            </div>
                            <div className="flex items-center justify-between pt-1">
                              <button
                                onClick={() => handleRetireVehicleFromMap(v.id)}
                                className="text-xs text-amber-700 font-medium hover:underline flex items-center gap-1 cursor-pointer"
                              >
                                <EyeOff size={12} /> Retirar del mapa
                              </button>
                              <button
                                onClick={() =>
                                  setDeleteTarget({
                                    type: 'vehicle_fleet',
                                    id: v.id,
                                    name: v.nombre,
                                  })
                                }
                                className="text-xs text-red-600 font-medium hover:underline flex items-center gap-1 cursor-pointer ml-auto"
                              >
                                <Trash2 size={12} /> Eliminar
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </Popup>
                  </Marker>
                )
            )}

          {/* Marcadores y Trazado de Rutas */}
          {tab === 'rutas' && selectedRouteId && showRoute && (
            <>
              {routeLinePoints.length >= 2 && (
                <Polyline positions={routeLinePoints} pathOptions={{ color: '#1d4ed8', weight: 4, opacity: 0.7, dashArray: '8 8' }} />
              )}
              {waypoints.map((wp) => (
                <Marker key={wp.id} position={[wp.latitud, wp.longitud]} icon={createWaypointIcon(wp.tipo)}>
                  <Popup>
                    <div className="min-w-[170px]">
                      <p className="text-xs font-semibold uppercase" style={{ color: waypointTypeConfig[wp.tipo].color }}>
                        {waypointTypeConfig[wp.tipo].label}
                      </p>
                      {wp.etiqueta && <p className="font-bold text-gray-900 mt-1">{wp.etiqueta}</p>}
                      <p className="text-[11px] text-gray-400 mt-1">Punto {wp.orden + 1}</p>
                      {canManage && (
                        <button
                          onClick={() => handleRemoveWaypoint(wp.id)}
                          className="text-xs text-red-600 font-medium mt-2 flex items-center gap-1 hover:underline cursor-pointer"
                        >
                          <Trash2 size={13} /> Eliminar punto
                        </button>
                      )}
                    </div>
                  </Popup>
                </Marker>
              ))}
            </>
          )}

          {selectedLocation && (
            <Marker position={[selectedLocation.lat, selectedLocation.lng]} icon={selectedIcon}>
              <Popup>Ubicación seleccionada en el mapa</Popup>
            </Marker>
          )}
        </MapContainer>

        {addMode && (
          <div className="absolute top-3 left-3 right-3 z-[1000] rounded-xl bg-white/95 shadow-lg border border-primary-200 px-3.5 py-2 flex items-center gap-2">
            <Crosshair size={16} className="text-primary-600 flex-shrink-0 animate-pulse" />
            <p className="text-xs text-gray-700 flex-1 font-medium">{modeLabel}</p>
            <button onClick={cancelAdd} className="p-1 text-gray-500 hover:text-gray-800">
              <X size={17} />
            </button>
          </div>
        )}
      </div>

      {/* Acciones y formularios de gestión */}
      {tab === 'general' && canManage && (
        addMode === 'poi' ? (
          <div className="card p-4 space-y-3">
            <h2 className="text-sm font-semibold text-gray-900">Nuevo punto de interés</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="label">Categoría</label>
                <select className="input" value={poiCategory} onChange={(e) => setPoiCategory(e.target.value as PoiCategory)}>
                  {(Object.keys(poiConfig) as PoiCategory[]).map((item) => (
                    <option key={item} value={item}>
                      {poiConfig[item].label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Nombre del punto</label>
                <input
                  className="input"
                  value={poiName}
                  onChange={(e) => setPoiName(e.target.value)}
                  placeholder="Ej. Puesto Sanitario Avanzado Plaza Monjas"
                />
              </div>
            </div>
            <input
              className="input"
              value={poiDescription}
              onChange={(e) => setPoiDescription(e.target.value)}
              placeholder="Descripción u observaciones operativas"
            />
            {selectedLocation ? (
              <p className="text-xs text-success-700 bg-success-50 rounded-xl px-3 py-2 flex items-center gap-2">
                <MapPin size={14} /> Coordenadas fijadas: {selectedLocation.lat.toFixed(5)}, {selectedLocation.lng.toFixed(5)}
              </p>
            ) : (
              <p className="text-xs text-warning-700 bg-warning-50 rounded-xl px-3 py-2">
                Toca el mapa arriba para seleccionar la ubicación exacta del punto.
              </p>
            )}
            {error && <p className="text-sm text-error-600 bg-error-50 rounded-xl px-3 py-2">{error}</p>}
            <div className="flex gap-2">
              <button onClick={cancelAdd} className="btn-outline flex-1">
                Cancelar
              </button>
              <button onClick={savePoi} disabled={saving} className="btn-primary flex-1">
                {saving ? <Spinner size={16} /> : <Plus size={16} />} Guardar punto
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <button onClick={() => startAdd('poi')} className="btn-primary w-full">
              <Plus size={16} /> Añadir punto de interés
            </button>

            {/* Listado de Puntos de Interés con botón de borrado rápido */}
            <div className="card p-3.5 space-y-2">
              <p className="text-xs font-semibold text-gray-700">Puntos registrados en cartografía ({pois.length})</p>
              <div className="divide-y divide-gray-100 max-h-56 overflow-y-auto">
                {pois.map((p) => (
                  <div key={p.id} className="py-2 flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: poiConfig[p.categoria]?.color }} />
                      <div className="truncate">
                        <p className="font-semibold text-gray-900 truncate">{p.nombre}</p>
                        <p className="text-[11px] text-gray-400 truncate">{poiConfig[p.categoria]?.label}</p>
                      </div>
                    </div>
                    {canManage && (
                      <button
                        onClick={() =>
                          setDeleteTarget({
                            type: 'poi',
                            id: p.id,
                            name: p.nombre,
                          })
                        }
                        className="p-1.5 text-gray-400 hover:text-error-600 hover:bg-error-50 rounded-lg cursor-pointer"
                        title="Eliminar punto de interés"
                      >
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )
      )}

      {/* Formulario Vehículos: SELECCIÓN EXCLUSIVA DE PARQUE MÓVIL */}
      {tab === 'vehiculos' && canManage && (
        addMode === 'vehicle' ? (
          <div className="card p-4 space-y-3">
            <h2 className="text-sm font-semibold text-gray-900">Posicionar vehículo de la flota oficial</h2>
            <div className="space-y-3">
              <div>
                <label className="label font-semibold">Vehículo del Parque Móvil a desplegar</label>
                <select
                  className="input font-medium"
                  value={selectedFleetVehicleId}
                  onChange={(e) => {
                    setSelectedFleetVehicleId(e.target.value);
                    const match = vehicles.find((v) => v.id === e.target.value);
                    if (match) setVehicleStatus(match.estado);
                  }}
                >
                  <option value="">-- Selecciona un vehículo oficial --</option>
                  {vehicles.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.indicativo ? `${v.indicativo} · ` : ''}
                      {v.nombre} ({vehicleTypeConfig[v.tipo]?.label || v.tipo}) {v.matricula ? `[${v.matricula}]` : ''}
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-gray-400 mt-1">
                  Solo se pueden situar vehículos creados en la gestión de Parque Móvil.
                </p>
              </div>

              <div>
                <label className="label">Estado operativo inicial</label>
                <select className="input" value={vehicleStatus} onChange={(e) => setVehicleStatus(e.target.value as VehicleStatus)}>
                  {(Object.keys(vehicleStatusConfig) as VehicleStatus[]).map((st) => (
                    <option key={st} value={st}>
                      {vehicleStatusConfig[st].label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {selectedLocation ? (
              <p className="text-xs text-success-700 bg-success-50 rounded-xl px-3 py-2 flex items-center gap-2">
                <Navigation size={14} /> Posición fijada: {selectedLocation.lat.toFixed(5)}, {selectedLocation.lng.toFixed(5)}
              </p>
            ) : (
              <p className="text-xs text-warning-700 bg-warning-50 rounded-xl px-3 py-2">
                Toca el mapa para fijar las coordenadas del vehículo.
              </p>
            )}

            {error && <p className="text-sm text-error-600 bg-error-50 rounded-xl px-3 py-2">{error}</p>}

            <div className="flex gap-2">
              <button onClick={cancelAdd} className="btn-outline flex-1">
                Cancelar
              </button>
              <button onClick={placeVehicleOnMap} disabled={saving} className="btn-primary flex-1">
                {saving ? <Spinner size={16} /> : <Truck size={16} />} Situar vehículo en el mapa
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <button onClick={() => startAdd('vehicle')} className="btn-primary w-full">
              <Plus size={16} /> Posicionar / Desplegar vehículo en el mapa
            </button>

            {/* Listado de Vehículos en el mapa con opciones de retirada y eliminación */}
            <div className="card p-3.5 space-y-2">
              <p className="text-xs font-semibold text-gray-700">Vehículos en el mapa ({placedVehicles.length})</p>
              <div className="divide-y divide-gray-100 max-h-56 overflow-y-auto">
                {placedVehicles.map((v) => (
                  <div key={v.id} className="py-2 flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: vehicleTypeConfig[v.tipo]?.color }} />
                      <div className="truncate">
                        <p className="font-semibold text-gray-900 truncate">
                          {v.indicativo ? `${v.indicativo} · ` : ''}{v.nombre}
                        </p>
                        <p className="text-[11px] text-gray-400">
                          {vehicleTypeConfig[v.tipo]?.label} · {vehicleStatusConfig[v.estado]?.label}
                        </p>
                      </div>
                    </div>
                    {canManage && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleRetireVehicleFromMap(v.id)}
                          className="px-2 py-1 text-[11px] text-amber-700 hover:bg-amber-50 rounded-md border border-amber-200 cursor-pointer"
                          title="Retirar del mapa"
                        >
                          Retirar
                        </button>
                        <button
                          onClick={() =>
                            setDeleteTarget({
                              type: 'vehicle_fleet',
                              id: v.id,
                              name: v.nombre,
                            })
                          }
                          className="p-1.5 text-gray-400 hover:text-error-600 hover:bg-error-50 rounded-lg cursor-pointer"
                          title="Eliminar de la flota"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )
      )}

      {/* Formulario Waypoints en Rutas */}
      {tab === 'rutas' && canManage && selectedRouteId && addMode === 'waypoint' && (
        <div className="card p-4 space-y-3">
          <h2 className="text-sm font-semibold text-gray-900">Añadir punto a la ruta seleccionada</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="label">Tipo de punto</label>
              <select className="input" value={waypointType} onChange={(e) => setWaypointType(e.target.value as WaypointType)}>
                {(Object.keys(waypointTypeConfig) as WaypointType[]).map((item) => (
                  <option key={item} value={item}>
                    {waypointTypeConfig[item].label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Etiqueta opcional</label>
              <input
                className="input"
                value={waypointLabel}
                onChange={(e) => setWaypointLabel(e.target.value)}
                placeholder="Ej. Retén Cruce Gran Vía"
              />
            </div>
          </div>
          {selectedLocation ? (
            <p className="text-xs text-success-700 bg-success-50 rounded-xl px-3 py-2 flex items-center gap-2">
              <MapPin size={14} /> Coordenadas fijadas: {selectedLocation.lat.toFixed(5)}, {selectedLocation.lng.toFixed(5)}
            </p>
          ) : (
            <p className="text-xs text-warning-700 bg-warning-50 rounded-xl px-3 py-2">
              Toca el mapa arriba para añadir el siguiente punto al trazado.
            </p>
          )}
          {error && <p className="text-sm text-error-600 bg-error-50 rounded-xl px-3 py-2">{error}</p>}
          <div className="flex gap-2">
            <button onClick={cancelAdd} className="btn-outline flex-1">
              Cancelar
            </button>
            <button onClick={addWaypoint} disabled={saving} className="btn-primary flex-1">
              {saving ? <Spinner size={16} /> : <Plus size={16} />} Añadir punto {waypoints.length > 0 ? `(${waypoints.length})` : ''}
            </button>
          </div>
        </div>
      )}

      {/* Modal de nueva ruta especial */}
      {showRouteModal && (
        <Modal open onClose={() => setShowRouteModal(false)} title="Nueva ruta especial" size="md">
          <div className="space-y-4">
            <div>
              <label className="label">Nombre del evento</label>
              <input
                className="input"
                value={routeName}
                onChange={(e) => setRouteName(e.target.value)}
                placeholder="Ej. Procesión del Domingo de Ramos"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Tipo de evento</label>
                <select className="input" value={routeType} onChange={(e) => setRouteType(e.target.value as RouteType)}>
                  {(Object.keys(routeTypeConfig) as RouteType[]).map((item) => (
                    <option key={item} value={item}>
                      {routeTypeConfig[item].label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Fecha y hora</label>
                <input type="datetime-local" className="input" value={routeDate} onChange={(e) => setRouteDate(e.target.value)} />
              </div>
            </div>
            <div>
              <label className="label">Descripción opcional</label>
              <input
                className="input"
                value={routeDescription}
                onChange={(e) => setRouteDescription(e.target.value)}
                placeholder="Detalles operativos del dispositivo"
              />
            </div>
            {error && <p className="text-sm text-error-600 bg-error-50 rounded-xl px-3 py-2">{error}</p>}
            <div className="flex gap-3">
              <button onClick={() => setShowRouteModal(false)} className="btn-outline flex-1">
                Cancelar
              </button>
              <button onClick={createRoute} disabled={saving} className="btn-primary flex-1">
                {saving ? <Spinner size={16} /> : <Plus size={16} />} Crear ruta
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Diálogo de Confirmación para Borrado de POI, Ruta o Vehículo */}
      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleExecuteDelete}
        title={
          deleteTarget?.type === 'poi'
            ? 'Eliminar Punto de Interés'
            : deleteTarget?.type === 'route'
            ? 'Eliminar Ruta Especial'
            : 'Eliminar Vehículo de la Flota'
        }
        message={
          deleteTarget?.type === 'poi'
            ? `¿Estás seguro de que deseas eliminar permanentemente el punto "${deleteTarget.name}" del mapa? Esta acción no se puede deshacer.`
            : deleteTarget?.type === 'route'
            ? `¿Estás seguro de que deseas eliminar la ruta "${deleteTarget?.name}" y todos sus puntos de trazado?`
            : `¿Estás seguro de que deseas eliminar permanentemente "${deleteTarget?.name}" de la flota oficial del Parque Móvil?`
        }
        confirmText="Eliminar"
        danger
      />

      <div className="flex items-center gap-2 text-xs text-gray-400 flex-wrap">
        <MapPinned size={14} />
        {loading
          ? 'Cargando cartografía…'
          : tab === 'general'
          ? `${visiblePois.length} puntos visibles`
          : tab === 'vehiculos'
          ? `${vehicles.length} vehículos en flota (${placedVehicles.length} en mapa)`
          : `${routes.length} rutas · ${waypoints.length} puntos`}
        {!canManage && <Badge variant="gray">Modo consulta</Badge>}
      </div>
    </div>
  );
}
