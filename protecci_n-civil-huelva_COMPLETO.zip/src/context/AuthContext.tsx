import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { supabase, isSupabaseConfigured, type Profile } from '@/lib/supabase';
import type { Session, User } from '@supabase/supabase-js';

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (data: SignUpData) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  signInDemo: () => void;
}

interface SignUpData {
  email: string;
  password: string;
  nombre: string;
  apellidos: string;
  indicativo?: string;
  especialidad?: string;
  telefono?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (uid: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', uid)
        .maybeSingle();
      if (error) {
        console.warn('Error fetching profile:', error);
      }
      if (data) {
        setProfile(data as Profile);
      } else {
        // Fallback profile if user exists in auth but no profile table record yet
        setProfile({
          id: uid,
          email: '',
          nombre: 'Voluntario',
          apellidos: '',
          role: 'voluntario',
          indicativo: null,
          especialidad: null,
          telefono: null,
          avatar_url: null,
          dni: null,
          agrupacion_role: 'voluntario',
          is_active: true,
          is_approved: true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
      }
    } catch (e) {
      console.warn('fetchProfile exception:', e);
    }
  }, []);

  useEffect(() => {
    if (!isSupabaseConfigured) {
      if (localStorage.getItem('pc-huelva-demo-active') === 'true') {
        signInDemo();
      } else {
        setLoading(false);
      }
      return;
    }

    // Safety timeout: never let loading freeze the UI beyond 2 seconds
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    supabase.auth.getSession()
      .then(({ data: { session } }) => {
        setSession(session);
        setUser(session?.user ?? null);
        if (session?.user) {
          fetchProfile(session.user.id).finally(() => {
            clearTimeout(timer);
            setLoading(false);
          });
        } else {
          clearTimeout(timer);
          setLoading(false);
        }
      })
      .catch((err) => {
        clearTimeout(timer);
        console.warn('Session error:', err);
        setLoading(false);
      });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (event === 'SIGNED_OUT') {
        setProfile(null);
        setLoading(false);
      } else if (session?.user) {
        (async () => {
          await fetchProfile(session.user.id);
          setLoading(false);
        })();
      } else {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchProfile]);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signUp = async (data: SignUpData) => {
    const { error } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: {
        data: {
          nombre: data.nombre,
          apellidos: data.apellidos,
          role: 'voluntario',
          indicativo: data.indicativo ?? null,
          especialidad: data.especialidad ?? null,
          telefono: data.telefono ?? null,
        },
      },
    });
    return { error: error?.message ?? null };
  };

  const signOut = async () => {
    localStorage.removeItem('pc-huelva-demo-active');
    if (isSupabaseConfigured) {
      await supabase.auth.signOut();
    }
    setProfile(null);
    setUser(null);
    setSession(null);
  };

  const refreshProfile = async () => {
    if (user && isSupabaseConfigured) await fetchProfile(user.id);
  };

  const signInDemo = () => {
    localStorage.setItem('pc-huelva-demo-active', 'true');
    const demoUser = {
      id: 'demo-user-123',
      email: 'voluntario@huelva.es',
      app_metadata: {},
      user_metadata: {},
      aud: 'authenticated',
      created_at: new Date().toISOString(),
    } as unknown as User;

    const demoProfile: Profile = {
      id: 'demo-user-123',
      email: 'voluntario@huelva.es',
      nombre: 'Andrés',
      apellidos: 'Castillejos',
      role: 'admin_tecnico',
      indicativo: 'BRAVO-1',
      especialidad: 'Auxilio Sanitario',
      telefono: '600123456',
      avatar_url: null,
      dni: '12345678Z',
      agrupacion_role: 'jefe_agrupacion',
      is_active: true,
      is_approved: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    setUser(demoUser);
    setProfile(demoProfile);
    setLoading(false);
  };

  return (
    <AuthContext.Provider value={{ session, user, profile, loading, signIn, signUp, signOut, refreshProfile, signInDemo }}>
      {children}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
