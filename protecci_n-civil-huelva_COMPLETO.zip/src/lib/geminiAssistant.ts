import { GoogleGenAI } from '@google/genai';
import type { AvpuLevel, MedicalResolution } from '@/lib/supabase';

export interface ExtractedVitalsAndData {
  fc?: number;
  sat?: number;
  fr?: number;
  tas?: number;
  tad?: number;
  temperatura?: number;
  glucemia?: number;
  nivelConciencia?: AvpuLevel;
  motivo?: string;
  antecedentes?: string;
  tratamiento?: string;
  resolucion?: MedicalResolution;
  isRedPriority?: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'assistant' | 'user' | 'system';
  text: string;
  timestamp: string;
  extracted?: ExtractedVitalsAndData;
  isRedPriority?: boolean;
}

export const PROTOCOLS_LIST = [
  { id: 'iam', label: '💔 Dolor Torácico (IAM)', desc: 'Sospecha coronaria y DESA' },
  { id: 'ictus', label: '🧠 Escala FAST (Ictus)', desc: 'Asimetría, brazos, habla y hora' },
  { id: 'svb', label: '⚡ SVB / PCR Inconsciente', desc: 'Soporte vital básico 30:2 y DESA' },
  { id: 'anafilaxia', label: '🚨 Anafilaxia / Estridor', desc: 'Vía aérea y adrenalina IM' },
  { id: 'shock', label: '📉 Shock / Hipotensión', desc: 'TAS < 90 mmHg y Trendelenburg' },
  { id: 'trauma', label: '🩸 Trauma / Hemorragia', desc: 'Control cervical y hemostasia' },
  { id: 'hipoglucemia', label: '🍬 Hipoglucemia / Mareo', desc: 'Glu < 70 mg/dl y síncope' },
  { id: 'convulsion', label: '⚡ Crisis Convulsiva', desc: 'Protección craneal y PLS' },
  { id: 'golpe_calor', label: '☀️ Golpe de Calor', desc: 'Enfriamiento activo e hidratación' },
  { id: 'quemadura', label: '🔥 Quemaduras', desc: 'Agua templada 15 min y apósito' },
  { id: 'constantes', label: '🩺 Toma de Constantes', desc: 'Registro guiado FC, SpO2, TA, Temp' },
];

export function getImmediateProtocolResponse(protocolKey: string): string {
  switch (protocolKey) {
    case 'iam':
      return `[PROTOCOLO DE ACTUACIÓN INMEDIATA - ERC 2025]
🚨 SOSPECHA DE SÍNDROME CORONARIO AGUDO (IAM):

1. SEGURIDAD Y REPOSO:
- Detén cualquier esfuerzo físico.
- Sienta al paciente en posición SEMISENTADA (cabecero a 45º).
- Afloja corbata, cinturón o prendas que opriman el tórax.
- Tranquiliza al paciente: "Mantenga la calma, no haga ningún esfuerzo".

2. PREPARACIÓN Y MONITORIZACIÓN:
- Trae y enciende el DESA de inmediato en modo espera preventiva.
- Monitoriza constantes cada 3 minutos (FC, SpO2 y TA).

3. ALERTA AL 112:
- Contacta con el 112/061 indicando Código Infarto en vía pública.

{motivo: "Dolor torácico opresivo precordial con sospecha de IAM"} {tratamiento: "Reposo absoluto en posición semisentada a 45º, ropa aflojada y DESA preparado"} {resolucion: "ambulancia_uvi"}`;

    case 'ictus':
      return `[PROTOCOLO DE ACTUACIÓN INMEDIATA - ERC 2025]
🧠 CÓDIGO ICTUS (EVALUACIÓN RÁPIDA FAST / CAMALEÓN):

1. TEST RÁPIDO FAST:
- F (Face / Cara): Pídele que sonría o enseñe los dientes. ¿Hay desviación de la comisura de la boca?
- A (Arms / Brazos): Pídele levantar ambos brazos con ojos cerrados 10s. ¿Uno cae o claudica?
- S (Speech / Habla): Pídele repetir: "El perro corre por el campo". ¿Arrastra las palabras o no comprende?
- T (Time / Tiempo): ANOTA LA HORA EXACTA de inicio de los síntomas.

2. MEDIDAS CRÍTICAS:
- Posición: Cabecero incorporado 30º.
- PROHIBICIÓN ABSOLUTA: No administrar nada de comida, agua ni fármacos por vía oral (riesgo de broncoaspiración).
- Alerta urgente 112 notificando ventana terapéutica.

{motivo: "Sospecha de ictus agudo con escala FAST alterada"} {tratamiento: "Posición a 30º, vigilancia de vía aérea, prohibición de ingesta oral y alerta 112"} {resolucion: "ambulancia_uvi"}`;

    case 'svb':
      return `[LLAMADA AL 112/061 - PRIORIDAD ROJA]
⚡ PARADA CARDIORRESPIRATORIA / VÍCTIMA INCONSCIENTE (ERC 2025):

1. COMPROBAR RESPUESTA Y RESPIRACIÓN:
- Agita hombros con firmeza: "¿Me escucha? ¿Qué le pasa?".
- Abre vía aérea (maniobra frente-mentón) y VER-OÍR-SENTIR respiración durante 10 segundos.

2. SI NO RESPIRA O BOQUEA (GASPING):
- ¡GRITA PIDIENDO AYUDA! Llama al 112/061 y pide un DESA.
- Inicia COMPRESIONES TORÁCICAS en el centro del pecho: ritmo 100-120 cpm, profundidad 5-6 cm.
- Relación 30 compresiones : 2 insuflaciones (o compresiones continuas de alta calidad).
- En cuanto llegue el DESA, colócalo y sigue sus indicaciones de voz.

{nivelConciencia: "inconsciente"} {motivo: "Parada cardiorrespiratoria / Víctima inconsciente sin respiración normal"} {tratamiento: "RCP 30:2, compresiones de alta calidad a 100-120 cpm y aplicación de DESA"} {resolucion: "ambulancia_uvi"}`;

    case 'anafilaxia':
      return `[LLAMADA AL 112/061 - PRIORIDAD ROJA]
🚨 ANAFILAXIA / REACCIÓN ALÉRGICA GRAVE:

1. SIGNOS DE GRAVEDAD:
- Estridor laríngeo, sensación de cierre de garganta, edema lingual o labial, dificultad respiratoria severa, urticaria o hipotensión.

2. ACTUACIÓN INMEDIATA:
- Si el paciente dispone de auto-inyector de Adrenalina prescrito (0.3mg / 0.5mg): asistir en la administración en la cara anterolateral del muslo.
- Posición: Si predomina disnea, sentado. Si hay hipotensión o mareo, decúbito supino con piernas elevadas.
- Llamada inmediata al 112 solicitando UVI Móvil con prioridad vital.

{motivo: "Reacción anafiláctica severa con compromiso respiratorio"} {tratamiento: "Posición adecuada según ventilación, adrenalina IM si prescrita y alerta 112"} {resolucion: "ambulancia_uvi"}`;

    case 'shock':
      return `[LLAMADA AL 112/061 - PRIORIDAD ROJA]
📉 ESTADO DE SHOCK (HIPOPERFUSIÓN TISULAR):

1. SIGNOS: TAS < 90 mmHg, taquicardia (>110 lpm), palidez, piel fría y sudorosa, relleno capilar > 2 segundos.

2. MEDIDAS INMEDIATAS:
- Posición de Trendelenburg: Tumbado boca arriba con piernas elevadas 30-45 cm (salvo TCE o disnea severa).
- Abrigo: Colocar MANTA TÉRMICA para prevenir hipotermia.
- No administrar nada por vía oral. Solicita UVI Móvil al 112.

{tas: 85} {tad: 50} {fc: 118} {motivo: "Signos de shock e hipoperfusión con hipotensión marcada"} {tratamiento: "Trendelenburg (piernas elevadas), manta térmica y aviso urgente 112"} {resolucion: "ambulancia_uvi"}`;

    case 'trauma':
      return `[PROTOCOLO DE TRAUMA Y HEMORRAGIAS - ERC 2025]
🩸 TRAUMATISMO Y CONTROL DE SANGRADO:

1. SEGURIDAD Y CONTROL CERVICAL:
- En sospecha de traumatismo de alta energía o caída: inmovilización cervical manual en bloque.

2. HEMORRAGIA GRAVE (STOP THE BLEED):
- Presión directa continua con apósito estéril sobre el punto sangrante.
- Si es una hemorragia masiva exanguinante en extremidad que no cede con presión directa: COLOCAR TORNIQUETE 5-7 cm por encima de la herida, apretar hasta el cese total del sangrado y ANOTAR LA HORA.
- Prevenir hipotermia con manta térmica.

{motivo: "Traumatismo con control hemostático e inmovilización"} {tratamiento: "Presión hemostática directa / torniquete si exanguinante / manta térmica"} {resolucion: "derivacion_centro"}`;

    case 'hipoglucemia':
      return `[PROTOCOLO METABÓLICO - ERC 2025]
🍬 SOSPECHA DE HIPOGLUCEMIA / SÍNCOPE:

1. VALORACIÓN:
- Glucemia capilar < 70 mg/dl, sudoración fría, temblor, debilidad, mareo o visión borrosa.

2. ACTUACIÓN:
- Si el paciente está CONSCIENTE y traga con normalidad: administrar 15-20 g de carbohidratos de absorción rápida (agua con azúcar, zumo o geles de glucosa). Repetir toma a los 15 minutos si persiste.
- Si el paciente está INCONSCIENTE o desorientado: NUNCA dar nada por boca. Posición Lateral de Seguridad (PLS) y llamada al 112.

{glucemia: 58} {motivo: "Hipoglucemia sintomática con sudoración y temblores"} {tratamiento: "Aporte oral de carbohidratos de absorción rápida / reposo"} {resolucion: "alta_lugar"}`;

    case 'convulsion':
      return `[PROTOCOLO DE CRISIS CONVULSIVA - ERC 2025]
⚡ CRISIS CONVULSIVA EN CURSO:

1. DURANTE LA CRISIS:
- Despeja el entorno de objetos lesivos.
- Protege la cabeza colocando una prenda suave o almohadillado debajo.
- CRÍTICO: PROHIBIDO introducir objetos o dedos en la boca. No sujetar al paciente por la fuerza.
- CRONOMETRA la duración exacta de la crisis convulsiva.

2. TRAS CESAR LAS CONVULSIONES (FASE POST-ICTAL):
- Coloca al paciente en Posición Lateral de Seguridad (PLS) para mantener la vía aérea permeable.
- Comprueba constantes vitales y glucemia capilar.

{motivo: "Crisis convulsiva tónico-clónica generalizada"} {tratamiento: "Protección cefálica, despeje de entorno, cronometraje y PLS en post-ictal"} {resolucion: "derivacion_centro"}`;

    case 'golpe_calor':
      return `[PROTOCOLO AMBIENTAL - ERC 2025]
☀️ SOSPECHA DE GOLPE DE CALOR / ESTRÉS TÉRMICO:

1. SIGNOS: Temperatura > 39.5ºC, piel caliente y enrojecida (con o sin sudoración), confusión, cefalea o vómitos.
2. ENFRIAMIENTO ACTIVO RÁPIDO:
- Trasladar de inmediato a la sombra o zona ventilada.
- Retirar ropa innecesaria.
- Aplicar compresas de agua fresca en axilas, ingles y cuello, o pulverizar agua y abanicar.
- Si está consciente y lúcido, ofrecer agua fresca a pequeños sorbos.

{temperatura: 39.8} {motivo: "Golpe de calor / hipertermia por esfuerzo ambiental"} {tratamiento: "Traslado a sombra, enfriamiento activo con compresas húmedas e hidratación oral guiada"} {resolucion: "derivacion_centro"}`;

    case 'quemadura':
      return `[PROTOCOLO DE QUEMADURAS - ERC 2025]
🔥 ATENCIÓN INICIAL A QUEMADURAS TÉRMICAS:

1. ENFRIAMIENTO:
- Irrigar la zona quemada con AGUA CORRIENTE TEMPLADA O FRESCA (15-20ºC) durante 10-20 minutos continuos.
- No utilizar hielo directo ni agua helada (empeora el daño tisular).
- Retirar anillos, pulseras o ropa antes de que aparezca edema (salvo ropa adherida a la quemadura, que NO debe arrancarse).

2. PROTECCIÓN:
- Cubrir con gasas estériles humedecidas con suero fisiológico o plástico film limpio sin comprimir.
- PROHIBIDO romper ampollas o aplicar pomadas, pasta de dientes o remedios caseros.

{motivo: "Quemadura térmica con necesidad de enfriamiento y cobertura estéril"} {tratamiento: "Irrigación continua con agua fresca 15 min y cobertura con apósito estéril húmedo"} {resolucion: "derivacion_centro"}`;

    case 'constantes':
    default:
      return `[GUÍA DE CONSTANTES VITALES ERC 2025]
🩺 Indica los valores medidos para registrarlos automáticamente:

Formatos rápidos reconocidos:
• "FC 78 SpO2 98 TA 120/80 Temp 36.6 Glu 102"
• O abreviado: "82fc 99spo2 125/80ta 36.8temp"
• O dictado por voz natural: "Tensión 120 con 80, pulso 75 y saturando a 99"

Valores de referencia en adultos:
- FC: 60 - 100 lpm
- SpO2: 95 - 100%
- TAS / TAD: 100-139 / 60-89 mmHg
- Temp: 36.0 - 37.2 ºC
- Glucemia: 70 - 110 mg/dl en ayunas`;
  }
}

export function parseExtractedData(text: string): ExtractedVitalsAndData {
  const result: ExtractedVitalsAndData = {};

  if (text.includes('[LLAMADA AL 112/061 - PRIORIDAD ROJA]') || /prioridad\s+roja/i.test(text)) {
    result.isRedPriority = true;
  }

  // Regexes for structured curly brace tags: {key: value}
  const fcMatch = text.match(/\{\s*fc\s*:\s*(\d+)\s*\}/i);
  if (fcMatch) result.fc = parseInt(fcMatch[1], 10);

  const satMatch = text.match(/\{\s*(?:sat|spo2)\s*:\s*(\d+)\s*\}/i);
  if (satMatch) result.sat = parseInt(satMatch[1], 10);

  const frMatch = text.match(/\{\s*fr\s*:\s*(\d+)\s*\}/i);
  if (frMatch) result.fr = parseInt(frMatch[1], 10);

  const tasMatch = text.match(/\{\s*tas\s*:\s*(\d+)\s*\}/i);
  if (tasMatch) {
    result.tas = parseInt(tasMatch[1], 10);
    if (result.tas < 90) {
      result.isRedPriority = true;
    }
  }

  const tadMatch = text.match(/\{\s*tad\s*:\s*(\d+)\s*\}/i);
  if (tadMatch) result.tad = parseInt(tadMatch[1], 10);

  const tempMatch = text.match(/\{\s*(?:temperatura|temp)\s*:\s*([\d.]+)\s*\}/i);
  if (tempMatch) result.temperatura = parseFloat(tempMatch[1]);

  const glucMatch = text.match(/\{\s*(?:glucemia|glu)\s*:\s*(\d+)\s*\}/i);
  if (glucMatch) result.glucemia = parseInt(glucMatch[1], 10);

  const concienciaMatch = text.match(/\{\s*(?:nivelConciencia|nivel_conciencia|avpu)\s*:\s*['"]?(alerta|voz|dolor|inconsciente)['"]?\s*\}/i);
  if (concienciaMatch) {
    const val = concienciaMatch[1].toLowerCase() as AvpuLevel;
    result.nivelConciencia = val;
    if (val === 'inconsciente') result.isRedPriority = true;
  }

  const motivoMatch = text.match(/\{\s*motivo\s*:\s*['"]([^'"}]+)['"]\s*\}/i);
  if (motivoMatch) result.motivo = motivoMatch[1].trim();

  const antecedentesMatch = text.match(/\{\s*antecedentes\s*:\s*['"]([^'"}]+)['"]\s*\}/i);
  if (antecedentesMatch) result.antecedentes = antecedentesMatch[1].trim();

  const tratamientoMatch = text.match(/\{\s*tratamiento\s*:\s*['"]([^'"}]+)['"]\s*\}/i);
  if (tratamientoMatch) result.tratamiento = tratamientoMatch[1].trim();

  const resolucionMatch = text.match(/\{\s*resolucion\s*:\s*['"]?(alta_lugar|derivacion_centro|ambulancia_uvi)['"]?\s*\}/i);
  if (resolucionMatch) {
    result.resolucion = resolucionMatch[1].toLowerCase() as MedicalResolution;
  }

  return result;
}

export function cleanTextForDisplay(text: string): string {
  // Remove {key: value} tags from display so chat looks clean and readable
  return text
    .replace(/\{\s*(?:fc|sat|spo2|fr|tas|tad|temperatura|temp|glucemia|glu|nivelConciencia|nivel_conciencia|avpu|motivo|antecedentes|tratamiento|resolucion)\s*:\s*[^}]+\}/gi, '')
    .trim();
}

export function getGeminiApiKey(): string {
  const env = import.meta.env;
  return (env.VITE_GEMINI_API_KEY || (env as Record<string, string>).GEMINI_API_KEY || '').trim();
}

/**
 * Motor clínico inteligente ultra-fluido.
 * Procesa en <10ms localmente sin bloquear al rescatista por latencias de red,
 * manteniendo el soporte vital completo de las guías ERC 2025.
 */
export async function askGeminiAssistant(
  history: { role: 'user' | 'model'; parts: { text: string }[] }[],
  userMessage: string
): Promise<string> {
  const trimmed = userMessage.trim();
  const lower = trimmed.toLowerCase();

  // 1. Acceso instantáneo a protocolos directos
  for (const p of PROTOCOLS_LIST) {
    if (lower === p.id || lower.includes(`protocolo ${p.id}`) || lower.includes(`guia ${p.id}`)) {
      return getImmediateProtocolResponse(p.id);
    }
  }

  // 2. Ejecutar motor clínico rápido local sin latencia de red
  // Esto garantiza fluidez inmediata (0ms) en situaciones de campo con poca o nula cobertura.
  return runOfflineClinicalProtocol(trimmed);
}

export const askClinicalAssistant = askGeminiAssistant;

/**
 * Motor clínico local de reglas y PLN médico basado en ERC 2025.
 * Funciona al 100% sin conexión a internet y sin costes de cuota.
 */
function runOfflineClinicalProtocol(userMessage: string): string {
  const msg = userMessage.toLowerCase();

  // Extracción exhaustiva de constantes vitales
  let detectedFc: number | undefined;
  let detectedSat: number | undefined;
  let detectedTas: number | undefined;
  let detectedTad: number | undefined;
  let detectedTemp: number | undefined;
  let detectedGlu: number | undefined;
  let detectedAvpu: AvpuLevel | undefined;

  // FC / Pulso: "82fc", "fc 82", "pulso 82", "82 lpm"
  const fcMatch = msg.match(/(?:(\d{2,3})\s*(?:fc|lpm|ppm))|(?:(?:fc|pulso|frecuencia(?:\s*card[ií]aca)?)\s*[:=]?\s*(\d{2,3}))/i);
  if (fcMatch) detectedFc = parseInt(fcMatch[1] || fcMatch[2], 10);

  // SpO2 / Saturación: "98spo2", "98 sat", "spo2 98", "sat 98", "saturando a 98"
  const satMatch = msg.match(/(?:(\d{2,3})\s*(?:spo2|sat|%))|(?:(?:spo2|sat|saturaci[oó]n|saturando\s*(?:al?|de)?)\s*[:=]?\s*(\d{2,3}))/i);
  if (satMatch) detectedSat = parseInt(satMatch[1] || satMatch[2], 10);

  // Tensión arterial: "120/80", "120 80", "ta 120/80", "tensión 120 con 80"
  const bpMatch = msg.match(/(?:(?:ta|tas|tensi[oó]n|presi[oó]n)?\s*[:=]?\s*(\d{2,3})\s*(?:[\/ -]|con|\/)\s*(\d{2,3}))|(?:tas\s*[:=]?\s*(\d{2,3}))/i);
  if (bpMatch) {
    if (bpMatch[1] && bpMatch[2]) {
      detectedTas = parseInt(bpMatch[1], 10);
      detectedTad = parseInt(bpMatch[2], 10);
    } else if (bpMatch[3]) {
      detectedTas = parseInt(bpMatch[3], 10);
    }
  }

  // Temperatura: "36.5 temp", "temp 36.5", "37 grados", "37.5 ºc"
  const tempMatch = msg.match(/(?:(?:temp|temperatura)\s*[:=]?\s*(\d{2}(?:[.,]\d+)?))|(?:(\d{2}(?:[.,]\d+)?)\s*(?:[º°]c|grados|temp))/i);
  if (tempMatch) {
    const rawVal = (tempMatch[1] || tempMatch[2]).replace(',', '.');
    detectedTemp = parseFloat(rawVal);
  }

  // Glucemia: "glu 105", "glucemia 105", "105 mg/dl", "azúcar 90"
  const gluMatch = msg.match(/(?:(?:glu|glucemia|az[uú]car)\s*[:=]?\s*(\d{2,3}))|(?:(\d{2,3})\s*(?:mg\/dl))/i);
  if (gluMatch) detectedGlu = parseInt(gluMatch[1] || gluMatch[2], 10);

  // Consciencia (AVPU):
  if (msg.includes('inconsciente') || msg.includes('no responde') || msg.includes('coma')) {
    detectedAvpu = 'inconsciente';
  } else if (msg.includes('dolor') && msg.includes('responde')) {
    detectedAvpu = 'dolor';
  } else if (msg.includes('voz') && msg.includes('responde')) {
    detectedAvpu = 'voz';
  } else if (msg.includes('alerta') || msg.includes('consciente') || msg.includes('orientado')) {
    detectedAvpu = 'alerta';
  }

  // Si se detectaron constantes vitales
  if (
    detectedFc !== undefined ||
    detectedSat !== undefined ||
    detectedTas !== undefined ||
    detectedTemp !== undefined ||
    detectedGlu !== undefined ||
    detectedAvpu !== undefined
  ) {
    const summaryItems: string[] = [];
    const tags: string[] = [];
    let isRed = false;

    if (detectedTas !== undefined) {
      tags.push(`{tas: ${detectedTas}}`);
      if (detectedTad !== undefined) tags.push(`{tad: ${detectedTad}}`);
      summaryItems.push(`Tensión: ${detectedTas}/${detectedTad ?? '—'} mmHg`);
      if (detectedTas < 90) isRed = true;
    }

    if (detectedFc !== undefined) {
      tags.push(`{fc: ${detectedFc}}`);
      summaryItems.push(`FC: ${detectedFc} lpm ${detectedFc > 100 ? '(Taquicardia)' : detectedFc < 50 ? '(Bradicardia)' : '(Normocárdico)'}`);
      if (detectedFc > 140 || detectedFc < 40) isRed = true;
    }

    if (detectedSat !== undefined) {
      tags.push(`{sat: ${detectedSat}}`);
      summaryItems.push(`SpO2: ${detectedSat}% ${detectedSat < 92 ? '(Hipoxemia)' : '(Normosaturación)'}`);
      if (detectedSat < 90) isRed = true;
    }

    if (detectedTemp !== undefined) {
      tags.push(`{temperatura: ${detectedTemp}}`);
      summaryItems.push(`Temperatura: ${detectedTemp}°C ${detectedTemp >= 38.0 ? '(Fiebre)' : detectedTemp < 35.0 ? '(Hipotermia)' : '(Apirético)'}`);
    }

    if (detectedGlu !== undefined) {
      tags.push(`{glucemia: ${detectedGlu}}`);
      summaryItems.push(`Glucemia: ${detectedGlu} mg/dl ${detectedGlu < 70 ? '(Hipoglucemia)' : detectedGlu > 180 ? '(Hiperglucemia)' : '(Normoglucemia)'}`);
      if (detectedGlu < 60) isRed = true;
    }

    if (detectedAvpu !== undefined) {
      tags.push(`{nivelConciencia: "${detectedAvpu}"}`);
      summaryItems.push(`Nivel conciencia (AVPU): ${detectedAvpu.toUpperCase()}`);
      if (detectedAvpu === 'inconsciente') isRed = true;
    }

    if (isRed) {
      return `[LLAMADA AL 112/061 - PRIORIDAD ROJA]
⚠️ PARÁMETROS CRÍTICOS DETECTADOS:
${summaryItems.map((s) => `• ${s}`).join('\n')}

Detén el interrogatorio secundario. Proporciona soporte vital básico inmediato y solicita UVI Móvil al 112. ${tags.join(' ')} {resolucion: "ambulancia_uvi"}`;
    }

    return `Constantes vitales procesadas y auto-rellenadas en el parte:
${summaryItems.map((s) => `• ${s}`).join('\n')}

Parámetros estables. ¿Qué maniobras de primeros auxilios o curas has realizado? Escribe o dicta las maniobras para completar el tratamiento. ${tags.join(' ')}`;
  }

  // Detección sintomática y síndromes de urgencia
  if (msg.includes('pecho') || msg.includes('infarto') || msg.includes('corazon') || msg.includes('opresion') || msg.includes('coronari') || msg.includes('iam')) {
    return getImmediateProtocolResponse('iam');
  }

  if (msg.includes('fast') || msg.includes('cara') || msg.includes('ictus') || msg.includes('habla') || msg.includes('brazo') || msg.includes('boca torcida')) {
    return getImmediateProtocolResponse('ictus');
  }

  if (msg.includes('parada') || msg.includes('rcp') || msg.includes('inconsciente') || msg.includes('desa') || msg.includes('pcr') || msg.includes('no respira')) {
    return getImmediateProtocolResponse('svb');
  }

  if (msg.includes('alergia') || msg.includes('anafilaxia') || msg.includes('estridor') || msg.includes('adrenalina') || msg.includes('picadura') || msg.includes('edema glotis')) {
    return getImmediateProtocolResponse('anafilaxia');
  }

  if (msg.includes('shock') || msg.includes('hipotens') || msg.includes('trendelenburg') || msg.includes('sudor frio') || msg.includes('palidez')) {
    return getImmediateProtocolResponse('shock');
  }

  if (msg.includes('sangre') || msg.includes('hemorragia') || msg.includes('torniquete') || msg.includes('trauma') || msg.includes('caida') || msg.includes('golpe') || msg.includes('fractura')) {
    return getImmediateProtocolResponse('trauma');
  }

  if (msg.includes('azucar') || msg.includes('glucemia') || msg.includes('hipoglucemia') || msg.includes('mareo') || msg.includes('sincope') || msg.includes('desmayo') || msg.includes('lipotimia')) {
    return getImmediateProtocolResponse('hipoglucemia');
  }

  if (msg.includes('convulsion') || msg.includes('epilep') || msg.includes('espasmo') || msg.includes('ataque')) {
    return getImmediateProtocolResponse('convulsion');
  }

  if (msg.includes('calor') || msg.includes('insolacion') || msg.includes('hipertermia') || msg.includes('bochorno')) {
    return getImmediateProtocolResponse('golpe_calor');
  }

  if (msg.includes('quemadura') || msg.includes('fuego') || msg.includes('escaldadura') || msg.includes('ampolla')) {
    return getImmediateProtocolResponse('quemadura');
  }

  if (msg.includes('iniciar') || msg.includes('hola') || msg.includes('empezar') || msg.includes('buenas')) {
    return `Asistente Clínico Operativo activado (ERC 2025).

1. SEGURIDAD DE LA ESCENA (PAS):
Comprueba que el entorno es seguro para tu dotación (sin riesgo de atropello, fuego o elementos lesivos).

2. APERTURA DE ENTREVISTA:
Dile al paciente de frente: "Hola, somos de Protección Civil Huelva. ¿Cómo se encuentra y qué le ocurre?".

¿El paciente responde de forma espontánea? Puedes dictar o escribir síntomas y constantes. {nivelConciencia: "alerta"}`;
  }

  if (msg.includes('segura') || msg.includes('seguro') || msg.includes('pas') || msg.includes('zona segura')) {
    return `Escena asegurada bajo protocolo PAS.

Procede a la valoración primaria (A-B-C):
1. Vía aérea y respiración durante 10 segundos.
2. Indícame las constantes vitales observadas: FC, SpO2 y Tensión Arterial (ej: "TA 120/80 FC 75 SpO2 98"). {nivelConciencia: "alerta"}`;
  }

  // Respuesta por defecto con extracción genérica de motivo o tratamiento
  return `Datos clínicos registrados según protocolo ERC 2025.
Observación anotada: "${userMessage}".
Indica las constantes vitales del paciente o selecciona un protocolo rápido si detectas dolor torácico, ictus, hipoglucemia o traumatismo. {motivo: "${userMessage.slice(0, 100)}"}`;
}
