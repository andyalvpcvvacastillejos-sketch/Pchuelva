import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export interface PendingSyncCounts {
  incidents: number;
  reports: number;
  triage: number;
  total: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user_id?: string;
  user_email?: string;
  user_role?: string;
  action: 'delete_incident' | 'delete_poi' | 'delete_route' | 'delete_vehicle' | 'delete_report';
  target_id: string;
  target_name: string;
}

const AUDIT_LOG_KEY = 'pc-huelva-audit-log';

/**
 * Registra una acción de borrado o cambio crítico con trazabilidad para Protección Civil.
 */
export function recordAuditAction(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) {
  try {
    const existing: AuditLogEntry[] = JSON.parse(localStorage.getItem(AUDIT_LOG_KEY) || '[]');
    const newEntry: AuditLogEntry = {
      ...entry,
      id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
    };
    const updated = [newEntry, ...existing].slice(0, 100);
    localStorage.setItem(AUDIT_LOG_KEY, JSON.stringify(updated));
  } catch {
    /* noop */
  }
}

/**
 * Obtiene el registro de auditoría local.
 */
export function getAuditLog(): AuditLogEntry[] {
  try {
    return JSON.parse(localStorage.getItem(AUDIT_LOG_KEY) || '[]');
  } catch {
    return [];
  }
}

/**
 * Calcula el número total de elementos pendientes de sincronización en campo.
 */
export function getPendingSyncCounts(): PendingSyncCounts {
  let incidents = 0;
  let reports = 0;
  let triage = 0;

  try {
    const pInc = JSON.parse(localStorage.getItem('pc-huelva-pending-incidents') || '[]');
    incidents = Array.isArray(pInc) ? pInc.length : 0;
  } catch { /* noop */ }

  try {
    const pRep = JSON.parse(localStorage.getItem('pc-huelva-pending-reports') || '[]');
    reports = Array.isArray(pRep) ? pRep.length : 0;
  } catch { /* noop */ }

  try {
    const pTri = JSON.parse(localStorage.getItem('pc-huelva-pending-triage') || '[]');
    triage = Array.isArray(pTri) ? pTri.length : 0;
  } catch { /* noop */ }

  return {
    incidents,
    reports,
    triage,
    total: incidents + reports + triage,
  };
}

/**
 * Ejecuta la sincronización en lote de todos los elementos pendientes cuando hay conexión.
 */
export async function syncAllPendingData(): Promise<{ synced: number; failed: number }> {
  let synced = 0;
  let failed = 0;

  if (!navigator.onLine || !isSupabaseConfigured) {
    return { synced: 0, failed: 0 };
  }

  // 1. Sincronizar incidencias pendientes
  try {
    const pendingIncidents = JSON.parse(localStorage.getItem('pc-huelva-pending-incidents') || '[]');
    if (pendingIncidents.length > 0) {
      const remainingInc = [];
      for (const inc of pendingIncidents) {
        try {
          const { error } = await supabase.from('incidencias_operativas').insert({
            user_id: inc.user_id,
            categoria: inc.categoria,
            descripcion: inc.descripcion,
            latitud: inc.latitud,
            longitud: inc.longitud,
            foto_path: inc.foto_path || null,
            estado: inc.estado || 'abierta',
          });
          if (error) {
            remainingInc.push(inc);
            failed++;
          } else {
            synced++;
          }
        } catch {
          remainingInc.push(inc);
          failed++;
        }
      }
      localStorage.setItem('pc-huelva-pending-incidents', JSON.stringify(remainingInc));
    }
  } catch { /* noop */ }

  // 2. Sincronizar partes sanitarios pendientes
  try {
    const pendingReports = JSON.parse(localStorage.getItem('pc-huelva-pending-reports') || '[]');
    if (pendingReports.length > 0) {
      const remainingRep = [];
      for (const rep of pendingReports) {
        try {
          const { error } = await supabase.from('partes_sanitarios').insert(rep);
          if (error) {
            remainingRep.push(rep);
            failed++;
          } else {
            synced++;
          }
        } catch {
          remainingRep.push(rep);
          failed++;
        }
      }
      localStorage.setItem('pc-huelva-pending-reports', JSON.stringify(remainingRep));
    }
  } catch { /* noop */ }

  return { synced, failed };
}
