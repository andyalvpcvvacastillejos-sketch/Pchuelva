import { supabase, isSupabaseConfigured, type OperationalVehicle, type VehicleType, type VehicleStatus } from './supabase';
import { demoVehicles, DEMO_USER_ID } from './demoData';

const FLEET_STORAGE_KEY = 'pc-huelva-flota-vehiculos';
const FLEET_EVENT = 'pc-huelva-fleet-updated';

export interface FleetVehicleInput {
  nombre: string;
  tipo: VehicleType;
  estado: VehicleStatus;
  matricula?: string | null;
  indicativo?: string | null;
  kilometraje?: number | null;
  itv_caducidad?: string | null;
  seguro_caducidad?: string | null;
  equipamiento?: string | null;
  notas?: string | null;
  latitud?: number | null;
  longitud?: number | null;
  avl_active?: boolean;
  avl_speed?: number | null;
  avl_heading?: number | null;
  avl_accuracy?: number | null;
  avl_last_ping?: string | null;
  avl_transmitted_by?: string | null;
}

/**
 * Obtiene la flota completa de vehículos operativos.
 * Es la fuente única de verdad para toda la aplicación.
 */
export async function getFleetVehicles(): Promise<OperationalVehicle[]> {
  let localVehicles: OperationalVehicle[] = [];
  try {
    const raw = localStorage.getItem(FLEET_STORAGE_KEY);
    if (raw) {
      localVehicles = JSON.parse(raw);
    }
  } catch (e) {
    console.warn('Error al leer flota de localStorage:', e);
  }

  // Si no hay datos en localStorage, inicializamos con los vehículos de demostración
  if (localVehicles.length === 0) {
    localVehicles = [...demoVehicles];
    try {
      localStorage.setItem(FLEET_STORAGE_KEY, JSON.stringify(localVehicles));
    } catch { /* noop */ }
  }

  // Si Supabase está configurado, intentamos consultar y sincronizar
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase
        .from('vehiculos_operativos')
        .select('*')
        .eq('is_active', true)
        .order('nombre', { ascending: true });

      if (!error && data && data.length > 0) {
        // Mezclar con los locales respetando modificaciones recientes
        const dbVehicles = data as OperationalVehicle[];
        const seen = new Set(dbVehicles.map((v) => v.id));
        const merged = [...dbVehicles];
        for (const local of localVehicles) {
          if (!seen.has(local.id) && local.is_active !== false) {
            merged.push(local);
          }
        }
        try {
          localStorage.setItem(FLEET_STORAGE_KEY, JSON.stringify(merged));
        } catch { /* noop */ }
        return merged;
      }
    } catch (err) {
      console.warn('Error al consultar vehiculos_operativos en Supabase:', err);
    }
  }

  return localVehicles.filter((v) => v.is_active !== false);
}

/**
 * Crea un nuevo vehículo en la flota
 */
export async function createFleetVehicle(input: FleetVehicleInput, userId?: string): Promise<OperationalVehicle> {
  const newId = `veh-${Date.now()}`;
  const now = new Date().toISOString();

  const newVehicle: OperationalVehicle & {
    matricula?: string | null;
    indicativo?: string | null;
    kilometraje?: number | null;
    itv_caducidad?: string | null;
    seguro_caducidad?: string | null;
    equipamiento?: string | null;
    notas?: string | null;
  } = {
    id: newId,
    nombre: input.nombre.trim(),
    tipo: input.tipo,
    estado: input.estado,
    latitud: input.latitud ?? 37.2614,
    longitud: input.longitud ?? -6.9447,
    updated_at: now,
    created_at: now,
    created_by: userId || DEMO_USER_ID,
    is_active: true,
    matricula: input.matricula?.trim() || null,
    indicativo: input.indicativo?.trim() || null,
    kilometraje: input.kilometraje ?? null,
    itv_caducidad: input.itv_caducidad || null,
    seguro_caducidad: input.seguro_caducidad || null,
    equipamiento: input.equipamiento?.trim() || null,
    notas: input.notas?.trim() || null,
  };

  // Guardar en localStorage
  try {
    const current = await getFleetVehicles();
    const updated = [newVehicle as OperationalVehicle, ...current];
    localStorage.setItem(FLEET_STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new Event(FLEET_EVENT));
  } catch (e) {
    console.warn('Error guardando vehículo en local:', e);
  }

  // Sincronizar con Supabase si está disponible
  if (isSupabaseConfigured) {
    try {
      await supabase.from('vehiculos_operativos').insert({
        nombre: newVehicle.nombre,
        tipo: newVehicle.tipo,
        estado: newVehicle.estado,
        latitud: newVehicle.latitud,
        longitud: newVehicle.longitud,
        is_active: true,
      });
    } catch (err) {
      console.warn('No se pudo insertar en Supabase:', err);
    }
  }

  return newVehicle as OperationalVehicle;
}

/**
 * Modifica un vehículo existente en la flota
 */
export async function updateFleetVehicle(
  id: string,
  updates: Partial<OperationalVehicle & {
    matricula?: string | null;
    indicativo?: string | null;
    kilometraje?: number | null;
    itv_caducidad?: string | null;
    seguro_caducidad?: string | null;
    equipamiento?: string | null;
    notas?: string | null;
  }>
): Promise<OperationalVehicle | null> {
  const current = await getFleetVehicles();
  const index = current.findIndex((v) => v.id === id);
  if (index === -1) return null;

  const updatedVehicle = {
    ...current[index],
    ...updates,
    updated_at: new Date().toISOString(),
  };

  current[index] = updatedVehicle;

  try {
    localStorage.setItem(FLEET_STORAGE_KEY, JSON.stringify(current));
    window.dispatchEvent(new Event(FLEET_EVENT));
  } catch (e) {
    console.warn('Error actualizando vehículo en local:', e);
  }

  if (isSupabaseConfigured) {
    try {
      await supabase
        .from('vehiculos_operativos')
        .update({
          nombre: updatedVehicle.nombre,
          tipo: updatedVehicle.tipo,
          estado: updatedVehicle.estado,
          latitud: updatedVehicle.latitud,
          longitud: updatedVehicle.longitud,
          updated_at: updatedVehicle.updated_at,
        })
        .eq('id', id);
    } catch (err) {
      console.warn('Error actualizando en Supabase:', err);
    }
  }

  return updatedVehicle;
}

/**
 * Elimina un vehículo de la flota
 */
export async function deleteFleetVehicle(id: string): Promise<boolean> {
  const current = await getFleetVehicles();
  const filtered = current.filter((v) => v.id !== id);

  try {
    localStorage.setItem(FLEET_STORAGE_KEY, JSON.stringify(filtered));
    window.dispatchEvent(new Event(FLEET_EVENT));
  } catch (e) {
    console.warn('Error eliminando vehículo en local:', e);
  }

  if (isSupabaseConfigured) {
    try {
      await supabase
        .from('vehiculos_operativos')
        .update({ is_active: false })
        .eq('id', id);
    } catch (err) {
      console.warn('Error desactivando vehículo en Supabase:', err);
    }
  }

  return true;
}

/**
 * Suscribe un callback a cualquier cambio en la flota
 */
export function subscribeToFleetUpdates(callback: () => void): () => void {
  window.addEventListener(FLEET_EVENT, callback);
  return () => window.removeEventListener(FLEET_EVENT, callback);
}

// ============================================================
// TELEMETRÍA Y GEOLOCALIZACIÓN CONTINUA AVL (AUTOMATIC VEHICLE LOCATION)
// ============================================================

let activeWatchId: number | null = null;
const AVL_STATE_KEY = 'pc-huelva-active-avl-state';

export interface AvlBeaconState {
  active: boolean;
  vehicleId: string;
  volunteerName: string;
  lastPing: string | null;
  lat?: number | null;
  lng?: number | null;
  speed?: number | null;
  accuracy?: number | null;
}

export function getAvlBeaconState(): AvlBeaconState | null {
  try {
    const raw = localStorage.getItem(AVL_STATE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

/**
 * Inicia la baliza GPS activa transmitiendo la posición del vehículo en segundo plano
 */
export function startAvlBeacon(
  vehicleId: string,
  volunteerName: string,
  onUpdate?: (data: { lat: number; lng: number; speed: number | null; accuracy: number | null }) => void
): boolean {
  if (typeof navigator === 'undefined' || !navigator.geolocation) {
    return false;
  }

  stopAvlBeacon();

  const handlePosition = (pos: GeolocationPosition) => {
    const lat = Number(pos.coords.latitude.toFixed(6));
    const lng = Number(pos.coords.longitude.toFixed(6));
    const speed =
      pos.coords.speed !== null && pos.coords.speed !== undefined
        ? Math.round(pos.coords.speed * 3.6) // convertir m/s a km/h
        : null;
    const accuracy = Math.round(pos.coords.accuracy);
    const now = new Date().toISOString();

    const state: AvlBeaconState = {
      active: true,
      vehicleId,
      volunteerName,
      lastPing: now,
      lat,
      lng,
      speed,
      accuracy,
    };

    try {
      localStorage.setItem(AVL_STATE_KEY, JSON.stringify(state));
    } catch { /* noop */ }

    // Actualizar coordenadas y metadatos AVL en la flota
    updateFleetVehicle(vehicleId, {
      latitud: lat,
      longitud: lng,
      estado: 'en_ruta',
      avl_active: true,
      avl_speed: speed,
      avl_heading: pos.coords.heading ?? null,
      avl_accuracy: accuracy,
      avl_last_ping: now,
      avl_transmitted_by: volunteerName,
    });

    if (onUpdate) {
      onUpdate({ lat, lng, speed, accuracy });
    }
  };

  try {
    activeWatchId = navigator.geolocation.watchPosition(
      handlePosition,
      (err) => console.warn('Aviso de telemetría GPS AVL:', err),
      {
        enableHighAccuracy: true,
        maximumAge: 3000,
        timeout: 12000,
      }
    );

    // Obtención inicial rápida
    navigator.geolocation.getCurrentPosition(handlePosition, () => {}, { enableHighAccuracy: true });

    const initState: AvlBeaconState = {
      active: true,
      vehicleId,
      volunteerName,
      lastPing: new Date().toISOString(),
    };
    try {
      localStorage.setItem(AVL_STATE_KEY, JSON.stringify(initState));
    } catch { /* noop */ }

    window.dispatchEvent(new Event(FLEET_EVENT));
    return true;
  } catch (err) {
    console.error('Error al iniciar baliza AVL:', err);
    return false;
  }
}

/**
 * Detiene la baliza GPS activa
 */
export function stopAvlBeacon(): void {
  if (activeWatchId !== null && typeof navigator !== 'undefined' && navigator.geolocation) {
    navigator.geolocation.clearWatch(activeWatchId);
    activeWatchId = null;
  }

  const prev = getAvlBeaconState();
  if (prev?.vehicleId) {
    updateFleetVehicle(prev.vehicleId, {
      avl_active: false,
    });
  }

  try {
    localStorage.removeItem(AVL_STATE_KEY);
  } catch { /* noop */ }

  window.dispatchEvent(new Event(FLEET_EVENT));
}

