import type { MedicalReport, OperativeIncident } from './supabase';

export interface ReportExportItem extends MedicalReport {
  servicio_titulo?: string;
  vehiculo_nombre?: string;
  incident_descripcion?: string;
  incident_latitud?: number | null;
  incident_longitud?: number | null;
}

export interface IncidentExportItem extends OperativeIncident {
  report_count?: number;
  servicio_titulo?: string;
}

const resolutionLabels: Record<string, string> = {
  alta_lugar: 'Alta en el lugar',
  derivacion_centro: 'Derivación a centro sanitario',
  ambulancia_uvi: 'Ambulancia UVI (Prioridad Roja)',
};

const categoryLabels: Record<string, string> = {
  urgente_refuerzos: 'Urgente / Refuerzos',
  sanitaria: 'Asistencia Sanitaria',
  trafico_via_publica: 'Tráfico / Vía Pública',
  aviso_general: 'Aviso General / Preventivo',
};

/**
 * Descarga archivo CSV formateado con UTF-8 BOM para compatibilidad con Microsoft Excel y Hojas de Cálculo
 */
export function downloadCsv(filename: string, rows: (string | number | null | undefined)[][]): void {
  const processRow = (row: (string | number | null | undefined)[]) => {
    return row
      .map((val) => {
        if (val === null || val === undefined) return '""';
        const str = String(val).replace(/"/g, '""');
        return `"${str}"`;
      })
      .join(';'); // Delimitador punto y coma estándar para España/Europa
  };

  const csvContent = '\uFEFF' + rows.map(processRow).join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Exporta el historial de asistencias sanitarias a un archivo CSV ordenado y legible
 */
export function exportAsistenciasToCsv(reports: ReportExportItem[], filterLabel?: string): void {
  const headers = [
    'ID Parte',
    'Fecha y Hora',
    'Servicio / Dispositivo',
    'Vehículo Operativo',
    'Nombre Paciente',
    'DNI / NIE',
    'Edad',
    'Teléfono',
    'Dirección Asistencia',
    'Motivo Asistencia / Síntomas',
    'FC (lpm)',
    'TAS (mmHg)',
    'TAD (mmHg)',
    'SpO2 (%)',
    'Temperatura (°C)',
    'Glucemia (mg/dl)',
    'AVPU (Conciencia)',
    'Tratamiento / Primeros Auxilios',
    'Resolución Médica',
    'Latitud GPS',
    'Longitud GPS',
  ];

  const rows: (string | number | null | undefined)[][] = [headers];

  for (const r of reports) {
    const formattedDate = new Date(r.created_at).toLocaleString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    rows.push([
      r.id,
      formattedDate,
      r.servicio_titulo || 'Sin servicio asociado',
      r.vehiculo_nombre || 'No asignado',
      r.paciente_nombre || 'Anónimo / No facilitado',
      r.paciente_dni || '',
      r.paciente_edad != null ? r.paciente_edad : '',
      r.paciente_telefono || '',
      r.direccion || '',
      r.motivo_asistencia || '',
      r.fc != null ? r.fc : '',
      r.tas != null ? r.tas : '',
      r.tad != null ? r.tad : '',
      r.spo2 != null ? r.spo2 : '',
      r.temperatura != null ? r.temperatura : '',
      r.glucemia != null ? r.glucemia : '',
      r.nivel_conciencia ? r.nivel_conciencia.toUpperCase() : '',
      r.tratamiento || '',
      resolutionLabels[r.resolucion] || r.resolucion,
      r.incident_latitud != null ? r.incident_latitud : '',
      r.incident_longitud != null ? r.incident_longitud : '',
    ]);
  }

  const cleanLabel = (filterLabel || 'todas')
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '_')
    .slice(0, 30);
  const timestamp = new Date().toISOString().slice(0, 10);
  downloadCsv(`asistencias_sanitarias_${cleanLabel}_${timestamp}.csv`, rows);
}

/**
 * Exporta incidencias operativas a un archivo CSV con filtro opcional de servicio
 */
export function exportIncidenciasToCsv(incidents: IncidentExportItem[], filterLabel?: string): void {
  const headers = [
    'ID Incidencia',
    'Fecha y Hora',
    'Dispositivo / Servicio',
    'Categoría',
    'Estado',
    'Descripción',
    'Partes Sanitarios Asociados',
    'Latitud GPS',
    'Longitud GPS',
    'Tiene Foto',
  ];

  const rows: (string | number | null | undefined)[][] = [headers];

  for (const inc of incidents) {
    const formattedDate = new Date(inc.created_at).toLocaleString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    rows.push([
      inc.id,
      formattedDate,
      inc.servicio_titulo || 'General / Operativa activa',
      categoryLabels[inc.categoria] || inc.categoria,
      inc.estado === 'resuelta' ? 'Resuelta' : 'Abierta',
      inc.descripcion,
      inc.report_count ?? 0,
      inc.latitud != null ? inc.latitud : '',
      inc.longitud != null ? inc.longitud : '',
      inc.foto_path ? 'Sí' : 'No',
    ]);
  }

  const cleanLabel = (filterLabel || 'todas')
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '_')
    .slice(0, 30);
  const timestamp = new Date().toISOString().slice(0, 10);
  downloadCsv(`incidencias_${cleanLabel}_${timestamp}.csv`, rows);
}
