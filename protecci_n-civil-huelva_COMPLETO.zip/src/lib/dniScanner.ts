const DNI_LETTERS = 'TRWAGMYFPDXBNJZSQVHLCKE';

export interface ScannedDniResult {
  dni?: string | null;
  nombre?: string | null;
  apellidos?: string | null;
  edad?: number | null;
  direccion?: string | null;
  cip_nss?: string | null;
  valido?: boolean;
}

/**
 * Valida si un DNI o NIE español tiene el dígito de control oficial correcto (Módulo 23)
 */
export function validateSpanishDni(dni: string): boolean {
  if (!dni) return false;
  const clean = dni.trim().toUpperCase().replace(/[-\s]/g, '');

  // Formato DNI estándar: 8 dígitos + letra
  const dniMatch = clean.match(/^(\d{8})([A-Z])$/);
  if (dniMatch) {
    const num = parseInt(dniMatch[1], 10);
    const letter = dniMatch[2];
    const expected = DNI_LETTERS[num % 23];
    return letter === expected;
  }

  // Formato NIE: X/Y/Z + 7 dígitos + letra
  const nieMatch = clean.match(/^([XYZ])(\d{7})([A-Z])$/);
  if (nieMatch) {
    const prefix = nieMatch[1] === 'X' ? '0' : nieMatch[1] === 'Y' ? '1' : '2';
    const num = parseInt(prefix + nieMatch[2], 10);
    const letter = nieMatch[3];
    const expected = DNI_LETTERS[num % 23];
    return letter === expected;
  }

  return false;
}

// ------------------------------------------------------------
// Escaneo SIMULADO (demo): genera un DNI con letra de control válida
// y un nombre aleatorio. No lee ningún documento real.
// ------------------------------------------------------------

const SIM_FIRST_NAMES = [
  'María', 'Antonio', 'Carmen', 'José', 'Dolores', 'Manuel', 'Rocío', 'Francisco',
  'Lucía', 'Juan', 'Marta', 'Javier', 'Ana', 'Miguel', 'Isabel', 'Rafael',
  'Pilar', 'Alejandro', 'Cristina', 'Fernando',
];

const SIM_SURNAMES = [
  'García', 'Domínguez', 'Rodríguez', 'Martín', 'Pérez', 'González', 'Fernández', 'López',
  'Sánchez', 'Romero', 'Jiménez', 'Márquez', 'Vázquez', 'Gutiérrez', 'Ramos', 'Cordero',
  'Infante', 'Beltrán', 'Moreno', 'Prieto',
];

const pickRandom = <T,>(list: readonly T[]): T => list[Math.floor(Math.random() * list.length)];

/** Devuelve un DNI aleatorio de 8 dígitos + letra de control oficial (módulo 23). */
export function generateValidDni(): string {
  const num = Math.floor(10_000_000 + Math.random() * 69_999_999); // 10.000.000 – 79.999.998
  return `${num}${DNI_LETTERS[num % 23]}`;
}

/** Nombre y dos apellidos aleatorios (formato habitual en España). */
export function generateRandomFullName(): string {
  const surname1 = pickRandom(SIM_SURNAMES);
  let surname2 = pickRandom(SIM_SURNAMES);
  while (surname2 === surname1) surname2 = pickRandom(SIM_SURNAMES);
  return `${pickRandom(SIM_FIRST_NAMES)} ${surname1} ${surname2}`;
}

/** Resultado de una captura simulada: DNI válido + nombre ficticio. */
export function generateSimulatedScan(): { dni: string; nombre: string } {
  return { dni: generateValidDni(), nombre: generateRandomFullName() };
}

/**
 * Redimensiona y comprime una imagen fotográfica en el navegador para que el OCR sea ultra-rápido (<100KB)
 */
export async function compressImageForOcr(file: File, maxDimension = 900): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('No se pudo inicializar canvas'));
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      resolve(dataUrl);
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}

/**
 * Escanea la fotografía de un DNI o tarjeta sanitaria mediante el endpoint de OCR visual del servidor
 */
export async function scanDniDocument(file: File): Promise<ScannedDniResult> {
  const base64 = await compressImageForOcr(file);

  try {
    const res = await fetch('/api/ocr-dni', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ imageBase64: base64 }),
    });

    if (res.ok) {
      const data = await res.json();
      const rawDni = (data.dni || '').trim().toUpperCase();
      const isValid = validateSpanishDni(rawDni);

      return {
        dni: rawDni || null,
        nombre: data.nombre ? `${data.nombre} ${data.apellidos || ''}`.trim() : null,
        apellidos: data.apellidos || null,
        edad: typeof data.edad === 'number' ? data.edad : null,
        direccion: data.direccion || null,
        cip_nss: data.cip_nss || null,
        valido: isValid,
      };
    }
  } catch (err) {
    console.warn('Fallo en OCR remoto /api/ocr-dni:', err);
  }

  // Fallback si la API no está disponible
  return {
    dni: null,
    nombre: null,
    valido: false,
  };
}
