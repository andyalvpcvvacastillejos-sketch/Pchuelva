import { downloadCsv } from './exportUtils';

export type TriageCategory = 'rojo' | 'amarillo' | 'verde' | 'negro';
export type TriageAgeGroup = 'adulto' | 'pediatrico' | 'geriatrico';
export type TriageGender = 'varon' | 'mujer' | 'desconocido';

export interface TriageRecord {
  id: string;
  numero_etiqueta: number; // e.g. 1, 2, 3...
  categoria: TriageCategory;
  edad_grupo: TriageAgeGroup;
  genero: TriageGender;
  lesion_principal: string;
  deambula: boolean;
  frecuencia_respiratoria?: number | null;
  relleno_capilar_seg?: number | null;
  obedece_ordenes: boolean;
  ubicacion_nido?: string | null;
  destino_traslado?: string | null;
  observaciones?: string | null;
  incident_id?: string | null;
  servicio_id?: string | null;
  triado_por: string;
  created_at: string;
  updated_at: string;
}

export const triageCategoryConfig: Record<
  TriageCategory,
  {
    codigo: string;
    label: string;
    prioridad: string;
    tiempoMaximo: string;
    colorHex: string;
    bgClass: string;
    borderClass: string;
    textClass: string;
    dotClass: string;
  }
> = {
  rojo: {
    codigo: 'T1',
    label: 'Inmediato (Rojo)',
    prioridad: 'Prioridad 1 - Riesgo Vital Inmediato',
    tiempoMaximo: '< 15 minutos',
    colorHex: '#dc2626',
    bgClass: 'bg-red-50',
    borderClass: 'border-red-500',
    textClass: 'text-red-700',
    dotClass: 'bg-red-600',
  },
  amarillo: {
    codigo: 'T2',
    label: 'Demorado (Amarillo)',
    prioridad: 'Prioridad 2 - Grave no crítico',
    tiempoMaximo: '< 2 horas',
    colorHex: '#d97706',
    bgClass: 'bg-amber-50',
    borderClass: 'border-amber-500',
    textClass: 'text-amber-800',
    dotClass: 'bg-amber-500',
  },
  verde: {
    codigo: 'T3',
    label: 'Leve (Verde)',
    prioridad: 'Prioridad 3 - Menor / Deambulante',
    tiempoMaximo: '< 4 horas',
    colorHex: '#16a34a',
    bgClass: 'bg-emerald-50',
    borderClass: 'border-emerald-500',
    textClass: 'text-emerald-800',
    dotClass: 'bg-emerald-500',
  },
  negro: {
    codigo: 'T0',
    label: 'Fallecido (Negro)',
    prioridad: 'Prioridad 0 - Fallecido / Sin respiración',
    tiempoMaximo: 'No recuperable',
    colorHex: '#1e293b',
    bgClass: 'bg-slate-100',
    borderClass: 'border-slate-800',
    textClass: 'text-slate-800',
    dotClass: 'bg-slate-900',
  },
};

const TRIAGE_STORAGE_KEY = 'pc-huelva-triage-records';
const TRIAGE_EVENT = 'pc-huelva-triage-updated';

const demoTriageInitial: TriageRecord[] = [
  {
    id: 'tri-001',
    numero_etiqueta: 1,
    categoria: 'rojo',
    edad_grupo: 'adulto',
    genero: 'varon',
    lesion_principal: 'TCE severo con anisocoria y compromiso ventilatorio',
    deambula: false,
    frecuencia_respiratoria: 34,
    relleno_capilar_seg: 3,
    obedece_ordenes: false,
    ubicacion_nido: 'Puesto de Socorro Avanzado - Nido 1',
    destino_traslado: 'UVI Móvil 061 -> Hospital Juan Ramón Jiménez',
    observaciones: 'Prioridad máxima de evacuación en primera ambulancia de soporte vital avanzado.',
    triado_por: 'VIR-1 Bravo',
    created_at: new Date(Date.now() - 1800000).toISOString(),
    updated_at: new Date(Date.now() - 1800000).toISOString(),
  },
  {
    id: 'tri-002',
    numero_etiqueta: 2,
    categoria: 'amarillo',
    edad_grupo: 'adulto',
    genero: 'mujer',
    lesion_principal: 'Fractura abierta de fémur con hemostasia controlada',
    deambula: false,
    frecuencia_respiratoria: 22,
    relleno_capilar_seg: 1,
    obedece_ordenes: true,
    ubicacion_nido: 'Carpa Asistencial 2',
    destino_traslado: 'Ambulancia SVB Protección Civil',
    observaciones: 'Inmovilización con férula de tracción y manta térmica colocada.',
    triado_por: 'Dotación Sanitaria Alfa',
    created_at: new Date(Date.now() - 1500000).toISOString(),
    updated_at: new Date(Date.now() - 1500000).toISOString(),
  },
  {
    id: 'tri-003',
    numero_etiqueta: 3,
    categoria: 'verde',
    edad_grupo: 'adulto',
    genero: 'varon',
    lesion_principal: 'Contusión en muñeca y erosiones múltiples superficiales',
    deambula: true,
    frecuencia_respiratoria: 16,
    relleno_capilar_seg: 1,
    obedece_ordenes: true,
    ubicacion_nido: 'Zona de leves / Sala de espera',
    destino_traslado: 'Alta en lugar tras cura',
    observaciones: 'Caminando por su propio pie. Acompañado por personal de apoyo psicológico.',
    triado_por: 'Dotación Sanitaria Alfa',
    created_at: new Date(Date.now() - 1200000).toISOString(),
    updated_at: new Date(Date.now() - 1200000).toISOString(),
  },
];

export function getTriageRecords(): TriageRecord[] {
  try {
    const raw = localStorage.getItem(TRIAGE_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.warn('Error leyendo registros de triaje de localStorage:', e);
  }

  // Inicializar con demostración si está vacío
  try {
    localStorage.setItem(TRIAGE_STORAGE_KEY, JSON.stringify(demoTriageInitial));
  } catch { /* noop */ }
  return [...demoTriageInitial];
}

export function saveTriageRecord(
  input: Omit<TriageRecord, 'id' | 'numero_etiqueta' | 'created_at' | 'updated_at'> & { id?: string; numero_etiqueta?: number }
): TriageRecord {
  const current = getTriageRecords();
  const now = new Date().toISOString();

  if (input.id) {
    // Edición
    const idx = current.findIndex((r) => r.id === input.id);
    if (idx !== -1) {
      const updated: TriageRecord = {
        ...current[idx],
        ...input,
        id: current[idx].id,
        numero_etiqueta: current[idx].numero_etiqueta,
        updated_at: now,
      };
      current[idx] = updated;
      try {
        localStorage.setItem(TRIAGE_STORAGE_KEY, JSON.stringify(current));
        window.dispatchEvent(new Event(TRIAGE_EVENT));
      } catch { /* noop */ }
      return updated;
    }
  }

  // Alta de nueva víctima triada
  const nextNum = current.length > 0 ? Math.max(...current.map((r) => r.numero_etiqueta)) + 1 : 1;
  const newRecord: TriageRecord = {
    ...input,
    // Sufijo aleatorio: evita ids repetidos si se registran varias víctimas en el mismo milisegundo
    id: `tri-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    numero_etiqueta: nextNum,
    created_at: now,
    updated_at: now,
  };

  const updatedList = [newRecord, ...current];
  try {
    localStorage.setItem(TRIAGE_STORAGE_KEY, JSON.stringify(updatedList));
    window.dispatchEvent(new Event(TRIAGE_EVENT));
  } catch { /* noop */ }

  return newRecord;
}

export function deleteTriageRecord(id: string): boolean {
  const current = getTriageRecords();
  const filtered = current.filter((r) => r.id !== id);
  try {
    localStorage.setItem(TRIAGE_STORAGE_KEY, JSON.stringify(filtered));
    window.dispatchEvent(new Event(TRIAGE_EVENT));
  } catch { /* noop */ }
  return true;
}

// ------------------------------------------------------------
// Contador rápido del PMA (+ / −)
// Cada "+" crea una ficha mínima, de modo que el contador, el listado
// de víctimas, el CSV y el resumen para el 112 comparten la misma fuente.
// ------------------------------------------------------------

const QUICK_LESION_DEFAULT: Record<TriageCategory, string> = {
  rojo: 'Compromiso vital inmediato (registro rápido PMA)',
  amarillo: 'Lesión grave no crítica (registro rápido PMA)',
  verde: 'Lesión leve deambulante (registro rápido PMA)',
  negro: 'Víctima sin signos vitales (registro rápido PMA)',
};

/** Registra 1 víctima de la categoría indicada con datos mínimos (pendiente de filiar). */
export function addQuickTriage(categoria: TriageCategory, triadoPor: string): TriageRecord {
  return saveTriageRecord({
    categoria,
    edad_grupo: 'adulto',
    genero: 'desconocido',
    lesion_principal: QUICK_LESION_DEFAULT[categoria],
    deambula: categoria === 'verde',
    obedece_ordenes: categoria === 'verde' || categoria === 'amarillo',
    ubicacion_nido: 'Puesto de Mando Avanzado (PMA)',
    destino_traslado: null,
    observaciones: 'Alta con contador rápido del PMA. Pendiente de filiación y valoración detallada.',
    triado_por: triadoPor,
  });
}

/**
 * Resta 1 víctima de la categoría: elimina la ficha más reciente (mayor nº de etiqueta).
 * Devuelve la ficha eliminada para poder deshacer la operación, o null si no había ninguna.
 */
export function removeLastTriage(categoria: TriageCategory): TriageRecord | null {
  const target = getTriageRecords()
    .filter((r) => r.categoria === categoria)
    .sort((a, b) => b.numero_etiqueta - a.numero_etiqueta)[0];
  if (!target) return null;
  deleteTriageRecord(target.id);
  return target;
}

/** Reinserta una ficha eliminada (misma id y nº de etiqueta). Usado por "Deshacer". */
export function restoreTriageRecord(record: TriageRecord): void {
  const current = getTriageRecords();
  if (current.some((r) => r.id === record.id)) return;
  const restored = [record, ...current].sort((a, b) => b.numero_etiqueta - a.numero_etiqueta);
  try {
    localStorage.setItem(TRIAGE_STORAGE_KEY, JSON.stringify(restored));
    window.dispatchEvent(new Event(TRIAGE_EVENT));
  } catch { /* noop */ }
}

export function clearAllTriageRecords(): void {
  try {
    localStorage.setItem(TRIAGE_STORAGE_KEY, JSON.stringify([]));
    window.dispatchEvent(new Event(TRIAGE_EVENT));
  } catch { /* noop */ }
}

export function subscribeToTriageUpdates(callback: () => void): () => void {
  window.addEventListener(TRIAGE_EVENT, callback);
  return () => window.removeEventListener(TRIAGE_EVENT, callback);
}

/**
 * Calcula estadísticas de triaje y estimación de recursos sanitarios para el PMA
 */
export function calculateTriageStats(records: TriageRecord[]) {
  const total = records.length;
  const rojos = records.filter((r) => r.categoria === 'rojo').length;
  const amarillos = records.filter((r) => r.categoria === 'amarillo').length;
  const verdes = records.filter((r) => r.categoria === 'verde').length;
  const negros = records.filter((r) => r.categoria === 'negro').length;

  // Cálculo estimativo de evacuación y recursos
  // Cada rojo requiere una ambulancia asistencial avanzada (SVA / UVI)
  const uviRequeridas = rojos;
  // Los amarillos requieren SVB a razón de 1-2 por ambulancia
  const svbRequeridas = Math.ceil(amarillos * 0.7 + verdes * 0.15);

  return {
    total,
    rojos,
    amarillos,
    verdes,
    negros,
    uviRequeridas,
    svbRequeridas,
  };
}

/**
 * Exporta el registro de triaje a CSV para la sala de coordinación / 112
 */
export function exportTriageToCsv(records: TriageRecord[], incidentTitle?: string): void {
  const headers = [
    'Nº Etiqueta',
    'Categoría Triaje',
    'Prioridad Código',
    'Grupo de Edad',
    'Género',
    'Lesión Principal',
    'Deambula',
    'Frecuencia Resp. (rpm)',
    'Relleno Capilar (seg)',
    'Obedece Órdenes',
    'Ubicación en Nido',
    'Destino Traslado / Evacuación',
    'Observaciones Clínicas',
    'Triado Por',
    'Hora Registro',
  ];

  const rows: (string | number | null | undefined)[][] = [headers];

  for (const r of records) {
    rows.push([
      `#${String(r.numero_etiqueta).padStart(3, '0')}`,
      triageCategoryConfig[r.categoria]?.label || r.categoria,
      triageCategoryConfig[r.categoria]?.codigo || '',
      r.edad_grupo,
      r.genero,
      r.lesion_principal,
      r.deambula ? 'SÍ' : 'NO',
      r.frecuencia_respiratoria ?? '—',
      r.relleno_capilar_seg ? `${r.relleno_capilar_seg}s` : '—',
      r.obedece_ordenes ? 'SÍ' : 'NO',
      r.ubicacion_nido || '',
      r.destino_traslado || '',
      r.observaciones || '',
      r.triado_por,
      new Date(r.created_at).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
    ]);
  }

  const filename = `triaje_imv_huelva_${incidentTitle ? incidentTitle.replace(/[^a-zA-Z0-9]/g, '_') : 'pma'}_${new Date().toISOString().slice(0, 10)}.csv`;
  downloadCsv(filename, rows);
}
